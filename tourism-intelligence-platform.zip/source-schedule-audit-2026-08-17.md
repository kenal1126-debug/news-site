# 來源與排程稽核（2026-08-17）

## 每日同步時間

目前啟用中的 Heartbeat `daily-tourism-news-sync` 使用 cron `0 0 2 * * *`（UTC），callback 為 `/api/scheduled/sync-news`。最近執行時間為 `2026-08-17T02:04:33Z`，下一次為 `2026-08-18T02:00:00Z`，因此目前約於每日台灣時間 10:00（UTC+8）同步一次，資料保留最近 14 天。

## 現有程式來源與實際資料

`server/news-sync.ts` 的 NEWS_FEEDS 目前主要是風傳媒、自由時報、自由時報生活與四組 Google News 中文搜尋，尚未直接加入 Reuters、AP、BBC、The Guardian、Travel Weekly、Skift 或 PhocusWire RSS。最近 14 天資料庫來源以 UDN、經濟日報、Google News／聯合新聞網、自由時報生活、NOWnews 等中文來源為主，因此目前「世界10大觀光新聞」雖已有海外來源判定邏輯，實際英文海外新聞數量仍有限。

## 已核對的官方 RSS

交通部英文新聞頁 `https://www.motc.gov.tw/en/app/news_list/list?id=13` 提供官方 RSS：`https://www.motc.gov.tw/en/app/rss?lang=en&folderName=en&id=0`。頁面可見英文交通、港口、郵輪與國際旅運新聞，例如台灣港務公司拓展郵輪航線與國際郵輪市場的內容。

台灣觀光署英文 RSS 訂閱頁 `https://eng.taiwan.net.tw/m1.aspx?sNo=0000270` 提供新聞 RSS：`https://eng.taiwan.net.tw/rss.aspx?sNo=0002001`，可直接補捉觀光署英文新聞與官方政策發布。

外交部英文 RSS 入口 `https://en.mofa.gov.tw/Rss.aspx?n=1447` 提供 News and Events、Press Releases、Statements and Responses、Background Information、Important Remarks 等官方內容入口，適合補捉旅客安全、領務與國際旅運相關政策訊息。

## 部會首長新聞缺漏原因

目前 `isTourismRelated` 主要以旅遊活動、旅宿、景點、航班、旅行社與觀光產業詞彙篩選；「部長／署長宣布政策」「政策記者會」「官方談話」等人物與政策語境覆蓋不足，且現有 NEWS_FEEDS 沒有交通部與觀光署官方英文 RSS，因此部會首長相關新聞容易未進入資料庫。後續應加入官方 RSS，並以觀光政策、旅客安全、航線、旅宿、國際客源等具體觀光訊號保留；選舉、候選人、政黨、投票、民調與選區等內容則一律排除。

## 選舉資料稽核

最近 14 天資料中已確認並清理 4 筆選舉或競選語境新聞：UDN 的「2026九合一選舉」標題尾綴、自由時報生活的出國考察經費攻防、Yahoo／UDN 的觀光政見，以及 Google News／聯合新聞網的「2026九合一選舉」標題尾綴。
