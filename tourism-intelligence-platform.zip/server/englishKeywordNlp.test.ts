import { describe, expect, it } from "vitest";
import { selectEnglishTrendTerms } from "./englishKeywordNlp";

describe("英文關鍵詞 NLP 篩選", () => {
  const candidates = [
    { term: "capacity", count: 8, size: 30 },
    { term: "bookings", count: 6, size: 24 },
    { term: "most", count: 9, size: 32 },
    { term: "scenic", count: 5, size: 18 },
  ];

  it("only accepts noun or concrete-verb terms returned from the known candidate list", () => {
    expect(selectEnglishTrendTerms(candidates, ["capacity", "bookings", "unknown", "MOST"]))
      .toEqual([candidates[0], candidates[1], candidates[2]]);
  });

  it("does not add terms that were not generated from recent news", () => {
    expect(selectEnglishTrendTerms(candidates, ["destination", "routes"]))
      .toEqual([]);
  });
});
