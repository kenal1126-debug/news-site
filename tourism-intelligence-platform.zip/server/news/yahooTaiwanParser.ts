import { createHash } from "node:crypto";
import type { InsertNewsItem } from "../../drizzle/schema";
import { decodeEntities, stripHtml, FOURTEEN_DAYS_MS } from "./rssParser";

type YahooCategoryFeed = { readonly source: string; readonly category: string; readonly url: string };

function parseYahooRelativeDate(context: string, now: Date) {
  if (/剛剛|剛才/.test(context)) return now;
  if (/昨天/.test(context)) return new Date(now.getTime() - 24 * 60 * 60 * 1000);
  if (/前天/.test(context)) return new Date(now.getTime() - 2 * 24 * 60 * 60 * 1000);
  const hours = context.match(/(\d+)\s*小時前/);
  if (hours) return new Date(now.getTime() - Number(hours[1]) * 60 * 60 * 1000);
  const days = context.match(/(\d+)\s*天前/);
  if (days) return new Date(now.getTime() - Number(days[1]) * 24 * 60 * 60 * 1000);
  const weeks = context.match(/(\d+)\s*週前/);
  return weeks ? new Date(now.getTime() - Number(weeks[1]) * 7 * 24 * 60 * 60 * 1000) : null;
}

function parseYahooImage(context: string) {
  const candidates = Array.from(context.matchAll(/<(?:img|source)[^>]+(?:src|data-src|srcset)=["']([^"']+)["'][^>]*>/gi)).map((match) => match[1]).filter((url) => url && !/spaceball|logo|avatar|icon|sprite/i.test(url));
  return candidates[0] ? decodeEntities(candidates[0]).split(",")[0].trim().split(" ")[0] : null;
}

export function parseYahooTaiwanCategoryHtml(html: string, categoryFeed: YahooCategoryFeed, now = new Date()): InsertNewsItem[] {
  const since = now.getTime() - FOURTEEN_DAYS_MS;
  const seen = new Set<string>();
  const results: InsertNewsItem[] = [];
  for (const match of Array.from(html.matchAll(/<a[^>]+href=["']((?:https:\/\/tw\.news\.yahoo\.com)?\/[^"']+-\d+\.html)["'][^>]*>([\s\S]*?)<\/a>/gi))) {
    const url = new URL(decodeEntities(match[1]), "https://tw.news.yahoo.com").toString();
    const title = stripHtml(match[2]);
    if (!title || seen.has(url)) continue;
    const index = match.index ?? 0;
    const context = html.slice(Math.max(0, index - 1400), Math.min(html.length, index + 1400));
    const publishedAt = parseYahooRelativeDate(stripHtml(context), now) || now;
    if (publishedAt.getTime() < since) continue;
    seen.add(url);
    results.push({ source: categoryFeed.source, title, url, guid: createHash("sha256").update(url).digest("hex"), summary: null, imageUrl: parseYahooImage(context), publishedAt });
  }
  return results;
}

export async function fetchYahooTaiwanArticleMetadata(url: string) {
  try {
    const response = await fetch(url, { headers: { "user-agent": "TourismIntelligencePlatform/1.0" }, redirect: "follow", signal: AbortSignal.timeout(8_000) });
    if (!response.ok) return {};
    const html = await response.text();
    const dateRaw = html.match(/datePublished[^A-Za-z0-9]+([0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9:.+\-Z]+)/i)?.[1];
    const description = html.match(/<meta[^>]+(?:name|property)=["'](?:description|og:description)["'][^>]+content=["']([^"']+)["']/i)?.[1] || html.match(/<meta[^>]+content=["']([^"']+)["'][^>]+(?:name|property)=["'](?:description|og:description)["']/i)?.[1];
    const imageUrl = html.match(/<meta[^>]+property=["']og:image["'][^>]+content=["']([^"']+)["']/i)?.[1] || html.match(/<meta[^>]+content=["']([^"']+)["'][^>]+property=["']og:image["']/i)?.[1];
    const publishedAt = dateRaw ? new Date(dateRaw) : undefined;
    return { publishedAt: publishedAt && !Number.isNaN(publishedAt.getTime()) ? publishedAt : undefined, summary: description ? stripHtml(description).slice(0, 500) : undefined, imageUrl: imageUrl ? new URL(decodeEntities(imageUrl), url).toString() : undefined };
  } catch {
    return {};
  }
}
