import { describe, expect, it, vi } from "vitest";
import { refreshNewsKeywordCloudsAfterSync } from "./feedSyncService";

describe("feed sync keyword-cloud refresh", () => {
  it("invalidates the cache and re-analyzes the latest 14-day database rows", async () => {
    const cutoffAt = new Date("2026-08-16T00:00:00Z");
    const events: string[] = [];
    const latestRows = [
      { source: "BBC Travel", title: "Latest route update", summary: "New route capacity." },
    ];
    const invalidateCache = vi.fn(async () => { events.push("cache-invalidated"); });
    const readLatestNews = vi.fn(async (receivedCutoff: Date) => {
      events.push(`read:${receivedCutoff.toISOString()}`);
      return latestRows;
    });
    const analyze = vi.fn(async (items: typeof latestRows) => {
      events.push(`analyze:${items[0]?.title ?? "empty"}`);
    });

    await refreshNewsKeywordCloudsAfterSync(cutoffAt, {
      invalidateCache,
      listRecentNews: readLatestNews,
      analyze,
    });

    expect(events).toEqual([
      "cache-invalidated",
      "read:2026-08-16T00:00:00.000Z",
      "analyze:Latest route update",
    ]);
    expect(readLatestNews).toHaveBeenCalledWith(cutoffAt);
    expect(analyze).toHaveBeenCalledWith(latestRows);
  });
});
