import { createHash } from "node:crypto";

export const FULL_FEED_SOURCES = new Set(["Yahoo Travel"]);

export const YAHOO_TAIWAN_FUN_FEEDS = [
  { source: "Yahoo台灣｜最新熱門景點新聞", category: "最新熱門景點新聞", url: "https://tw.news.yahoo.com/tourist-spots/" },
  { source: "Yahoo台灣｜最新熱門美食新聞", category: "最新熱門美食新聞", url: "https://tw.news.yahoo.com/food/" },
  { source: "Yahoo台灣｜最新日韓旅遊新聞", category: "最新日韓旅遊新聞", url: "https://tw.news.yahoo.com/travel-abroad/" },
  { source: "Yahoo台灣｜最新賞花步道新聞", category: "最新賞花步道新聞", url: "https://tw.news.yahoo.com/outdoors/" },
  { source: "Yahoo台灣｜旅遊達人", category: "旅遊達人", url: "https://tw.news.yahoo.com/travel-blogger/" },
] as const;

export const REQUIRED_ARTICLES = [{ source: "BBC Travel", url: "https://www.bbc.com/travel/article/20260814-the-worlds-best-countries-for-expats-in-2026", title: "The world's best countries for expats in 2026", publishedAt: new Date("2026-08-14T00:00:00Z") }] as const;

export const NEWS_FEEDS = [
  { source: "風傳媒", url: "https://www.storm.mg/feed" },
  { source: "自由時報", url: "https://news.ltn.com.tw/rss/news.xml" },
  { source: "自由時報生活", url: "https://news.ltn.com.tw/rss/life.xml" },
  { source: "Google News／主要媒體", url: "https://news.google.com/rss/search?q=%E8%A7%80%E5%85%89%20%E6%97%85%E9%81%8A%20%E8%88%AA%E7%A9%BA%20%E6%97%85%E5%AE%BF%20%E6%97%85%E8%A1%8C%E7%A4%BE&hl=zh-TW&gl=TW&ceid=TW:zh-Hant" },
  { source: "Google News／聯合新聞網", url: "https://news.google.com/rss/search?q=site%3Audn.com%20%E8%A7%80%E5%85%89%20%E6%97%85%E9%81%8A&hl=zh-TW&gl=TW&ceid=TW:zh-Hant" },
  { source: "Google News／經濟日報", url: "https://news.google.com/rss/search?q=site%3Amoney.udn.com%20%E8%A7%80%E5%85%89%E7%94%A2%E6%A5%AD&hl=zh-TW&gl=TW&ceid=TW:zh-Hant" },
  { source: "Google News／NOWnews", url: "https://news.google.com/rss/search?q=site%3Anownews.com%20%E6%97%85%E9%81%8A%20%E8%A7%80%E5%85%89&hl=zh-TW&gl=TW&ceid=TW:zh-Hant" },
  { source: "Google News／TVBS新聞網", url: "https://news.google.com/rss/search?q=site%3Anews.tvbs.com.tw%20%28%E8%A7%80%E5%85%89%20OR%20%E6%97%85%E9%81%8A%20OR%20%E6%97%85%E5%AE%BF%20OR%20%E9%A3%AF%E5%BA%97%20OR%20%E8%88%AA%E7%A9%BA%20OR%20%E6%97%85%E8%A1%8C%E7%A4%BE%29&hl=zh-TW&gl=TW&ceid=TW:zh-Hant" },
  { source: "Google News／中央社", url: "https://news.google.com/rss/search?q=site%3Acna.com.tw%20%28%E8%A7%80%E5%85%89%20OR%20%E6%97%85%E9%81%8A%20OR%20%E6%97%85%E5%AE%BF%20OR%20%E8%88%AA%E7%A9%BA%20OR%20%E6%97%85%E8%A1%8C%E7%A4%BE%29&hl=zh-TW&gl=TW&ceid=TW:zh-Hant" },
  { source: "Google News／ETtoday", url: "https://news.google.com/rss/search?q=site%3Aettoday.net%20%28%E8%A7%80%E5%85%89%20OR%20%E6%97%85%E9%81%8A%20OR%20%E6%97%85%E5%AE%BF%20OR%20%E8%88%AA%E7%A9%BA%20OR%20%E6%97%85%E8%A1%8C%E7%A4%BE%29&hl=zh-TW&gl=TW&ceid=TW:zh-Hant" },
  { source: "Google News／三立新聞網", url: "https://news.google.com/rss/search?q=site%3Asetn.com%20%28%E8%A7%80%E5%85%89%20OR%20%E6%97%85%E9%81%8A%20OR%20%E6%97%85%E5%AE%BF%20OR%20%E8%88%AA%E7%A9%BA%20OR%20%E6%97%85%E8%A1%8C%E7%A4%BE%29&hl=zh-TW&gl=TW&ceid=TW:zh-Hant" },
  { source: "Google News／中時新聞網", url: "https://news.google.com/rss/search?q=site%3Achinatimes.com%20%28%E8%A7%80%E5%85%89%20OR%20%E6%97%85%E9%81%8A%20OR%20%E6%97%85%E5%AE%BF%20OR%20%E8%88%AA%E7%A9%BA%20OR%20%E6%97%85%E8%A1%8C%E7%A4%BE%29&hl=zh-TW&gl=TW&ceid=TW:zh-Hant" },
  { source: "Google News／公視新聞網", url: "https://news.google.com/rss/search?q=site%3Apnn.pts.org.tw%20%28%E8%A7%80%E5%85%89%20OR%20%E6%97%85%E9%81%8A%20OR%20%E6%97%85%E5%AE%BF%20OR%20%E8%88%AA%E7%A9%BA%20OR%20%E6%97%85%E8%A1%8C%E7%A4%BE%29&hl=zh-TW&gl=TW&ceid=TW:zh-Hant" },
  { source: "Google News／政府旅遊服務異常", url: "https://news.google.com/rss/search?q=%28%E8%A7%80%E5%85%89%E7%BD%B2%20OR%20%E8%A7%80%E6%97%85%E5%B1%80%20OR%20%E4%BA%A4%E9%80%9A%E9%83%A8%20OR%20%E5%9C%8B%E6%97%85%E8%A3%9C%E5%8A%A9%20OR%20%E6%97%85%E5%AE%BF%29%20%28%E7%B6%B2%E7%AB%99%E7%95%B6%E6%A9%9F%20OR%20%E7%B6%B2%E7%AB%99%E7%95%B6%E6%8E%89%20OR%20%E7%B3%BB%E7%B5%B1%E7%95%B6%E6%A9%9F%20OR%20%E7%B3%BB%E7%B5%B1%E5%A1%9E%E7%88%86%20OR%20%E7%95%B6%E6%8E%89%20OR%20%E5%A1%9E%E7%88%86%20OR%20%E6%B5%81%E9%87%8F%E7%95%B0%E5%B8%B8%20OR%20%E6%B5%81%E9%87%8F%E6%9A%B4%E5%A2%9E%20OR%20%E7%B6%B2%E7%AB%99%E5%A3%85%E5%A1%9E%20OR%20%E6%9C%8D%E5%8B%99%E4%B8%AD%E6%96%B7%20OR%20%E7%94%B3%E8%AB%8B%E7%95%B0%E5%B8%B8%29&hl=zh-TW&gl=TW&ceid=TW:zh-Hant" },
  { source: "台灣觀光署英文", url: "https://eng.taiwan.net.tw/rss.aspx?sNo=0002001" },
  { source: "Skift", url: "https://skift.com/feed/" },
  { source: "BBC Travel", url: "https://news.google.com/rss/search?q=site%3Abbc.com%2Ftravel%20travel%20tourism&hl=en-US&gl=US&ceid=US:en" },
  { source: "Yahoo Travel", url: "https://news.google.com/rss/search?q=site%3Atravel.yahoo.com&hl=en-US&gl=US&ceid=US:en" },
  { source: "Google News／海外英文", url: "https://news.google.com/rss/search?q=travel%20tourism%20airlines%20hotels&hl=en-US&gl=US&ceid=US:en" },
  { source: "UN Tourism", url: "https://news.google.com/rss/search?q=site%3Auntourism.int%20%28tourism%20OR%20travel%29&hl=en-US&gl=US&ceid=US:en" },
  { source: "PATA", url: "https://news.google.com/rss/search?q=site%3Apata.org%20%28tourism%20OR%20travel%29&hl=en-US&gl=US&ceid=US:en" },
  { source: "WTTC", url: "https://news.google.com/rss/search?q=site%3Awttc.org%20%28tourism%20OR%20travel%29&hl=en-US&gl=US&ceid=US:en" },
  { source: "IAAPA", url: "https://news.google.com/rss/search?q=site%3Aiaapa.org%20%28attractions%20OR%20tourism%20OR%20travel%29&hl=en-US&gl=US&ceid=US:en" },
  { source: "OECD", url: "https://news.google.com/rss/search?q=site%3Aoecd.org%20%28tourism%20OR%20travel%29&hl=en-US&gl=US&ceid=US:en" },
  { source: "WEF", url: "https://news.google.com/rss/search?q=site%3Aweforum.org%20%28tourism%20OR%20travel%29&hl=en-US&gl=US&ceid=US:en" },
  { source: "日本觀光廳", url: "https://news.google.com/rss/search?q=site%3Amlit.go.jp%2Fkankocho%20%28%E8%A6%B3%E5%85%89%20OR%20%E6%97%85%E8%A1%8C%20OR%20%E8%A8%AA%E6%97%A5%29&hl=ja&gl=JP&ceid=JP%3Aja" },
  { source: "JNTO（日文）", url: "https://news.google.com/rss/search?q=site%3Ajnto.go.jp%20%28%E8%A6%B3%E5%85%89%20OR%20%E6%97%85%E8%A1%8C%20OR%20%E8%A8%AA%E6%97%A5%29&hl=ja&gl=JP&ceid=JP%3Aja" },
  { source: "JNTO（台灣）", url: "https://news.google.com/rss/search?q=site%3Ajapan.travel%2Ftw%20%28%E6%97%A5%E6%9C%AC%20OR%20%E6%97%85%E9%81%8A%20OR%20%E8%A7%80%E5%85%89%29&hl=zh-TW&gl=TW&ceid=TW%3Azh-Hant" },
  { source: "旅奇週刊", url: "https://news.google.com/rss/search?q=site%3Ab2b.travelrich.tw%20%28%E6%97%85%E9%81%8A%20OR%20%E8%A7%80%E5%85%89%20OR%20%E6%97%85%E5%AE%BF%20OR%20%E8%88%AA%E7%A9%BA%29&hl=zh-TW&gl=TW&ceid=TW%3Azh-Hant" },
  { source: "旅報", url: "https://news.google.com/rss/search?q=site%3Attnmedia.com%20%28%E6%97%85%E9%81%8A%20OR%20%E8%A7%80%E5%85%89%20OR%20%E6%97%85%E5%AE%BF%20OR%20%E8%88%AA%E7%A9%BA%29&hl=zh-TW&gl=TW&ceid=TW%3Azh-Hant" },
  { source: "旅奇傳媒", url: "https://news.google.com/rss/search?q=site%3Atromnimedia.com%20%28%E6%97%85%E9%81%8A%20OR%20%E8%A7%80%E5%85%89%20OR%20%E6%97%85%E5%AE%BF%20OR%20%E8%88%AA%E7%A9%BA%29&hl=zh-TW&gl=TW&ceid=TW%3Azh-Hant" },
] as const;

export type CatalogSourceSnapshot = {
  sourceKey: string;
  displayName: string;
  adapterKind: "rss" | "yahoo_category_html" | "required_article";
  endpointUrl: string;
  categoryHint?: string;
  language: "zh-Hant" | "en" | "ja";
  isRequired: boolean;
  isActive: boolean;
};

function sourceKey(adapterKind: CatalogSourceSnapshot["adapterKind"], displayName: string) {
  return `${adapterKind}:${createHash("sha256").update(displayName).digest("hex").slice(0, 16)}`;
}

function getLanguage(url: string): "zh-Hant" | "en" | "ja" {
  if (/(?:hl=ja|gl=JP|mlit\.go\.jp\/kankocho|jnto\.go\.jp)/i.test(url)) return "ja";
  return /(?:hl=en-|bbc\.com|skift\.com|travel\.yahoo\.com|taiwan\.net\.tw)/i.test(url) ? "en" : "zh-Hant";
}

/**
 * Converts the runtime-only catalog to persistence-safe source identities.
 * The source key is derived from adapter and label (not URL), so an endpoint
 * URL change keeps the same source history while each run retains its own URL snapshot.
 */
export function getCatalogSourceSnapshots(): CatalogSourceSnapshot[] {
  return [
    ...NEWS_FEEDS.map((feed) => ({
      sourceKey: sourceKey("rss", feed.source),
      displayName: feed.source,
      adapterKind: "rss" as const,
      endpointUrl: feed.url,
      language: getLanguage(feed.url),
      isRequired: false,
      isActive: true,
    })),
    ...YAHOO_TAIWAN_FUN_FEEDS.map((feed) => ({
      sourceKey: sourceKey("yahoo_category_html", feed.source),
      displayName: feed.source,
      adapterKind: "yahoo_category_html" as const,
      endpointUrl: feed.url,
      categoryHint: feed.category,
      language: "zh-Hant" as const,
      isRequired: true,
      isActive: true,
    })),
    ...REQUIRED_ARTICLES.map((article) => ({
      sourceKey: sourceKey("required_article", article.title),
      displayName: `${article.source}｜必收文章`,
      adapterKind: "required_article" as const,
      endpointUrl: article.url,
      language: getLanguage(article.url),
      isRequired: true,
      isActive: true,
    })),
  ];
}
