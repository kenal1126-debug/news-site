type SyncResult = { fetched: number; failedFeeds: string[]; cutoff: string };
type RecentItem = { source: string; title: string; imageUrl?: string | null; publishedAt: Date };

export async function runManualNewsSyncAudit(deps: {
  now: Date;
  syncNews: (now: Date) => Promise<SyncResult>;
  listRecentNews: (since: Date) => Promise<RecentItem[]>;
}) {
  const syncResult = await deps.syncNews(deps.now);
  const recent = await deps.listRecentNews(new Date(deps.now.getTime() - 14 * 24 * 60 * 60 * 1000));
  return { syncResult, recent };
}
