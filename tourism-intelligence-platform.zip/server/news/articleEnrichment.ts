function normalizeTitle(value: string) {
  return value.toLowerCase().replace(/[\s，。！？、：；「」『』（）()【】[\]…—–\-_:;,.!?/\\]+/g, "");
}

function decodeEntities(value: string) {
  return value.replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;/g, "'").trim();
}

function stripHtml(value: string) {
  return decodeEntities(value).replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();
}

function firstTag(item: string, tag: string) {
  const match = item.match(new RegExp(`<${tag}(?:\\s[^>]*)?>([\\s\\S]*?)</${tag}>`, "i"));
  return match?.[1] ? decodeEntities(match[1]) : "";
}

function extractItemImage(item: string) {
  return item.match(/<(?:media:content|media:thumbnail|enclosure)[^>]+\surl=["']([^"']+)["'][^>]*>/i)?.[1]
    || decodeEntities(firstTag(item, "description") || firstTag(item, "content:encoded")).match(/<img[^>]+(?:src|data-src)=["']([^"']+)["']/i)?.[1]
    || null;
}

export function findGoogleNewsMatch(xml: string, targetTitle: string) {
  const target = normalizeTitle(targetTitle);
  const targetTerms = targetTitle.split(/\s+/).map(normalizeTitle).filter((term) => term.length >= 2);
  const candidates = Array.from(xml.matchAll(/<item(?:\s[^>]*)?>([\s\S]*?)<\/item>/gi)).map((match) => match[1] ?? "").map((item) => {
    const title = stripHtml(firstTag(item, "title"));
    const normalized = normalizeTitle(title);
    const overlap = targetTerms.length === 0 ? 0 : targetTerms.filter((term) => normalized.includes(term)).length / targetTerms.length;
    return { title, url: firstTag(item, "link") || firstTag(item, "guid"), source: stripHtml(firstTag(item, "source")), imageUrl: extractItemImage(item), score: normalized.includes(target) || target.includes(normalized) ? 1 : overlap };
  });
  return candidates.find((candidate) => candidate.url && candidate.score >= 0.6) ?? null;
}

export async function extractArticleImage(url: string) {
  if (!url) return null;
  try {
    const response = await fetch(url, { headers: { "user-agent": "TourismIntelligencePlatform/1.0" }, redirect: "follow", signal: AbortSignal.timeout(6_000) });
    if (!response.ok) return null;
    const html = await response.text();
    const candidates = [
      html.match(/<meta[^>]+property=["']og:image["'][^>]+content=["']([^"']+)["']/i)?.[1],
      html.match(/<meta[^>]+content=["']([^"']+)["'][^>]+property=["']og:image["']/i)?.[1],
      html.match(/<meta[^>]+name=["']twitter:image["'][^>]+content=["']([^"']+)["']/i)?.[1],
      html.match(/<meta[^>]+content=["']([^"']+)["'][^>]+name=["']twitter:image["']/i)?.[1],
      html.match(/<article[\s\S]{0,12000}?<img[^>]+(?:src|data-src)=["']([^"']+)["']/i)?.[1],
    ].filter(Boolean) as string[];
    const candidate = candidates.find((value) => !/logo|icon|avatar|sprite|tracking/i.test(value));
    return candidate ? new URL(candidate, response.url || url).toString() : null;
  } catch {
    return null;
  }
}

async function decodeGoogleNewsUrl(url: string) {
  try {
    const parsed = new URL(url);
    const base64 = parsed.pathname.split("/").filter(Boolean).pop();
    if (!base64) return null;
    let signature = "";
    let timestamp = "";
    for (const pageUrl of [`https://news.google.com/articles/${base64}`, `https://news.google.com/rss/articles/${base64}`]) {
      const response = await fetch(pageUrl, { headers: { "user-agent": "Mozilla/5.0" }, signal: AbortSignal.timeout(8_000) });
      if (!response.ok) continue;
      const html = await response.text();
      signature = html.match(/data-n-a-sg=["']([^"']+)["']/i)?.[1] ?? "";
      timestamp = html.match(/data-n-a-ts=["']([^"']+)["']/i)?.[1] ?? "";
      if (signature && timestamp) break;
    }
    if (!signature || !timestamp) return null;
    const request = ["garturlreq", [["X", "X", ["X", "X"], null, null, 1, 1, "US:en", null, 1, null, null, null, null, null, 0, 1], "X", "X", 1, [1, 1, 1], 1, 1, null, 0, 0, null, 0], base64, Number(timestamp), signature];
    const response = await fetch("https://news.google.com/_/DotsSplashUi/data/batchexecute", { method: "POST", headers: { "content-type": "application/x-www-form-urlencoded;charset=UTF-8", "user-agent": "Mozilla/5.0" }, body: `f.req=${encodeURIComponent(JSON.stringify([["Fbv4je", JSON.stringify(request)]]))}`, signal: AbortSignal.timeout(8_000) });
    if (!response.ok) return null;
    const chunk = (await response.text()).split("\n\n")[1];
    if (!chunk) return null;
    const parsedResponse = JSON.parse(chunk.replace(/\n/g, "").replace(/\]$/, "]"));
    const decoded = JSON.parse(parsedResponse[0][2])[1];
    return typeof decoded === "string" && /^https?:\/\//.test(decoded) ? decoded : null;
  } catch {
    return null;
  }
}

export async function resolveOriginalUrl(url: string) {
  return url.startsWith("https://news.google.com/") ? await decodeGoogleNewsUrl(url) || url : url;
}

export async function searchGoogleNewsByTitle(title: string) {
  try {
    const response = await fetch(`https://news.google.com/rss/search?q=${encodeURIComponent(title)}&hl=zh-TW&gl=TW&ceid=TW:zh-Hant`, { headers: { "user-agent": "TourismIntelligencePlatform/1.0" }, signal: AbortSignal.timeout(8_000) });
    return response.ok ? findGoogleNewsMatch(await response.text(), title) : null;
  } catch {
    return null;
  }
}
