import type { InsertNewsItem } from "../../drizzle/schema";
import { extractArticleImage, resolveOriginalUrl, searchGoogleNewsByTitle } from "./articleEnrichment";
import { mapWithConcurrency } from "./concurrency";
import { FULL_FEED_SOURCES, getCatalogSourceSnapshots, NEWS_FEEDS, REQUIRED_ARTICLES, YAHOO_TAIWAN_FUN_FEEDS } from "./sourceCatalog";
import { FOURTEEN_DAYS_MS, parseRss, stripHtml } from "./rssParser";
import { runNewsSyncPipeline } from "./syncOrchestrator";
import { analyzeEnglishTrendKeywords, invalidateEnglishTrendKeywordCache } from "../englishKeywordNlp";
import { fetchYahooTaiwanArticleMetadata, parseYahooTaiwanCategoryHtml } from "./yahooTaiwanParser";
import { insertNewsItems, listRecentNews } from "../repositories/newsRepository";
import {
  completeNewsSyncRun,
  ensureNewsSourceSnapshots,
  normalizeErrorSummary,
  recordNewsSyncRunSources,
  startNewsSyncRun,
  upsertTourismServiceAlert,
} from "../repositories/operationsRepository";
import { classifyTourismServiceAlertSeverity, extractAffectedTourismService, isGovernmentTourismServiceDisruption } from "../../shared/tourismSignals";

const SOURCE_FETCH_TIMEOUT_MS = 12_000;
export const SYNC_SOURCE_CONCURRENCY = 3;
export const SYNC_ITEM_ENRICHMENT_CONCURRENCY = 16;
const TOURISM_SERVICE_ALERT_RULE_VERSION = "tourism-service-alert-v1";

type KeywordCloudRefreshDependencies = {
  invalidateCache: () => Promise<void>;
  listRecentNews: (cutoffAt: Date) => Promise<Array<{ source: string; title: string; summary: string | null }>>;
  analyze: (items: Array<{ source: string; title: string; summary: string | null }>) => Promise<unknown>;
};

export async function refreshNewsKeywordCloudsAfterSync(cutoffAt: Date, dependencies: KeywordCloudRefreshDependencies = {
  invalidateCache: invalidateEnglishTrendKeywordCache,
  listRecentNews,
  analyze: analyzeEnglishTrendKeywords,
}) {
  await dependencies.invalidateCache();
  const recentNews = await dependencies.listRecentNews(cutoffAt);
  await dependencies.analyze(recentNews.map((item) => ({ source: item.source, title: item.title, summary: item.summary })));
}

export type SyncRecentNewsOptions = {
  triggerKind?: "heartbeat" | "manual_audit" | "operations_replay";
  heartbeatTaskUid?: string;
};

async function fetchSourceDocument(url: string) {
  return fetch(url, { headers: { "user-agent": "TourismIntelligencePlatform/1.0" }, redirect: "follow", signal: AbortSignal.timeout(SOURCE_FETCH_TIMEOUT_MS) });
}

async function fetchRequiredArticle(article: (typeof REQUIRED_ARTICLES)[number], now: Date): Promise<InsertNewsItem | null> {
  if (article.publishedAt.getTime() < now.getTime() - FOURTEEN_DAYS_MS) return null;
  try {
    const response = await fetch(article.url, { headers: { "user-agent": "TourismIntelligencePlatform/1.0" }, redirect: "follow", signal: AbortSignal.timeout(8_000) });
    if (!response.ok) return null;
    const html = await response.text();
    const summary = html.match(/<meta[^>]+(?:name|property)=["'](?:description|og:description)["'][^>]+content=["']([^"']+)["']/i)?.[1] || html.match(/<meta[^>]+content=["']([^"']+)["'][^>]+(?:name|property)=["'](?:description|og:description)["']/i)?.[1] || "New global rankings reveal the best places to build a life abroad.";
    const imageUrl = html.match(/<meta[^>]+property=["']og:image["'][^>]+content=["']([^"']+)["']/i)?.[1] || html.match(/<meta[^>]+content=["']([^"']+)["'][^>]+property=["']og:image["']/i)?.[1] || null;
    return { source: article.source, title: article.title, url: article.url, guid: article.url, summary: stripHtml(summary).slice(0, 500), imageUrl: imageUrl ? new URL(imageUrl, article.url).toString() : null, publishedAt: article.publishedAt };
  } catch {
    return null;
  }
}

export async function syncRecentNews(now = new Date(), options: SyncRecentNewsOptions = {}) {
  const sourceSnapshots = getCatalogSourceSnapshots();
  const trackedSourceSnapshots = sourceSnapshots.filter(source => source.adapterKind !== "required_article");
  const sourceIds = await ensureNewsSourceSnapshots(sourceSnapshots);
  const cutoffAt = new Date(now.getTime() - FOURTEEN_DAYS_MS);
  const syncRunId = await startNewsSyncRun({
    triggerKind: options.triggerKind ?? "manual_audit",
    heartbeatTaskUid: options.heartbeatTaskUid,
    cutoffAt,
    sourceTotal: trackedSourceSnapshots.length,
  });
  const syncRssFeed = async (feed: (typeof NEWS_FEEDS)[number]) => {
    const startedAt = new Date();
    try {
      const response = await fetchSourceDocument(feed.url);
      if (!response.ok) return { items: [] as InsertNewsItem[], failure: `${feed.source}: HTTP ${response.status}`, httpStatus: response.status, startedAt, completedAt: new Date() };
      const parsed = parseRss(await response.text(), feed.source, FULL_FEED_SOURCES, now);
      const resolved = await mapWithConcurrency(parsed, SYNC_ITEM_ENRICHMENT_CONCURRENCY, async (item) => ({ ...item, url: await resolveOriginalUrl(item.url) }));
      const enriched = await mapWithConcurrency(resolved, SYNC_ITEM_ENRICHMENT_CONCURRENCY, async (item) => {
        let imageUrl = item.imageUrl || await extractArticleImage(item.url);
        let source = item.source;
        let articleUrl = item.url;
        if (!imageUrl && item.source !== "Yahoo Travel") {
          const match = await searchGoogleNewsByTitle(item.title);
          if (match) {
            source = match.source || source;
            articleUrl = await resolveOriginalUrl(match.url);
            imageUrl = match.imageUrl || await extractArticleImage(articleUrl) || await extractArticleImage(match.url) || imageUrl;
          }
        }
        return { ...item, source, url: articleUrl, imageUrl };
      });
      return { items: enriched, failure: null, httpStatus: response.status, startedAt, completedAt: new Date() };
    } catch (error) {
      return { items: [] as InsertNewsItem[], failure: `${feed.source}: ${String(error)}`, startedAt, completedAt: new Date() };
    }
  };

  const syncYahooFeed = async (feed: (typeof YAHOO_TAIWAN_FUN_FEEDS)[number]) => {
    const startedAt = new Date();
    try {
      const response = await fetchSourceDocument(feed.url);
      if (!response.ok) return { items: [] as InsertNewsItem[], failure: `${feed.source}: HTTP ${response.status}`, httpStatus: response.status, startedAt, completedAt: new Date() };
      const parsed = parseYahooTaiwanCategoryHtml(await response.text(), feed, now);
      const enriched = await mapWithConcurrency(parsed, SYNC_ITEM_ENRICHMENT_CONCURRENCY, async (item) => {
        const metadata = await fetchYahooTaiwanArticleMetadata(item.url);
        return { ...item, publishedAt: metadata.publishedAt || item.publishedAt, summary: metadata.summary || item.summary, imageUrl: metadata.imageUrl || item.imageUrl || await extractArticleImage(item.url) };
      });
      return { items: enriched.filter((item) => item.publishedAt.getTime() >= now.getTime() - FOURTEEN_DAYS_MS), failure: null, httpStatus: response.status, startedAt, completedAt: new Date() };
    } catch (error) {
      return { items: [] as InsertNewsItem[], failure: `${feed.source}: ${String(error)}`, startedAt, completedAt: new Date() };
    }
  };

  try {
    const result = await runNewsSyncPipeline({
      rssFeeds: NEWS_FEEDS,
      yahooFeeds: YAHOO_TAIWAN_FUN_FEEDS,
      requiredArticles: REQUIRED_ARTICLES,
      now,
      fourteenDaysMs: FOURTEEN_DAYS_MS,
      sourceConcurrency: SYNC_SOURCE_CONCURRENCY,
      itemConcurrency: SYNC_ITEM_ENRICHMENT_CONCURRENCY,
      mapConcurrent: mapWithConcurrency,
      syncRssFeed,
      syncYahooFeed,
      fetchRequiredArticle,
      insertItems: insertNewsItems,
      onSyncComplete: async () => {
        await refreshNewsKeywordCloudsAfterSync(cutoffAt);
      },
    });

    await recordNewsSyncRunSources(syncRunId, result.sourceBatches.flatMap((batch) => {
      const source = trackedSourceSnapshots.find(candidate => candidate.adapterKind === batch.adapterKind && candidate.displayName === batch.source);
      const newsSourceId = source ? sourceIds.get(source.sourceKey) : undefined;
      if (!newsSourceId) return [];
      return [{
        newsSourceId,
        endpointUrlSnapshot: batch.endpointUrl,
        status: batch.failure ? "failed" as const : "success" as const,
        httpStatus: batch.httpStatus ?? null,
        startedAt: batch.startedAt ?? now,
        completedAt: batch.completedAt ?? now,
        itemFetched: batch.items.length,
        itemAccepted: batch.items.length,
        errorSummary: normalizeErrorSummary(batch.failure),
      }];
    }));

    const failures = result.sourceBatches.filter(batch => Boolean(batch.failure));
    await completeNewsSyncRun(syncRunId, {
      status: failures.length === 0 ? "success" : failures.length === result.sourceBatches.length ? "failed" : "partial",
      completedAt: new Date(),
      sourceSucceeded: result.sourceBatches.length - failures.length,
      sourceFailed: failures.length,
      itemFetched: result.fetched,
      itemPersisted: result.fetched,
      errorSummary: failures.length ? normalizeErrorSummary(result.failedFeeds.join(" | ")) : null,
    });

    const recentNews = await listRecentNews(cutoffAt);
    const disruptionNews = recentNews.filter(item => isGovernmentTourismServiceDisruption({ title: item.title, summary: item.summary ?? "" }));
    await Promise.all(disruptionNews.map((item) => {
      const alertStory = { title: item.title, summary: item.summary ?? "" };
      const severity = classifyTourismServiceAlertSeverity(alertStory);
      return upsertTourismServiceAlert({
        newsItemId: item.id,
        syncRunId,
        severity: severity.level,
        affectedService: extractAffectedTourismService(alertStory),
        detectedAt: now,
        ruleVersion: TOURISM_SERVICE_ALERT_RULE_VERSION,
      });
    }));

    return { ...result, syncRunId };
  } catch (error) {
    await completeNewsSyncRun(syncRunId, {
      status: "failed",
      completedAt: new Date(),
      sourceSucceeded: 0,
      sourceFailed: 0,
      itemFetched: 0,
      itemPersisted: 0,
      errorSummary: normalizeErrorSummary(error),
    });
    throw error;
  }
}
