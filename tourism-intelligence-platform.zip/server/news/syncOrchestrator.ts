import type { InsertNewsItem } from "../../drizzle/schema";

export type SyncBatch = {
  items: InsertNewsItem[];
  failure: string | null;
  httpStatus?: number | null;
  startedAt?: Date;
  completedAt?: Date;
};

export type SyncSourceBatch = SyncBatch & {
  adapterKind: "rss" | "yahoo_category_html";
  source: string;
  endpointUrl: string;
};

type SyncOrchestratorDependencies<TFeed extends { source: string; url: string }, TYahooFeed extends { source: string; url: string }, TRequiredArticle> = {
  rssFeeds: readonly TFeed[];
  yahooFeeds: readonly TYahooFeed[];
  requiredArticles: readonly TRequiredArticle[];
  now: Date;
  fourteenDaysMs: number;
  sourceConcurrency: number;
  itemConcurrency: number;
  mapConcurrent: <T, R>(values: readonly T[], concurrency: number, worker: (value: T, index: number) => Promise<R>) => Promise<R[]>;
  syncRssFeed: (feed: TFeed) => Promise<SyncBatch>;
  syncYahooFeed: (feed: TYahooFeed) => Promise<SyncBatch>;
  fetchRequiredArticle: (article: TRequiredArticle, now: Date) => Promise<InsertNewsItem | null>;
  insertItems: (items: InsertNewsItem[]) => Promise<void>;
  onSyncComplete?: (items: InsertNewsItem[]) => Promise<void>;
};

export async function runNewsSyncPipeline<TFeed extends { source: string; url: string }, TYahooFeed extends { source: string; url: string }, TRequiredArticle>(deps: SyncOrchestratorDependencies<TFeed, TYahooFeed, TRequiredArticle>) {
  const [rssBatches, yahooBatches] = await Promise.all([
    deps.mapConcurrent(deps.rssFeeds, deps.sourceConcurrency, async (feed) => ({ feed, batch: await deps.syncRssFeed(feed) })),
    deps.mapConcurrent(deps.yahooFeeds, deps.sourceConcurrency, async (feed) => ({ feed, batch: await deps.syncYahooFeed(feed) })),
  ]);
  const sourceBatches: SyncSourceBatch[] = [
    ...rssBatches.map(({ feed, batch }) => ({ ...batch, adapterKind: "rss" as const, source: feed.source, endpointUrl: feed.url })),
    ...yahooBatches.map(({ feed, batch }) => ({ ...batch, adapterKind: "yahoo_category_html" as const, source: feed.source, endpointUrl: feed.url })),
  ];
  const collected: InsertNewsItem[] = [];
  const failedFeeds: string[] = [];
  for (const batch of sourceBatches) {
    collected.push(...batch.items);
    if (batch.failure) failedFeeds.push(batch.failure);
  }
  const required = await Promise.all(deps.requiredArticles.map((article) => deps.fetchRequiredArticle(article, deps.now)));
  collected.push(...required.filter((item): item is InsertNewsItem => Boolean(item)));
  await deps.insertItems(collected);
  await deps.onSyncComplete?.(collected);
  return {
    fetched: collected.length,
    failedFeeds,
    cutoff: new Date(deps.now.getTime() - deps.fourteenDaysMs).toISOString(),
    sourceBatches,
  };
}
