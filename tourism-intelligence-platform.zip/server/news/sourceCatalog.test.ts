import { describe, expect, it } from "vitest";
import { NEWS_FEEDS, getCatalogSourceSnapshots } from "./sourceCatalog";

const EXPECTED_OFFICIAL_SOURCES = [
  "UN Tourism",
  "PATA",
  "WTTC",
  "IAAPA",
  "OECD",
  "WEF",
  "日本觀光廳",
  "JNTO（日文）",
  "JNTO（台灣）",
];

const EXPECTED_INDUSTRY_MEDIA_SOURCES = ["旅奇週刊", "旅報", "旅奇傳媒"];

describe("official tourism source catalog", () => {
  it("registers every requested global and Japan official source as a site-limited public feed", () => {
    for (const source of EXPECTED_OFFICIAL_SOURCES) {
      const feed = NEWS_FEEDS.find((candidate) => candidate.source === source);
      expect(feed?.url).toContain("news.google.com/rss/search");
      expect(feed?.url).toContain("site%3A");
    }
  });

  it("keeps official sources in the persisted source snapshot catalog", () => {
    const names = new Set(getCatalogSourceSnapshots().map((source) => source.displayName));
    expect(EXPECTED_OFFICIAL_SOURCES.every((source) => names.has(source))).toBe(true);
  });

  it("labels Japan official sources with their actual publication language", () => {
    const snapshots = getCatalogSourceSnapshots();
    expect(snapshots.find((source) => source.displayName === "日本觀光廳")?.language).toBe("ja");
    expect(snapshots.find((source) => source.displayName === "JNTO（日文）")?.language).toBe("ja");
    expect(snapshots.find((source) => source.displayName === "JNTO（台灣）")?.language).toBe("zh-Hant");
  });

  it("registers the approved Taiwan travel industry media as site-limited sources", () => {
    for (const source of EXPECTED_INDUSTRY_MEDIA_SOURCES) {
      expect(NEWS_FEEDS.find((candidate) => candidate.source === source)?.url).toContain("news.google.com/rss/search");
    }
  });
});
