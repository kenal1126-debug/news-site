import { describe, expect, it, vi } from "vitest";
import { registerScheduledNewsSyncRoute } from "./scheduledSyncRoute";

function responseRecorder() {
  const calls: Array<{ status: number; body: unknown }> = [];
  let status = 200;
  const response = { status: (code: number) => { status = code; return response; }, json: (body: unknown) => { calls.push({ status, body }); return body; } };
  return { response, calls };
}

describe("scheduled sync route mounting", () => {
  it("mounts the production callback path and runs the feed sync service for cron callers", async () => {
    let mountedPath = "";
    let mountedHandler: ((req: { originalUrl?: string }, res: ReturnType<typeof responseRecorder>["response"]) => Promise<unknown>) | undefined;
    const app = { post: vi.fn((path, handler) => { mountedPath = path; mountedHandler = handler; }) };
    const syncNews = vi.fn().mockResolvedValue({ fetched: 7, failedFeeds: [], cutoff: "2026-08-07T00:00:00.000Z" });
    registerScheduledNewsSyncRoute(app, { authenticate: vi.fn().mockResolvedValue({ isCron: true, taskUid: "cron-news" }), syncNews });
    expect(mountedPath).toBe("/api/scheduled/sync-news");
    const { response, calls } = responseRecorder();
    await mountedHandler!({ originalUrl: mountedPath }, response);
    expect(syncNews).toHaveBeenCalledOnce();
    expect(calls).toEqual([{ status: 200, body: { ok: true, fetched: 7, failedFeeds: [], cutoff: "2026-08-07T00:00:00.000Z" } }]);
  });

  it("keeps 403 and 500 responses on the mounted callback", async () => {
    let handler: ((req: { originalUrl?: string }, res: ReturnType<typeof responseRecorder>["response"]) => Promise<unknown>) | undefined;
    const app = { post: vi.fn((_path, mountedHandler) => { handler = mountedHandler; }) };
    registerScheduledNewsSyncRoute(app, { authenticate: vi.fn().mockResolvedValue({ isCron: false }), syncNews: vi.fn() });
    const denied = responseRecorder();
    await handler!({ originalUrl: "/api/scheduled/sync-news" }, denied.response);
    expect(denied.calls).toEqual([{ status: 403, body: { error: "cron-only" } }]);

    registerScheduledNewsSyncRoute(app, { authenticate: vi.fn().mockResolvedValue({ isCron: true, taskUid: "cron-news" }), syncNews: vi.fn().mockRejectedValue(new Error("upstream timeout")), now: () => new Date("2026-08-21T00:00:00.000Z") });
    const failed = responseRecorder();
    await handler!({ originalUrl: "/api/scheduled/sync-news" }, failed.response);
    expect(failed.calls[0]).toMatchObject({ status: 500, body: { error: "Error: upstream timeout", context: { url: "/api/scheduled/sync-news" } } });
  });
});
