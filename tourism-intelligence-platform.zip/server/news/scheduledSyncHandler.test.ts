import { describe, expect, it, vi } from "vitest";
import { createScheduledNewsSyncHandler } from "./scheduledSyncHandler";

function responseRecorder() {
  const calls: Array<{ status: number; body: unknown }> = [];
  let status = 200;
  const response = { status: (code: number) => { status = code; return response; }, json: (body: unknown) => { calls.push({ status, body }); return body; } };
  return { response, calls };
}

describe("scheduled news sync handler", () => {
  it("runs the injected new sync service for an authenticated cron request", async () => {
    const syncNews = vi.fn().mockResolvedValue({ fetched: 12, failedFeeds: [], cutoff: "2026-08-07T00:00:00.000Z" });
    const handler = createScheduledNewsSyncHandler({ authenticate: vi.fn().mockResolvedValue({ isCron: true, taskUid: "cron-news" }), syncNews });
    const { response, calls } = responseRecorder();
    await handler({ originalUrl: "/api/scheduled/sync-news" }, response);
    expect(syncNews).toHaveBeenCalledOnce();
    expect(syncNews).toHaveBeenCalledWith({ triggerKind: "heartbeat", heartbeatTaskUid: "cron-news" });
    expect(calls).toEqual([{ status: 200, body: { ok: true, fetched: 12, failedFeeds: [], cutoff: "2026-08-07T00:00:00.000Z" } }]);
  });

  it("rejects non-cron callers and returns diagnosable errors", async () => {
    const syncNews = vi.fn();
    const handler = createScheduledNewsSyncHandler({ authenticate: vi.fn().mockResolvedValue({ isCron: false }), syncNews, now: () => new Date("2026-08-21T00:00:00.000Z") });
    const { response, calls } = responseRecorder();
    await handler({ originalUrl: "/api/scheduled/sync-news" }, response);
    expect(syncNews).not.toHaveBeenCalled();
    expect(calls).toEqual([{ status: 403, body: { error: "cron-only" } }]);
  });

  it("returns a 500 diagnostic payload when the sync service throws", async () => {
    const handler = createScheduledNewsSyncHandler({ authenticate: vi.fn().mockResolvedValue({ isCron: true, taskUid: "cron-news" }), syncNews: vi.fn().mockRejectedValue(new Error("sync unavailable")), now: () => new Date("2026-08-21T00:00:00.000Z") });
    const { response, calls } = responseRecorder();
    await handler({ originalUrl: "/api/scheduled/sync-news" }, response);
    expect(calls).toEqual([{ status: 500, body: { error: "Error: sync unavailable", context: { url: "/api/scheduled/sync-news" }, timestamp: "2026-08-21T00:00:00.000Z" } }]);
  });
});
