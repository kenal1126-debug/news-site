import { describe, expect, it } from "vitest";
import { runNewsSyncPipeline } from "./syncOrchestrator";

describe("news sync pipeline", () => {
  it("runs the post-sync refresh only after news persistence completes", async () => {
    const events: string[] = [];
    const now = new Date("2026-08-30T00:00:00Z");
    await runNewsSyncPipeline({
      rssFeeds: [{ source: "RSS", url: "https://example.com/rss" }],
      yahooFeeds: [],
      requiredArticles: [],
      now,
      fourteenDaysMs: 14 * 24 * 60 * 60 * 1000,
      sourceConcurrency: 1,
      itemConcurrency: 1,
      mapConcurrent: async (values, _concurrency, worker) => Promise.all(values.map(worker)),
      syncRssFeed: async () => ({ items: [{ source: "RSS", title: "Flight route", url: "https://example.com/1", guid: "1", summary: "Route update", imageUrl: null, publishedAt: now }], failure: null }),
      syncYahooFeed: async () => ({ items: [], failure: null }),
      fetchRequiredArticle: async () => null,
      insertItems: async () => { events.push("persisted"); },
      onSyncComplete: async () => { events.push("refreshed"); },
    });
    expect(events).toEqual(["persisted", "refreshed"]);
  });
});
