import { describe, expect, it, vi } from "vitest";
import { runManualNewsSyncAudit } from "./manualSyncAudit";

describe("manual sync audit", () => {
  it("runs the sync facade then reads recent records from the news repository", async () => {
    const now = new Date("2026-08-21T00:00:00.000Z");
    const syncNews = vi.fn().mockResolvedValue({ fetched: 5, failedFeeds: [], cutoff: "2026-08-07T00:00:00.000Z" });
    const listRecentNews = vi.fn().mockResolvedValue([{ source: "TVBS新聞網", title: "旅遊服務訊號", imageUrl: "https://example.com/image.jpg", publishedAt: now }]);
    const result = await runManualNewsSyncAudit({ now, syncNews, listRecentNews });
    expect(syncNews).toHaveBeenCalledWith(now);
    expect(listRecentNews).toHaveBeenCalledWith(new Date("2026-08-07T00:00:00.000Z"));
    expect(result.syncResult.fetched).toBe(5);
    expect(result.recent).toHaveLength(1);
  });
});
