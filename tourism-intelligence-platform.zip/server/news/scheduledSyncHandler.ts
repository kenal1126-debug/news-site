type CronUser = { isCron?: boolean; taskUid?: string };
type RequestLike = { originalUrl?: string };
type ResponseLike = { status: (code: number) => ResponseLike; json: (body: unknown) => unknown };
type SyncOptions = { triggerKind: "heartbeat"; heartbeatTaskUid: string };

export function createScheduledNewsSyncHandler(deps: {
  authenticate: (request: RequestLike) => Promise<CronUser>;
  syncNews: (options: SyncOptions) => Promise<{ fetched: number; failedFeeds: string[]; cutoff: string }>;
  now?: () => Date;
}) {
  return async (req: RequestLike, res: ResponseLike) => {
    try {
      const user = await deps.authenticate(req);
      if (!user.isCron || !user.taskUid) return res.status(403).json({ error: "cron-only" });
      return res.json({ ok: true, ...(await deps.syncNews({ triggerKind: "heartbeat", heartbeatTaskUid: user.taskUid })) });
    } catch (error) {
      return res.status(500).json({ error: String(error), context: { url: req.originalUrl }, timestamp: (deps.now ?? (() => new Date()))().toISOString() });
    }
  };
}
