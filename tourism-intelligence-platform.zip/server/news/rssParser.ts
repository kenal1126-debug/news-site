import type { InsertNewsItem } from "../../drizzle/schema";
import { isTourismRelated } from "../../shared/tourismTopics";
import { decodeHtmlEntities, normalizeHtmlText } from "../../shared/textNormalization";

export const FOURTEEN_DAYS_MS = 14 * 24 * 60 * 60 * 1000;

export function decodeEntities(value: string) { return decodeHtmlEntities(value).trim(); }
export function stripHtml(value: string) { return normalizeHtmlText(value); }
export function firstTag(item: string, tag: string) { const match = item.match(new RegExp(`<${tag}(?:\\s[^>]*)?>([\\s\\S]*?)</${tag}>`, "i")); return match?.[1] ? decodeEntities(match[1]) : ""; }
export function firstAttribute(item: string, tag: string, attribute: string) { return item.match(new RegExp(`<${tag}[^>]*\\s${attribute}=["']([^"']+)["'][^>]*>`, "i"))?.[1] ?? ""; }
export function extractImageUrl(item: string, summaryRaw: string) { const structuredImage = firstAttribute(item, "media:content", "url") || firstAttribute(item, "media:thumbnail", "url") || firstAttribute(item, "enclosure", "url"); if (structuredImage) return structuredImage; return decodeEntities(summaryRaw).match(/<img[^>]+(?:src|data-src)=["']([^"']+)["']/i)?.[1] ?? ""; }

export function parseRss(xml: string, source: string, fullFeedSources: ReadonlySet<string>, now = new Date()): InsertNewsItem[] {
  const since = now.getTime() - FOURTEEN_DAYS_MS;
  return Array.from(xml.matchAll(/<item(?:\s[^>]*)?>([\s\S]*?)<\/item>/gi)).map((match) => match[1] ?? "").map((item) => {
    const title = stripHtml(firstTag(item, "title"));
    const url = firstTag(item, "link") || firstTag(item, "guid");
    const guid = firstTag(item, "guid") || url;
    const originalSource = stripHtml(firstTag(item, "source"));
    const summaryRaw = firstTag(item, "description") || firstTag(item, "content:encoded");
    const publishedAt = new Date(firstTag(item, "pubDate") || firstTag(item, "dc:date") || now.toISOString());
    return { source: source.startsWith("Google News") ? originalSource || source : source, title, url, guid, summary: stripHtml(summaryRaw).slice(0, 500), imageUrl: extractImageUrl(item, summaryRaw) || null, publishedAt };
  }).filter((item) => item.title && item.url && item.guid && (fullFeedSources.has(source) || isTourismRelated(`${item.title} ${item.summary ?? ""}`, source)) && !Number.isNaN(item.publishedAt.getTime()) && item.publishedAt.getTime() >= since);
}
