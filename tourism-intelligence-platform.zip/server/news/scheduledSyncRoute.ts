import { createScheduledNewsSyncHandler } from "./scheduledSyncHandler";

type AppLike = { post: (path: string, handler: ReturnType<typeof createScheduledNewsSyncHandler>) => unknown };

export function registerScheduledNewsSyncRoute(app: AppLike, deps: Parameters<typeof createScheduledNewsSyncHandler>[0]) {
  app.post("/api/scheduled/sync-news", createScheduledNewsSyncHandler(deps));
}
