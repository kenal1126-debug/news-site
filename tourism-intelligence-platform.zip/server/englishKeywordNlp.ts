import { buildNewsKeywordClouds, classifyNewsKeywordLanguage, type NewsKeywordCloudItem, type NewsKeywordCloudTerm } from "../shared/newsKeywordCloud";
import { invokeLLM } from "./_core/llm";
import { ENGLISH_KEYWORD_CACHE_NAMESPACE, getInsightCacheEntry, hashTraceabilityInput, invalidateInsightCacheNamespace, putInsightCacheEntry } from "./repositories/operationsRepository";

type EnglishKeywordAnalysis = {
  terms: string[];
  analyzedAt: number;
  usedNlp: boolean;
};

const CACHE_TTL_MS = 6 * 60 * 60 * 1000;
const NLP_PROMPT_VERSION = "english-keyword-pos-v2-context";
const MAX_SELECTED_TERMS = 18;
let cachedAnalysis: { key: string; value: EnglishKeywordAnalysis } | undefined;

export async function invalidateEnglishTrendKeywordCache() {
  cachedAnalysis = undefined;
  await invalidateInsightCacheNamespace(ENGLISH_KEYWORD_CACHE_NAMESPACE);
}

export function selectEnglishTrendTerms(candidates: NewsKeywordCloudTerm[], taggedTerms: string[]) {
  const allowed = new Set(taggedTerms.map(term => term.trim().toLowerCase()));
  return candidates.filter(candidate => allowed.has(candidate.term.toLowerCase())).slice(0, MAX_SELECTED_TERMS);
}

function getEnglishCandidates(items: NewsKeywordCloudItem[]) {
  return buildNewsKeywordClouds(items, 80).find(cloud => cloud.language === "英文")?.terms ?? [];
}

function getEnglishNewsContext(items: NewsKeywordCloudItem[]) {
  return items
    .filter(item => classifyNewsKeywordLanguage(item) === "英文")
    .slice(0, 40)
    .map(item => `- ${item.title.replace(/\s+/g, " ").trim()} :: ${(item.summary ?? "").replace(/\s+/g, " ").trim().slice(0, 220)}`)
    .join("\n");
}

function getCacheKey(candidates: NewsKeywordCloudTerm[], context: string) {
  return `${NLP_PROMPT_VERSION}|${candidates.map(candidate => `${candidate.term}:${candidate.count}`).join("|")}|${context}`;
}

function parsePersistedAnalysis(payload: unknown): EnglishKeywordAnalysis | undefined {
  if (!payload || typeof payload !== "object") return undefined;
  const candidate = payload as Partial<EnglishKeywordAnalysis>;
  if (!Array.isArray(candidate.terms) || !candidate.terms.every(term => typeof term === "string")) return undefined;
  if (typeof candidate.analyzedAt !== "number" || typeof candidate.usedNlp !== "boolean") return undefined;
  return { terms: candidate.terms, analyzedAt: candidate.analyzedAt, usedNlp: candidate.usedNlp };
}

export async function analyzeEnglishTrendKeywords(items: NewsKeywordCloudItem[]): Promise<EnglishKeywordAnalysis> {
  const candidates = getEnglishCandidates(items);
  const fallback: EnglishKeywordAnalysis = {
    terms: candidates.slice(0, MAX_SELECTED_TERMS).map(candidate => candidate.term),
    analyzedAt: Date.now(),
    usedNlp: false,
  };
  if (candidates.length === 0) return fallback;

  const context = getEnglishNewsContext(items);
  const key = getCacheKey(candidates, context);
  if (cachedAnalysis?.key === key && cachedAnalysis.value.analyzedAt + CACHE_TTL_MS > Date.now()) {
    return cachedAnalysis.value;
  }
  const cacheKeyHash = hashTraceabilityInput(key);
  const persisted = await getInsightCacheEntry(ENGLISH_KEYWORD_CACHE_NAMESPACE, cacheKeyHash);
  const persistedValue = parsePersistedAnalysis(persisted?.payloadJson);
  if (persistedValue) {
    cachedAnalysis = { key, value: persistedValue };
    return persistedValue;
  }

  try {
    const response = await invokeLLM({
      model: "gpt-5-mini",
      messages: [
        {
          role: "system",
          content: "You are a precise English tourism-industry NLP tagger. Select at most 18 terms and only admit a common noun, proper noun, or concrete action verb that is supported by the supplied news context and directly conveys a tourism market, destination asset, accommodation, airline, transport, event, demand, supply, booking, route, price, consumer, or policy trend. Exclude every adjective, adverb, pronoun, determiner, question word, preposition, color, spatial or temporal word, generic storytelling word, media or brand name, and tourism or travel generic term. Do not return a term merely because it appears in a destination-feature story. You must only return terms from the candidate list.",
        },
        {
          role: "user",
          content: `Candidate terms ranked by frequency:\n${candidates.map(candidate => `${candidate.term} (${candidate.count})`).join(", ")}\n\nRecent English news context:\n${context}`,
        },
      ],
      response_format: {
        type: "json_schema",
        json_schema: {
          name: "english_trend_terms",
          strict: true,
          schema: {
            type: "object",
            properties: {
              terms: { type: "array", items: { type: "string" } },
            },
            required: ["terms"],
            additionalProperties: false,
          },
        },
      },
    });
    const content = response.choices[0]?.message.content;
    const parsed = typeof content === "string" ? JSON.parse(content) as { terms?: unknown } : undefined;
    const taggedTerms = Array.isArray(parsed?.terms) ? parsed.terms.filter((term): term is string => typeof term === "string") : [];
    const selected = selectEnglishTrendTerms(candidates, taggedTerms);
    if (selected.length === 0) {
      console.warn("[English keyword NLP] No candidate terms returned by NLP; falling back to deterministic terms", { content, taggedTerms });
      return fallback;
    }

    const value: EnglishKeywordAnalysis = {
      terms: selected.map(term => term.term),
      analyzedAt: Date.now(),
      usedNlp: true,
    };
    cachedAnalysis = { key, value };
    await putInsightCacheEntry({
      cacheNamespace: ENGLISH_KEYWORD_CACHE_NAMESPACE,
      cacheKeyHash,
      inputFingerprint: hashTraceabilityInput(`${candidates.map(candidate => `${candidate.term}:${candidate.count}`).join("|")}|${context}`),
      payloadJson: value,
      promptVersion: NLP_PROMPT_VERSION,
      model: "gpt-5-mini",
      expiresAt: new Date(Date.now() + CACHE_TTL_MS),
    });
    return value;
  } catch (error) {
    console.warn("[English keyword NLP] Falling back to deterministic keyword rules:", error instanceof Error ? error.message : error);
    return fallback;
  }
}
