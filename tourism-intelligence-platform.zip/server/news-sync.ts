import { extractArticleImage, findGoogleNewsMatch, resolveOriginalUrl, searchGoogleNewsByTitle } from "./news/articleEnrichment";
import { mapWithConcurrency } from "./news/concurrency";
import { NEWS_FEEDS, FULL_FEED_SOURCES, REQUIRED_ARTICLES, YAHOO_TAIWAN_FUN_FEEDS } from "./news/sourceCatalog";
import { SYNC_ITEM_ENRICHMENT_CONCURRENCY, SYNC_SOURCE_CONCURRENCY, syncRecentNews } from "./news/feedSyncService";
import { parseRss as parseRssCore } from "./news/rssParser";
import { parseYahooTaiwanCategoryHtml } from "./news/yahooTaiwanParser";

// Compatibility facade for the Heartbeat endpoint, audit script, and current tests.
// All implementation lives under server/news/; new callers should import that layer directly.
export { extractArticleImage, findGoogleNewsMatch, mapWithConcurrency, NEWS_FEEDS, REQUIRED_ARTICLES, resolveOriginalUrl, searchGoogleNewsByTitle, SYNC_ITEM_ENRICHMENT_CONCURRENCY, SYNC_SOURCE_CONCURRENCY, syncRecentNews, YAHOO_TAIWAN_FUN_FEEDS, parseYahooTaiwanCategoryHtml };

export function parseRss(xml: string, source: string, now = new Date()) {
  return parseRssCore(xml, source, FULL_FEED_SOURCES, now);
}
