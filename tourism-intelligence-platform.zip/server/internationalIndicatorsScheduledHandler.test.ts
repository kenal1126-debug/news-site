import { describe, expect, it, vi } from "vitest";
import { createInternationalIndicatorsScheduledHandler } from "./internationalIndicatorsScheduledHandler";

function responseSpy() {
  const json = vi.fn();
  const status = vi.fn().mockReturnValue({ json });
  return { response: { status, json }, status, json };
}

describe("international indicator scheduled handler", () => {
  it("runs an authenticated cron refresh with the Heartbeat task UID", async () => {
    const refresh = vi.fn().mockResolvedValue({ runStatus: "success", observationsPersisted: 2 });
    const handler = createInternationalIndicatorsScheduledHandler({ authenticate: vi.fn().mockResolvedValue({ isCron: true, taskUid: "indicator-task" }), refresh });
    const { response, json } = responseSpy();
    await handler({ originalUrl: "/api/scheduled/refresh-international-indicators" }, response);
    expect(refresh).toHaveBeenCalledWith({ triggerKind: "heartbeat", heartbeatTaskUid: "indicator-task" });
    expect(json).toHaveBeenCalledWith({ ok: true, runStatus: "success", observationsPersisted: 2 });
  });

  it("rejects a non-cron caller without starting a refresh", async () => {
    const refresh = vi.fn();
    const handler = createInternationalIndicatorsScheduledHandler({ authenticate: vi.fn().mockResolvedValue({ isCron: false }), refresh });
    const { response, status, json } = responseSpy();
    await handler({}, response);
    expect(status).toHaveBeenCalledWith(403);
    expect(json).toHaveBeenCalledWith({ error: "cron-only" });
    expect(refresh).not.toHaveBeenCalled();
  });
});
