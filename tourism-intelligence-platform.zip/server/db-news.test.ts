import { describe, expect, it } from "vitest";
import { chunkNewsItemsForPersistence, collapseNewsItemsForPersistence, NEWS_GUID_MAX_LENGTH, NEWS_UPSERT_BATCH_SIZE, normalizeNewsGuidForPersistence, normalizeNewsItemsForPersistence, PRESERVE_IMAGE_ON_DUPLICATE_SQL, preserveExistingImageUrl } from "./repositories/newsRepository";

describe("news persistence", () => {
  it("preserves an existing image when a duplicate incoming row has no image", () => {
    expect(preserveExistingImageUrl("https://example.com/old.jpg", null)).toBe("https://example.com/old.jpg");
    expect(preserveExistingImageUrl("https://example.com/old.jpg", "")).toBe("https://example.com/old.jpg");
    expect(PRESERVE_IMAGE_ON_DUPLICATE_SQL).toBe("COALESCE(VALUES(imageUrl), imageUrl)");
  });

  it("accepts a newly discovered image for a duplicate row", () => {
    expect(preserveExistingImageUrl("https://example.com/old.jpg", "https://example.com/new.jpg")).toBe("https://example.com/new.jpg");
    expect(preserveExistingImageUrl(null, "https://example.com/new.jpg")).toBe("https://example.com/new.jpg");
  });

  it("collapses same-title rows and keeps the row with an image", () => {
    const result = collapseNewsItemsForPersistence([
      { source: "經濟日報", title: "數位產業署舉辦 AI DEMO DAY 促成觀光旅宿產業交流媒合", summary: "同一則新聞", url: "https://money.udn.com/no-image", guid: "guid-a", imageUrl: null, publishedAt: new Date("2026-08-14T08:00:00Z") },
      { source: "經濟日報", title: "數位產業署舉辦 AI DEMO DAY 促成觀光旅宿產業交流媒合 - 經濟日報", summary: "同一則新聞完整摘要", url: "https://money.udn.com/with-image", guid: "guid-b", imageUrl: "https://money.udn.com/article.jpg", publishedAt: new Date("2026-08-14T08:00:00Z") },
    ]);
    expect(result).toHaveLength(1);
    expect(result[0].imageUrl).toBe("https://money.udn.com/article.jpg");
    expect(result[0].url).toBe("https://money.udn.com/with-image");
  });

  it("splits persisted news into bounded batches for scheduled writes", () => {
    const items = [
      { source: "測試", title: "新聞一", summary: null, url: "https://example.com/1", guid: "1", imageUrl: null, publishedAt: new Date("2026-08-18T00:00:00Z") },
      { source: "測試", title: "新聞二", summary: null, url: "https://example.com/2", guid: "2", imageUrl: null, publishedAt: new Date("2026-08-18T00:00:00Z") },
      { source: "測試", title: "新聞三", summary: null, url: "https://example.com/3", guid: "3", imageUrl: null, publishedAt: new Date("2026-08-18T00:00:00Z") },
    ];
    expect(chunkNewsItemsForPersistence(items, 2).map((batch) => batch.map((item) => item.guid))).toEqual([["1", "2"], ["3"]]);
    expect(NEWS_UPSERT_BATCH_SIZE).toBe(50);
  });

  it("hashes only overlong source GUIDs so a single RSS item cannot abort a batch", () => {
    const sourceGuid = `google-news-${"a".repeat(600)}`;
    const normalized = normalizeNewsGuidForPersistence(sourceGuid);
    expect(normalized).toMatch(/^sha256:[a-f0-9]{64}$/);
    expect(normalized.length).toBeLessThanOrEqual(NEWS_GUID_MAX_LENGTH);
    expect(normalizeNewsGuidForPersistence(sourceGuid)).toBe(normalized);
    expect(normalizeNewsGuidForPersistence("short-guid")).toBe("short-guid");

    const items = normalizeNewsItemsForPersistence([
      { source: "Google News", title: "測試新聞", summary: null, url: "https://example.com/guid", guid: sourceGuid, imageUrl: null, publishedAt: new Date("2026-08-19T00:00:00Z") },
    ]);
    expect(items[0].guid).toBe(normalized);
  });
});
