import { describe, expect, it, vi } from "vitest";
import { extractArticleImage, findGoogleNewsMatch, mapWithConcurrency, NEWS_FEEDS, parseRss, parseYahooTaiwanCategoryHtml, resolveOriginalUrl, SYNC_ITEM_ENRICHMENT_CONCURRENCY, SYNC_SOURCE_CONCURRENCY, YAHOO_TAIWAN_FUN_FEEDS } from "./news-sync";

describe("news sync RSS parsing", () => {
  it("limits concurrent source work while preserving source order", async () => {
    let active = 0;
    let peakActive = 0;
    const values = await mapWithConcurrency([1, 2, 3, 4], 2, async (value) => {
      active += 1;
      peakActive = Math.max(peakActive, active);
      await Promise.resolve();
      active -= 1;
      return value * 10;
    });
    expect(values).toEqual([10, 20, 30, 40]);
    expect(peakActive).toBeLessThanOrEqual(2);
    expect(SYNC_SOURCE_CONCURRENCY).toBe(3);
    expect(SYNC_ITEM_ENRICHMENT_CONCURRENCY).toBe(16);
  });

  it("parses recent items and keeps the article image", () => {
    const now = new Date("2026-08-14T00:00:00Z");
    const xml = `<rss><channel><item><title><![CDATA[觀光需求回升]]></title><link>https://example.com/story</link><guid>story-1</guid><pubDate>Thu, 13 Aug 2026 10:00:00 GMT</pubDate><description><![CDATA[旅遊需求摘要]]></description><media:content url="https://example.com/image.jpg" /></item></channel></rss>`;
    const items = parseRss(xml, "測試來源", now);
    expect(items).toHaveLength(1);
    expect(items[0]).toMatchObject({ title: "觀光需求回升", url: "https://example.com/story", imageUrl: "https://example.com/image.jpg", source: "測試來源" });
  });

  it("keeps the original media source published by Google News RSS", () => {
    const now = new Date("2026-08-18T00:00:00Z");
    const xml = `<rss><channel><item><title>旅宿市場需求回升</title><link>https://news.google.com/rss/articles/example</link><guid>google-news-1</guid><source url="https://money.udn.com">經濟日報</source><pubDate>Mon, 17 Aug 2026 10:00:00 GMT</pubDate><description>飯店與旅宿市場觀光需求摘要</description></item></channel></rss>`;
    expect(parseRss(xml, "Google News／主要媒體", now)[0]).toMatchObject({ source: "經濟日報", url: "https://news.google.com/rss/articles/example" });
  });

  it("requires BBC Travel as an enabled English source and keeps its tourism stories", () => {
    expect(NEWS_FEEDS).toContainEqual({
      source: "BBC Travel",
      url: "https://news.google.com/rss/search?q=site%3Abbc.com%2Ftravel%20travel%20tourism&hl=en-US&gl=US&ceid=US:en",
    });
    const now = new Date("2026-08-14T00:00:00Z");
    const xml = `<rss><channel><item><title>How tourism is changing the way travellers experience destinations</title><link>https://www.bbc.com/travel/article/example</link><guid>bbc-travel-1</guid><pubDate>Thu, 13 Aug 2026 10:00:00 GMT</pubDate><description>Travelers are discovering a destination through local food and sustainable tourism.</description></item></channel></rss>`;
    expect(parseRss(xml, "BBC Travel", now)).toHaveLength(1);
  });

  it("requires all five Yahoo Taiwan Fun category pages as mandatory sources", () => {
    expect(YAHOO_TAIWAN_FUN_FEEDS.map((feed) => feed.url)).toEqual([
      "https://tw.news.yahoo.com/tourist-spots/",
      "https://tw.news.yahoo.com/food/",
      "https://tw.news.yahoo.com/travel-abroad/",
      "https://tw.news.yahoo.com/outdoors/",
      "https://tw.news.yahoo.com/travel-blogger/",
    ]);
  });

  it("parses Yahoo Taiwan category articles with relative dates, direct URLs, and images", () => {
    const now = new Date("2026-08-17T00:00:00Z");
    const html = `<a href="https://tw.news.yahoo.com/story-one-123456789.html"><img src="https://img.yahoo.com/story-one.jpg" />熱門景點一</a><span>Yahoo旅遊夯即時・3 天前</span><a href="https://tw.news.yahoo.com/story-two-987654321.html"><img src="https://img.yahoo.com/story-two.jpg" />熱門景點二</a><span>Yahoo旅遊編輯部・6 天前</span>`;
    const items = parseYahooTaiwanCategoryHtml(html, YAHOO_TAIWAN_FUN_FEEDS[0], now);
    expect(items).toHaveLength(2);
    expect(items[0]).toMatchObject({ source: "Yahoo台灣｜最新熱門景點新聞", title: "熱門景點一", url: "https://tw.news.yahoo.com/story-one-123456789.html", imageUrl: "https://img.yahoo.com/story-one.jpg" });
    expect(items[0]?.publishedAt.toISOString()).toBe("2026-08-14T00:00:00.000Z");
  });

  it("requires Yahoo Travel as an enabled English source and keeps its tourism stories", () => {
    expect(NEWS_FEEDS).toContainEqual({
      source: "Yahoo Travel",
      url: "https://news.google.com/rss/search?q=site%3Atravel.yahoo.com&hl=en-US&gl=US&ceid=US:en",
    });
    const now = new Date("2026-08-14T00:00:00Z");
    const xml = `<rss><channel><item><title>Travel advice for a safer summer trip</title><link>https://travel.yahoo.com/guides/article/example.html</link><guid>yahoo-travel-1</guid><pubDate>Thu, 13 Aug 2026 10:00:00 GMT</pubDate><description>Travel tips help visitors plan a destination and hotel stay.</description></item><item><title>Portugal announces a new entry policy for 2026</title><link>https://travel.yahoo.com/news/article/portugal-policy.html</link><guid>yahoo-policy-1</guid><pubDate>Thu, 13 Aug 2026 09:00:00 GMT</pubDate><description>Government officials announced a new entry policy.</description></item></channel></rss>`;
    expect(parseRss(xml, "Yahoo Travel", now)).toHaveLength(2);
  });

  it("includes TVBS as a domain-limited public news source and preserves its direct article URL", () => {
    expect(NEWS_FEEDS).toContainEqual({
      source: "Google News／TVBS新聞網",
      url: "https://news.google.com/rss/search?q=site%3Anews.tvbs.com.tw%20%28%E8%A7%80%E5%85%89%20OR%20%E6%97%85%E9%81%8A%20OR%20%E6%97%85%E5%AE%BF%20OR%20%E9%A3%AF%E5%BA%97%20OR%20%E8%88%AA%E7%A9%BA%20OR%20%E6%97%85%E8%A1%8C%E7%A4%BE%29&hl=zh-TW&gl=TW&ceid=TW:zh-Hant",
    });
    const now = new Date("2026-08-20T00:00:00Z");
    const xml = `<rss><channel><item><title>國旅補助平日住宿優惠上線</title><link>https://news.tvbs.com.tw/travel/4009859</link><guid>tvbs-4009859</guid><source url="https://news.tvbs.com.tw">TVBS新聞網</source><pubDate>Wed, 20 Aug 2026 02:27:00 GMT</pubDate><description>觀光署國旅補助協助旅客安排住宿與旅遊行程。</description></item></channel></rss>`;
    expect(parseRss(xml, "Google News／TVBS新聞網", now)[0]).toMatchObject({ source: "TVBS新聞網", url: "https://news.tvbs.com.tw/travel/4009859" });
  });

  it("includes a dedicated government tourism service-disruption query", () => {
    expect(NEWS_FEEDS.some((feed) => feed.source === "Google News／政府旅遊服務異常" && feed.url.includes("%E7%B6%B2%E7%AB%99%E7%95%B6%E6%A9%9F"))).toBe(true);
  });

  it("keeps English overseas tourism news from an international source", () => {
    const now = new Date("2026-08-14T00:00:00Z");
    const xml = `<rss><channel><item><title>Global tourism demand lifts hotel and airline outlook</title><link>https://skift.com/story</link><guid>skift-1</guid><pubDate>Thu, 13 Aug 2026 10:00:00 GMT</pubDate><description>Travel demand and hotel bookings continue to change across markets.</description></item></channel></rss>`;
    expect(parseRss(xml, "Skift", now)).toHaveLength(1);
  });

  it("drops election-related tourism news even when it contains tourism keywords", () => {
    const now = new Date("2026-08-14T00:00:00Z");
    const xml = `<rss><channel><item><title>觀光政見與2026九合一選舉</title><link>https://example.com/election</link><guid>election-1</guid><pubDate>Thu, 13 Aug 2026 10:00:00 GMT</pubDate><description>候選人提出旅遊與觀光政策。</description></item></channel></rss>`;
    expect(parseRss(xml, "自由時報生活", now)).toHaveLength(0);
  });

  it("keeps tourism industry topics across food, lodging, travel, shopping, transport, and agencies", () => {
    const now = new Date("2026-08-14T00:00:00Z");
    const xml = `<rss><channel>
      <item><title>旅行社推出秋季套裝行程</title><link>https://example.com/agency</link><guid>agency-1</guid><pubDate>Thu, 13 Aug 2026 10:00:00 GMT</pubDate></item>
      <item><title>城市道路施工公告</title><link>https://example.com/unrelated</link><guid>unrelated-1</guid><pubDate>Thu, 13 Aug 2026 10:00:00 GMT</pubDate></item>
      <item><title>飯店住房率與航班運能回升</title><link>https://example.com/travel</link><guid>travel-1</guid><pubDate>Thu, 13 Aug 2026 10:00:00 GMT</pubDate></item>
    </channel></rss>`;
    const items = parseRss(xml, "自由時報生活", now);
    expect(items.map((item) => item.guid)).toEqual(["agency-1", "travel-1"]);
  });

  it("extracts images from RSS media, thumbnail, and inline description markup", () => {
    const now = new Date("2026-08-14T00:00:00Z");
    const xml = `<rss><channel>
      <item><title>飯店媒體圖片</title><link>https://example.com/media</link><guid>media-1</guid><pubDate>Thu, 13 Aug 2026 10:00:00 GMT</pubDate><media:thumbnail url="https://example.com/thumb.jpg" /></item>
      <item><title>旅遊內嵌圖片</title><link>https://example.com/inline</link><guid>inline-1</guid><pubDate>Thu, 13 Aug 2026 10:00:00 GMT</pubDate><description><![CDATA[<img src="https://example.com/inline.jpg" />旅遊摘要]]></description></item>
    </channel></rss>`;
    expect(parseRss(xml, "測試來源", now).map((item) => item.imageUrl)).toEqual(["https://example.com/thumb.jpg", "https://example.com/inline.jpg"]);
  });

  it("drops items older than fourteen days", () => {
    const now = new Date("2026-08-14T00:00:00Z");
    const xml = `<rss><channel><item><title>過期新聞</title><link>https://example.com/old</link><guid>old-1</guid><pubDate>Wed, 30 Jul 2026 10:00:00 GMT</pubDate></item></channel></rss>`;
    expect(parseRss(xml, "測試來源", now)).toHaveLength(0);
  });

  it("extracts the original article og:image and resolves relative paths", async () => {
    const fetchMock = vi.spyOn(globalThis, "fetch").mockResolvedValue({
      ok: true,
      url: "https://news.ltn.com.tw/news/life/breakingnews/5539855",
      text: async () => '<html><head><meta property="og:image" content="/images/story.jpg"></head></html>',
    } as Response);
    await expect(extractArticleImage("https://news.ltn.com.tw/news/life/breakingnews/5539855")).resolves.toBe("https://news.ltn.com.tw/images/story.jpg");
    expect(fetchMock).toHaveBeenCalledTimes(1);
    fetchMock.mockRestore();

    const googleFetch = vi.spyOn(globalThis, "fetch").mockResolvedValue({
      ok: true,
      url: "https://news.google.com/rss/articles/example",
      text: async () => '<meta property="og:image" content="https://lh3.googleusercontent.com/article-image=s0-w300">',
    } as Response);
    await expect(extractArticleImage("https://news.google.com/rss/articles/example")).resolves.toBe("https://lh3.googleusercontent.com/article-image=s0-w300");
    expect(googleFetch).toHaveBeenCalledTimes(1);
    googleFetch.mockRestore();
  });

  it("selects the first matching Google News result and preserves its source and image", () => {
    const xml = `<rss><channel><item><title>烏干達要求台人持中國護照蓋入境章外交部嚴正關切</title><link>https://news.google.com/rss/articles/first</link><guid>first</guid><source url="https://www.rti.org.tw">中央廣播電臺</source><description><![CDATA[<img src="https://example.com/uganda.jpg" />]]></description></item><item><title>其他烏干達新聞</title><link>https://news.google.com/rss/articles/second</link><guid>second</guid></item></channel></rss>`;
    expect(findGoogleNewsMatch(xml, "烏干達要求台人持中國護照蓋入境章外交部嚴正關切")).toMatchObject({
      url: "https://news.google.com/rss/articles/first",
      source: "中央廣播電臺",
      imageUrl: "https://example.com/uganda.jpg",
    });
  });

  it("resolves Google News wrappers to the original media URL", async () => {
    const directUrl = "https://money.udn.com/money/story/5612/0000000";
    const decodedPayload = JSON.stringify(["unused", directUrl]);
    const fetchMock = vi.spyOn(globalThis, "fetch")
      .mockResolvedValueOnce({ ok: true, text: async () => '<c-wiz><div jscontroller="x" data-n-a-sg="signature" data-n-a-ts="123456"></div></c-wiz>' } as Response)
      .mockResolvedValueOnce({ ok: true, text: async () => `prefix\n\n${JSON.stringify([["unused", "unused", decodedPayload]])}` } as Response);
    await expect(resolveOriginalUrl("https://news.google.com/rss/articles/example")).resolves.toBe(directUrl);
    await expect(resolveOriginalUrl("https://news.ltn.com.tw/news/life/breakingnews/5539855")).resolves.toBe("https://news.ltn.com.tw/news/life/breakingnews/5539855");
    expect(fetchMock).toHaveBeenCalledTimes(2);
    fetchMock.mockRestore();
  });
});
