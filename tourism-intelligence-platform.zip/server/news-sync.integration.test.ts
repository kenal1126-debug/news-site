import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";
import { NEWS_FEEDS, YAHOO_TAIWAN_FUN_FEEDS, mapWithConcurrency, parseRss } from "./news-sync";
import { NEWS_FEEDS as catalogNewsFeeds, YAHOO_TAIWAN_FUN_FEEDS as catalogYahooFeeds } from "./news/sourceCatalog";

describe("news sync compatibility and scheduling contracts", () => {
  it("keeps the public sync facade bound to the single source catalog", async () => {
    expect(NEWS_FEEDS).toBe(catalogNewsFeeds);
    expect(YAHOO_TAIWAN_FUN_FEEDS).toBe(catalogYahooFeeds);
    const xml = `<rss><channel><item><title>旅遊需求回升</title><link>https://example.com/item</link><guid>item-1</guid><pubDate>Thu, 20 Aug 2026 10:00:00 GMT</pubDate><description>觀光市場摘要</description></item></channel></rss>`;
    expect(parseRss(xml, "測試來源", new Date("2026-08-21T00:00:00Z"))).toHaveLength(1);
    expect(await mapWithConcurrency([1, 2], 1, async (value) => value)).toEqual([1, 2]);
  });

  it("keeps the scheduled endpoint and manual audit script connected through the compatible facade", () => {
    const coreIndex = readFileSync(new URL("./_core/index.ts", import.meta.url), "utf8");
    const scheduledRoute = readFileSync(new URL("./news/scheduledSyncRoute.ts", import.meta.url), "utf8");
    const manualScript = readFileSync(new URL("../scripts/manual-sync.mjs", import.meta.url), "utf8");
    expect(coreIndex).toContain('registerScheduledNewsSyncRoute');
    expect(coreIndex).toContain('syncRecentNews');
    expect(scheduledRoute).toContain('/api/scheduled/sync-news');
    expect(manualScript).toContain('from "../server/news-sync.ts"');
    expect(manualScript).toContain('from "../server/repositories/newsRepository.ts"');
  });
});
