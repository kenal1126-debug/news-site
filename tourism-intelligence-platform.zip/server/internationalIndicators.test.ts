import { describe, expect, it } from "vitest";
import { INTERNATIONAL_INDICATOR_CATALOG, parseOfficialIndicatorPage, parseOfficialMonthlyArrivalPage, VERIFIED_BASELINE_OBSERVATIONS } from "./internationalIndicators";

describe("international indicator catalog", () => {
  it("defines inbound-travel and population metrics for every current macro country", () => {
    expect(INTERNATIONAL_INDICATOR_CATALOG).toHaveLength(12);
    for (const countryCode of ["JPN", "KOR", "CAN", "AUS", "NZL", "THA"]) {
      expect(INTERNATIONAL_INDICATOR_CATALOG.filter(item => item.countryCode === countryCode).map(item => item.indicatorCode).sort()).toEqual(["inbound_arrivals", "population"]);
    }
  });

  it("keeps all seeded observations bound to a configured official source and a reference period", () => {
    const sourceHosts = new Set(INTERNATIONAL_INDICATOR_CATALOG.map(item => new URL(item.sourceUrl).host));
    expect(VERIFIED_BASELINE_OBSERVATIONS).not.toHaveLength(0);
    for (const observation of VERIFIED_BASELINE_OBSERVATIONS) {
      expect(observation.value).toBeGreaterThan(0);
      expect(observation.periodStart.getTime()).toBeLessThanOrEqual(observation.referenceDate.getTime());
      expect(sourceHosts).toContain(new URL(observation.sourceUrl).host);
    }
  });

  it("parses official Australia and New Zealand monthly-arrival release wording", () => {
    expect(parseOfficialMonthlyArrivalPage("For short-term visitor arrivals to Australia in June 2026: A total of 566,910 trips were recorded.", "AUS")).toMatchObject({ value: 566_910, referenceDate: new Date("2026-06-30T00:00:00.000Z") });
    expect(parseOfficialMonthlyArrivalPage("Overseas visitor arrivals were 203,300 in May 2026, an increase from May 2025.", "NZL")).toMatchObject({ value: 203_300, referenceDate: new Date("2026-05-31T00:00:00.000Z") });
  });

  it("parses Thailand's official central-bank tourism table in thousands", () => {
    const parsed = parseOfficialMonthlyArrivalPage(`
      ( JAN 2015 - JUN 2026 ) Last Updated : 31 Jul 2026
      | | JUN 2026 p | MAY 2026 p |
      | 1 | 1. Number of foreign tourists visiting Thailand (in thousands) | 1,841.55 | 2,346.85 |
    `, "THA");
    expect(parsed).toMatchObject({ value: 1_841_550, referenceDate: new Date(Date.UTC(2026, 5, 30)) });
  });

  it("parses Thailand's server-fetched HTML table cells", () => {
    const parsed = parseOfficialMonthlyArrivalPage(`
      <td>JUN 2026 p</td>
      <td>1. Number of foreign tourists visiting Thailand (in thousands) </td><td align="right">1,841.55</td>
    `, "THA");
    expect(parsed).toMatchObject({ value: 1_841_550, referenceDate: new Date(Date.UTC(2026, 5, 30)) });
  });

  it("parses official Canada and Korea arrival releases plus Australia population", () => {
    expect(parseOfficialIndicatorPage("Travel between Canada and other countries, June 2026. In June,&#160;811,000&#160;overseas residents arrived in Canada.", "CAN:inbound_arrivals")).toMatchObject({ value: 811_000, referenceDate: new Date(Date.UTC(2026, 5, 30)) });
    expect(parseOfficialIndicatorPage("Through June 2026. Total International Visitors 8,825,967 10,709,919 21%", "KOR:inbound_arrivals")).toMatchObject({ value: 10_709_919, referenceDate: new Date(Date.UTC(2026, 5, 30)), periodStart: new Date(Date.UTC(2026, 0, 1)) });
    expect(parseOfficialIndicatorPage("Australia’s population was 27,801,023 people at 31 December 2025.", "AUS:population")).toMatchObject({ value: 27_801_023, referenceDate: new Date(Date.UTC(2025, 11, 31)) });
  });

  it("parses New Zealand resident population and Thailand census population pages", () => {
    expect(parseOfficialIndicatorPage("Year ended December 2025 Annual change Population Estimated resident population, as at 31 December 5,344,500", "NZL:population")).toMatchObject({ value: 5_344_500, referenceDate: new Date(Date.UTC(2025, 11, 31)), status: "provisional" });
    expect(parseOfficialIndicatorPage("The estimated resident population of New Zealand at 31 December 2025 was 5,342,000 (provisionally).", "NZL:population")).toMatchObject({ value: 5_342_000, referenceDate: new Date(Date.UTC(2025, 11, 31)), status: "provisional" });
    expect(parseOfficialIndicatorPage("The provisional estimated resident population of Aotearoa New Zealand was 5,357,300 at 30 June 2026.", "NZL:population")).toMatchObject({ value: 5_357_300, referenceDate: new Date(Date.UTC(2026, 5, 30)), status: "provisional" });
    expect(parseOfficialIndicatorPage("RecordClassName&quot;:&quot;Stats\\\\IndicatorBlock&quot;,&quot;Value&quot;:&quot;5,357,300&quot;,&quot;Period&quot;:&quot;30 June 2026&quot;", "NZL:population")).toMatchObject({ value: 5_357_300, referenceDate: new Date(Date.UTC(2026, 5, 30)), status: "provisional" });
    expect(parseOfficialIndicatorPage("2025 Population and Housing Census. The total population living in Thailand is 70.3 million people.", "THA:population")).toMatchObject({ value: 70_300_000, referenceDate: new Date(Date.UTC(2025, 11, 31)), status: "provisional" });
  });
});
