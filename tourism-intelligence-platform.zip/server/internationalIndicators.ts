import type { InsertCountryIndicator, InsertCountryIndicatorObservation } from "../drizzle/schema";
import { completeCountryIndicatorRefreshRun, ensureCountryIndicators, hashTraceabilityInput, recordCountryIndicatorRefreshItems, startCountryIndicatorRefreshRun, upsertCountryIndicatorObservation } from "./repositories/operationsRepository";

type CountryIndicatorSeed = InsertCountryIndicator & { key: string };

const MONTHLY_REFRESH = "monthly_official_release";
const QUARTERLY_REFRESH = "quarterly_official_estimate";

export const INTERNATIONAL_INDICATOR_CATALOG: CountryIndicatorSeed[] = [
  { key: "JPN:inbound_arrivals", countryCode: "JPN", countryName: "日本", indicatorCode: "inbound_arrivals", label: "國際旅客入境旅次", unit: "旅次", periodicity: "月", sourceName: "JNTO Japan Tourism Statistics", sourceUrl: "https://statistics.jnto.go.jp/en/graph/", definition: "JNTO 公布的 Visitor Arrivals to Japan；為入境旅次統計，非去重後獨立旅客數。", refreshPolicy: MONTHLY_REFRESH },
  { key: "JPN:population", countryCode: "JPN", countryName: "日本", indicatorCode: "population", label: "總人口估計", unit: "人", periodicity: "年", sourceName: "Statistics Bureau of Japan", sourceUrl: "https://www.stat.go.jp/english/data/jinsui/2024np/index.html", definition: "日本統計局人口推計；使用發布表的基準日與人口概念。", refreshPolicy: QUARTERLY_REFRESH },
  { key: "KOR:inbound_arrivals", countryCode: "KOR", countryName: "韓國", indicatorCode: "inbound_arrivals", label: "外國訪客入境旅次", unit: "旅次", periodicity: "月／累計", sourceName: "Korea Ministry of Culture, Sports and Tourism", sourceUrl: "https://www.mcst.go.kr/english/policy/pressView.jsp?pSeq=658", definition: "韓國文化體育觀光部發布的外國訪客入境統計；為入境旅次而非獨立訪客。", refreshPolicy: MONTHLY_REFRESH },
  { key: "KOR:population", countryCode: "KOR", countryName: "韓國", indicatorCode: "population", label: "總人口", unit: "人", periodicity: "年", sourceName: "KOSIS", sourceUrl: "https://kosis.kr/statHtml/statHtml.do?sso=ok&returnurl=https%3A%2F%2Fkosis.kr%3A443%2FstatHtml%2FstatHtml.do%3FtblId%3DDT_1IN1502%26language%3Den%26orgId%3D101%26", definition: "KOSIS 人口、戶數與住宅統計表的全國總人口，包含韓國人與外國居民；不採首頁預測輪播數。", refreshPolicy: QUARTERLY_REFRESH },
  { key: "CAN:inbound_arrivals", countryCode: "CAN", countryName: "加拿大", indicatorCode: "inbound_arrivals", label: "海外非居民到達旅次", unit: "旅次", periodicity: "月", sourceName: "Statistics Canada", sourceUrl: "https://www150.statcan.gc.ca/n1/daily-quotidien/260820/dq260820b-eng.htm", definition: "加拿大統計局國際旅行發布中的 overseas residents arrivals；不混入加拿大居民返國旅次。", refreshPolicy: MONTHLY_REFRESH },
  { key: "CAN:population", countryCode: "CAN", countryName: "加拿大", indicatorCode: "population", label: "總人口估計", unit: "人", periodicity: "季", sourceName: "Statistics Canada Table 17-10-0009-01", sourceUrl: "https://www150.statcan.gc.ca/t1/tbl1/en/tv.action?pid=1710000901", definition: "Statistics Canada 季度人口估計；保留表號、統計基準日與發布日。", refreshPolicy: QUARTERLY_REFRESH },
  { key: "AUS:inbound_arrivals", countryCode: "AUS", countryName: "澳洲", indicatorCode: "inbound_arrivals", label: "短期訪客入境旅次", unit: "旅次", periodicity: "月", sourceName: "Australian Bureau of Statistics", sourceUrl: "https://www.abs.gov.au/statistics/industry/tourism-and-transport/overseas-arrivals-and-departures-australia/latest-release", definition: "ABS Short-term visitor arrivals；官方明示為國際邊境移動／旅次，非獨立人數。", refreshPolicy: MONTHLY_REFRESH },
  { key: "AUS:population", countryCode: "AUS", countryName: "澳洲", indicatorCode: "population", label: "總人口估計", unit: "人", periodicity: "季", sourceName: "Australian Bureau of Statistics", sourceUrl: "https://www.abs.gov.au/statistics/people/population/national-state-and-territory-population/latest-release", definition: "ABS National, state and territory population 的國家總人口估計。", refreshPolicy: QUARTERLY_REFRESH },
  { key: "NZL:inbound_arrivals", countryCode: "NZL", countryName: "紐西蘭", indicatorCode: "inbound_arrivals", label: "海外訪客入境旅次", unit: "旅次", periodicity: "月", sourceName: "Stats NZ", sourceUrl: "https://www.stats.govt.nz/information-releases/international-travel-may-2026/", definition: "Stats NZ overseas visitor arrivals，屬短期國際移動統計而非去重後個人數。", refreshPolicy: MONTHLY_REFRESH },
  { key: "NZL:population", countryCode: "NZL", countryName: "紐西蘭", indicatorCode: "population", label: "常住人口估計", unit: "人", periodicity: "季", sourceName: "Stats NZ", sourceUrl: "https://www.stats.govt.nz/indicators/population-of-nz/", definition: "Stats NZ 以 Census 為基礎發布的居民人口估計；使用固定指標頁的最新修訂值並保留估計基準日。", refreshPolicy: QUARTERLY_REFRESH },
  { key: "THA:inbound_arrivals", countryCode: "THA", countryName: "泰國", indicatorCode: "inbound_arrivals", label: "外國旅客入境旅次", unit: "旅次", periodicity: "月", sourceName: "Bank of Thailand / Ministry of Tourism and Sports", sourceUrl: "https://app.bot.or.th/BTWS_STAT/statistics/ReportPage.aspx?reportID=875&language=eng", definition: "泰國中央銀行公布且標示來源為觀光與體育部的外國旅客訪泰統計；單位為千人，為入境旅次。", refreshPolicy: MONTHLY_REFRESH },
  { key: "THA:population", countryCode: "THA", countryName: "泰國", indicatorCode: "population", label: "總人口（普查初步）", unit: "人", periodicity: "年", sourceName: "Thailand National Statistical Office", sourceUrl: "https://www.nso.go.th/nsoweb/main/summano/aE?set_lang=en", definition: "泰國國家統計局人口及住宅普查公布的居住人口；須與戶籍登記人口分開解讀。", refreshPolicy: QUARTERLY_REFRESH },
];

type BaselineObservation = {
  key: string;
  value: number;
  periodStart: Date;
  periodEnd: Date;
  referenceDate: Date;
  sourceUrl: string;
  note: string;
};

/** Values are only seeded after an official source and reference period have been verified. */
export const VERIFIED_BASELINE_OBSERVATIONS: BaselineObservation[] = [
  { key: "JPN:inbound_arrivals", value: 3_148_600, periodStart: new Date("2026-06-01T00:00:00Z"), periodEnd: new Date("2026-06-30T23:59:59Z"), referenceDate: new Date("2026-06-30T00:00:00Z"), sourceUrl: "https://statistics.jnto.go.jp/en/graph/", note: "2026 年 6 月訪日外國旅客；JNTO Visitor Arrivals to Japan。" },
  { key: "JPN:population", value: 123_802_000, periodStart: new Date("2024-10-01T00:00:00Z"), periodEnd: new Date("2024-10-01T00:00:00Z"), referenceDate: new Date("2024-10-01T00:00:00Z"), sourceUrl: "https://www.stat.go.jp/english/data/jinsui/2024np/index.html", note: "截至 2024-10-01 的日本統計局人口推計。" },
  { key: "KOR:inbound_arrivals", value: 10_709_919, periodStart: new Date("2026-01-01T00:00:00Z"), periodEnd: new Date("2026-06-30T23:59:59Z"), referenceDate: new Date("2026-06-30T00:00:00Z"), sourceUrl: "https://www.mcst.go.kr/english/policy/pressView.jsp?pSeq=658", note: "2026 年 1–6 月外國訪客入境累計；韓國文化體育觀光部於 2026-08-06 公布。" },
  { key: "KOR:population", value: 51_817_499, periodStart: new Date("2025-01-01T00:00:00Z"), periodEnd: new Date("2025-12-31T23:59:59Z"), referenceDate: new Date("2025-12-31T00:00:00Z"), sourceUrl: "https://kosis.kr/statHtml/statHtml.do?sso=ok&returnurl=https%3A%2F%2Fkosis.kr%3A443%2FstatHtml%2FstatHtml.do%3FtblId%3DDT_1IN1502%26language%3Den%26orgId%3D101%26", note: "KOSIS 2025 Whole country total population；表格於 2026-08-04 更新，含外國居民。" },
  { key: "CAN:inbound_arrivals", value: 811_000, periodStart: new Date("2026-06-01T00:00:00Z"), periodEnd: new Date("2026-06-30T23:59:59Z"), referenceDate: new Date("2026-06-30T00:00:00Z"), sourceUrl: "https://www150.statcan.gc.ca/n1/daily-quotidien/260820/dq260820b-eng.htm", note: "2026 年 6 月 overseas residents arrivals；不包含加拿大居民返國旅次。" },
  { key: "CAN:population", value: 41_417_056, periodStart: new Date("2026-04-01T00:00:00Z"), periodEnd: new Date("2026-04-01T00:00:00Z"), referenceDate: new Date("2026-04-01T00:00:00Z"), sourceUrl: "https://www150.statcan.gc.ca/n1/daily-quotidien/260617/dq260617a-eng.htm", note: "截至 2026-04-01 的 Statistics Canada 人口初步估計。" },
  { key: "AUS:inbound_arrivals", value: 566_910, periodStart: new Date("2026-06-01T00:00:00Z"), periodEnd: new Date("2026-06-30T23:59:59Z"), referenceDate: new Date("2026-06-30T00:00:00Z"), sourceUrl: "https://www.abs.gov.au/statistics/industry/tourism-and-transport/overseas-arrivals-and-departures-australia/latest-release", note: "2026 年 6 月 ABS short-term visitor arrivals；統計單位為旅次。" },
  { key: "AUS:population", value: 27_801_023, periodStart: new Date("2025-12-31T00:00:00Z"), periodEnd: new Date("2025-12-31T00:00:00Z"), referenceDate: new Date("2025-12-31T00:00:00Z"), sourceUrl: "https://www.abs.gov.au/statistics/people/population/national-state-and-territory-population/latest-release", note: "截至 2025-12-31 的 ABS 國家總人口估計。" },
  { key: "NZL:inbound_arrivals", value: 203_300, periodStart: new Date("2026-05-01T00:00:00Z"), periodEnd: new Date("2026-05-31T23:59:59Z"), referenceDate: new Date("2026-05-31T00:00:00Z"), sourceUrl: "https://www.stats.govt.nz/information-releases/international-travel-may-2026/", note: "2026 年 5 月 overseas visitor arrivals；Stats NZ 短期國際移動統計。" },
  { key: "NZL:population", value: 5_357_300, periodStart: new Date("2026-06-30T00:00:00Z"), periodEnd: new Date("2026-06-30T00:00:00Z"), referenceDate: new Date("2026-06-30T00:00:00Z"), sourceUrl: "https://www.stats.govt.nz/indicators/population-of-nz/", note: "截至 2026-06-30 的 Stats NZ estimated resident population；固定指標頁於 2026-08-18 更新，數值屬暫定並可能按季修訂。" },
  { key: "THA:population", value: 70_300_000, periodStart: new Date("2025-01-01T00:00:00Z"), periodEnd: new Date("2025-12-31T23:59:59Z"), referenceDate: new Date("2025-12-31T00:00:00Z"), sourceUrl: "https://www.nso.go.th/nsoweb/main/summano/aE?set_lang=en", note: "2025 年人口及住宅普查初步結果：居住於泰國的人口 7,030 萬；非戶籍登記人口口徑。" },
  { key: "THA:inbound_arrivals", value: 1_841_550, periodStart: new Date("2026-06-01T00:00:00Z"), periodEnd: new Date("2026-06-30T23:59:59Z"), referenceDate: new Date("2026-06-30T00:00:00Z"), sourceUrl: "https://app.bot.or.th/BTWS_STAT/statistics/ReportPage.aspx?reportID=875&language=eng", note: "2026 年 6 月外國旅客訪泰；泰國中央銀行觀光指標表，單位千人換算為旅次，資料標示 provisional，來源為觀光與體育部。" },
];

export async function bootstrapInternationalIndicatorCatalog(now = new Date()) {
  const ids = await ensureCountryIndicators(INTERNATIONAL_INDICATOR_CATALOG.map(({ key: _key, ...indicator }) => indicator));
  let observationsPersisted = 0;
  for (const baseline of VERIFIED_BASELINE_OBSERVATIONS) {
    const indicatorId = ids.get(baseline.key);
    if (!indicatorId) continue;
    await upsertCountryIndicatorObservation({
      countryIndicatorId: indicatorId,
      value: String(baseline.value),
      periodStart: baseline.periodStart,
      periodEnd: baseline.periodEnd,
      referenceDate: baseline.referenceDate,
      publishedAt: null,
      fetchedAt: now,
      status: "final",
      sourceUrl: baseline.sourceUrl,
      sourceFingerprint: hashTraceabilityInput(`${baseline.key}|${baseline.referenceDate.toISOString()}|${baseline.value}|${baseline.sourceUrl}`),
      metadataJson: { origin: "official-source-baseline", unit: "persons-or-trips" },
      note: baseline.note,
    });
    observationsPersisted += 1;
  }
  return { indicatorIds: ids, observationsPersisted };
}

type ParsedMonthlyMetric = { value: number; referenceDate: Date; note: string };
type ParsedOfficialMetric = ParsedMonthlyMetric & { periodStart?: Date; status?: "provisional" | "final" };

const MONTH_NAMES: Record<string, number> = {
  january: 0, february: 1, march: 2, april: 3, may: 4, june: 5,
  july: 6, august: 7, september: 8, october: 9, november: 10, december: 11,
  jan: 0, feb: 1, mar: 2, apr: 3, jun: 5, jul: 6, aug: 7, sep: 8, sept: 8, oct: 9, nov: 10, dec: 11,
};

function parseReleaseMonth(text: string) {
  const match = text.match(/\b(January|February|March|April|May|June|July|August|September|October|November|December|Jan|Feb|Mar|Apr|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec)\s+(20\d{2})\b/i);
  if (!match) return undefined;
  const month = MONTH_NAMES[match[1]?.toLowerCase() ?? ""];
  const year = Number(match[2]);
  if (month === undefined || !Number.isFinite(year)) return undefined;
  return new Date(Date.UTC(year, month + 1, 0));
}

function parseThaiTableReferenceMonth(text: string) {
  const match = text.match(/(?:\|\s*|>\s*)(January|February|March|April|May|June|July|August|September|October|November|December|Jan|Feb|Mar|Apr|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec)\s+(20\d{2})\s+p\b/i);
  if (!match) return undefined;
  const month = MONTH_NAMES[match[1]?.toLowerCase() ?? ""];
  const year = Number(match[2]);
  if (month === undefined || !Number.isFinite(year)) return undefined;
  return new Date(Date.UTC(year, month + 1, 0));
}

export function parseOfficialMonthlyArrivalPage(text: string, countryCode: "AUS" | "NZL" | "THA"): ParsedMonthlyMetric | undefined {
  const normalized = text.replace(/\s+/g, " ");
  const pattern = countryCode === "AUS"
    ? /short-term visitor arrivals(?: to Australia)?(?: in)?\s+(?:\w+\s+20\d{2}[^\d]{0,90})?([\d,]+)\s+(?:trips|were recorded)/i
    : countryCode === "NZL"
      ? /overseas visitor arrivals were\s+([\d,]+)\s+in\s+(?:\w+\s+20\d{2})/i
      : /Number of foreign tourists visiting Thailand\s*\(in thousands\)(?:\s*\|\s*|\s*<\/td>\s*<td[^>]*>\s*)([\d,.]+)/i;
  const valueMatch = normalized.match(pattern);
  const referenceDate = countryCode === "THA" ? parseThaiTableReferenceMonth(normalized) : parseReleaseMonth(normalized);
  const value = Number((valueMatch?.[1] ?? "").replace(/,/g, "")) * (countryCode === "THA" ? 1_000 : 1);
  if (!valueMatch || !Number.isFinite(value) || value <= 0 || !referenceDate) return undefined;
  return {
    value,
    referenceDate,
    note: countryCode === "AUS"
      ? "ABS short-term visitor arrivals；統計單位為旅次。"
      : countryCode === "NZL"
        ? "Stats NZ overseas visitor arrivals；屬短期國際移動統計。"
        : "泰國中央銀行觀光指標表的外國旅客訪泰數；單位千人換算為旅次，來源為觀光與體育部。",
  };
}

const AUTOMATED_MONTHLY_ARRIVAL_KEYS = new Set(["AUS:inbound_arrivals", "NZL:inbound_arrivals", "THA:inbound_arrivals"]);
const AUTOMATED_OFFICIAL_INDICATOR_KEYS = new Set([
  ...Array.from(AUTOMATED_MONTHLY_ARRIVAL_KEYS),
  "CAN:inbound_arrivals",
  "KOR:inbound_arrivals",
  "AUS:population",
  "NZL:population",
  "THA:population",
]);

export function parseOfficialIndicatorPage(text: string, indicatorKey: string): ParsedOfficialMetric | undefined {
  if (indicatorKey === "AUS:inbound_arrivals" || indicatorKey === "NZL:inbound_arrivals" || indicatorKey === "THA:inbound_arrivals") {
    return parseOfficialMonthlyArrivalPage(text, indicatorKey.slice(0, 3) as "AUS" | "NZL" | "THA");
  }
  const normalized = text
    .replace(/<[^>]+>/g, " ")
    .replace(/&(nbsp|#160|#xA0);?/gi, " ")
    .replace(/\s+/g, " ");
  if (indicatorKey === "CAN:inbound_arrivals") {
    const match = normalized.match(/In\s+(January|February|March|April|May|June|July|August|September|October|November|December),\s+([\d,]+)\s+overseas residents arrived in Canada/i);
    const referenceDate = parseReleaseMonth(normalized);
    const value = Number((match?.[2] ?? "").replace(/,/g, ""));
    if (!match || !referenceDate || !Number.isFinite(value) || value <= 0) return undefined;
    return { value, referenceDate, note: "Statistics Canada overseas residents arrivals；不含加拿大居民返國旅次。" };
  }
  if (indicatorKey === "KOR:inbound_arrivals") {
    const match = normalized.match(/Total International Visitors\s+[\d,]+\s+([\d,]+)\s+\d+%/i);
    const referenceDate = parseReleaseMonth(normalized);
    const value = Number((match?.[1] ?? "").replace(/,/g, ""));
    if (!match || !referenceDate || !Number.isFinite(value) || value <= 0) return undefined;
    return { value, referenceDate, periodStart: new Date(Date.UTC(referenceDate.getUTCFullYear(), 0, 1)), note: "韓國文化體育觀光部公布的年初至當期外國訪客入境累計；非單月值。" };
  }
  if (indicatorKey === "AUS:population") {
    const match = normalized.match(/Australia(?:’|'|’)s population was\s+([\d,]+)\s+people at\s+31\s+December\s+(20\d{2})/i);
    const value = Number((match?.[1] ?? "").replace(/,/g, ""));
    const year = Number(match?.[2]);
    if (!match || !Number.isFinite(value) || value <= 0 || !Number.isFinite(year)) return undefined;
    return { value, referenceDate: new Date(Date.UTC(year, 11, 31)), note: "ABS estimated resident population；國家總人口估計。" };
  }
  if (indicatorKey === "NZL:population") {
    const indicatorBlock = text.match(/RecordClassName&quot;:&quot;Stats\\+IndicatorBlock&quot;[\s\S]{0,500}?&quot;Value&quot;:&quot;([\d,]+)&quot;,&quot;Period&quot;:&quot;(\d{1,2})\s+(January|February|March|April|May|June|July|August|September|October|November|December)\s+(20\d{2})/i);
    if (indicatorBlock) {
      const value = Number(indicatorBlock[1].replace(/,/g, ""));
      const day = Number(indicatorBlock[2]);
      const month = MONTH_NAMES[indicatorBlock[3].toLowerCase()];
      const year = Number(indicatorBlock[4]);
      if (Number.isFinite(value) && value > 0 && Number.isFinite(day) && month !== undefined && Number.isFinite(year)) {
        return { value, referenceDate: new Date(Date.UTC(year, month, day)), status: "provisional", note: "Stats NZ estimated resident population；固定指標區塊的最新季度暫定估計。" };
      }
    }
    const currentFormat = normalized.match(/provisional estimated resident population of(?: Aotearoa)? New Zealand was\s+([\d,]+)\s+at\s+(\d{1,2})\s+(January|February|March|April|May|June|July|August|September|October|November|December)\s+(20\d{2})/i);
    if (currentFormat) {
      const value = Number(currentFormat[1].replace(/,/g, ""));
      const day = Number(currentFormat[2]);
      const month = MONTH_NAMES[currentFormat[3].toLowerCase()];
      const year = Number(currentFormat[4]);
      if (Number.isFinite(value) && value > 0 && Number.isFinite(day) && month !== undefined && Number.isFinite(year)) {
        return { value, referenceDate: new Date(Date.UTC(year, month, day)), status: "provisional", note: "Stats NZ estimated resident population；固定指標頁所列最新季度的暫定估計。" };
      }
    }
    const historicalFormat = normalized.match(/estimated resident population of(?: New Zealand)? at 31 December\s+(20\d{2})\s+was\s+([\d,]+)/i)
      ?? normalized.match(/Year ended December\s+(20\d{2})[\s\S]{0,300}?Estimated resident population, as at 31 December\s+([\d,]+)/i);
    const year = Number(historicalFormat?.[1]);
    const value = Number((historicalFormat?.[2] ?? "").replace(/,/g, ""));
    if (!historicalFormat || !Number.isFinite(value) || value <= 0 || !Number.isFinite(year)) return undefined;
    return { value, referenceDate: new Date(Date.UTC(year, 11, 31)), status: "provisional", note: "Stats NZ estimated resident population；按季修訂前的暫定估計。" };
  }
  if (indicatorKey === "THA:population") {
    const valueMatch = normalized.match(/total population living in Thailand is\s+([\d.]+)\s+million people/i);
    const yearMatch = normalized.match(/(20\d{2})\s+Population and Housing Census/i);
    const value = Number(valueMatch?.[1]) * 1_000_000;
    const year = Number(yearMatch?.[1]);
    if (!valueMatch || !Number.isFinite(value) || value <= 0 || !Number.isFinite(year)) return undefined;
    return { value, referenceDate: new Date(Date.UTC(year, 11, 31)), status: "provisional", note: "泰國國家統計局人口及住宅普查初步結果；居住人口而非戶籍登記人口。" };
  }
  return undefined;
}

export async function refreshInternationalIndicators(input: {
  triggerKind: "heartbeat" | "manual_audit" | "operations_replay";
  heartbeatTaskUid?: string;
  now?: Date;
  fetchText?: (url: string) => Promise<string>;
}) {
  const now = input.now ?? new Date();
  const { indicatorIds, observationsPersisted: baselinePersisted } = await bootstrapInternationalIndicatorCatalog(now);
  const refreshRunId = await startCountryIndicatorRefreshRun({
    triggerKind: input.triggerKind,
    heartbeatTaskUid: input.heartbeatTaskUid,
    indicatorTotal: INTERNATIONAL_INDICATOR_CATALOG.length,
  });
  const fetchText = input.fetchText ?? (async (url: string) => {
    const response = await fetch(url, { headers: { "user-agent": "TourismIntelligencePlatform/1.0" }, signal: AbortSignal.timeout(12_000) });
    if (!response.ok) throw new Error(`official-source-http-${response.status}`);
    return response.text();
  });
  let succeeded = 0;
  let failed = 0;
  let dynamicPersisted = 0;
  const itemResults: Array<{ countryIndicatorId: number; itemStatus: "success" | "failed" | "skipped"; sourceUrlSnapshot: string; referenceDate: Date | null; observationPersisted: boolean; errorSummary: string | null; completedAt: Date }> = [];

  for (const indicator of INTERNATIONAL_INDICATOR_CATALOG) {
    const countryIndicatorId = indicatorIds.get(indicator.key);
    if (!countryIndicatorId) continue;
    if (!AUTOMATED_OFFICIAL_INDICATOR_KEYS.has(indicator.key)) {
      itemResults.push({ countryIndicatorId, itemStatus: "skipped", sourceUrlSnapshot: indicator.sourceUrl, referenceDate: null, observationPersisted: false, errorSummary: "A dedicated machine-readable parser has not yet been enabled for this official source.", completedAt: now });
      continue;
    }
    try {
      const page = await fetchText(indicator.sourceUrl);
      const parsed = parseOfficialIndicatorPage(page, indicator.key);
      if (!parsed) throw new Error("official-source-value-not-found");
      const periodStart = parsed.periodStart ?? new Date(Date.UTC(parsed.referenceDate.getUTCFullYear(), parsed.referenceDate.getUTCMonth(), 1));
      await upsertCountryIndicatorObservation({
        countryIndicatorId,
        value: String(parsed.value),
        periodStart,
        periodEnd: parsed.referenceDate,
        referenceDate: parsed.referenceDate,
        publishedAt: null,
        fetchedAt: now,
        status: parsed.status ?? "final",
        sourceUrl: indicator.sourceUrl,
        sourceFingerprint: hashTraceabilityInput(`${indicator.key}|${parsed.referenceDate.toISOString()}|${parsed.value}|${indicator.sourceUrl}`),
        metadataJson: { origin: "official-page-refresh", parser: "official-metric-v2" },
        note: parsed.note,
      });
      succeeded += 1;
      dynamicPersisted += 1;
      itemResults.push({ countryIndicatorId, itemStatus: "success", sourceUrlSnapshot: indicator.sourceUrl, referenceDate: parsed.referenceDate, observationPersisted: true, errorSummary: null, completedAt: now });
    } catch (error) {
      failed += 1;
      itemResults.push({ countryIndicatorId, itemStatus: "failed", sourceUrlSnapshot: indicator.sourceUrl, referenceDate: null, observationPersisted: false, errorSummary: String(error).slice(0, 1000), completedAt: now });
    }
  }

  await recordCountryIndicatorRefreshItems(refreshRunId, itemResults);
  const skipped = itemResults.filter(item => item.itemStatus === "skipped").length;
  const runStatus = failed > 0 ? (succeeded > 0 ? "partial" : "failed") : "success";
  await completeCountryIndicatorRefreshRun(refreshRunId, {
    runStatus,
    completedAt: now,
    indicatorSucceeded: succeeded,
    indicatorFailed: failed,
    observationPersisted: baselinePersisted + dynamicPersisted,
    errorSummary: skipped ? `${skipped} official sources are cataloged but await dedicated machine-readable parsers.` : null,
  });
  return { refreshRunId, runStatus, succeeded, failed, skipped, observationsPersisted: baselinePersisted + dynamicPersisted };
}
