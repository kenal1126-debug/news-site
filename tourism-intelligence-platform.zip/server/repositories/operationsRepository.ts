import { createHash, randomUUID } from "node:crypto";
import { and, desc, eq, gt, inArray, sql } from "drizzle-orm";
import {
  countryIndicatorObservations,
  countryIndicators,
  countryIndicatorRefreshRunItems,
  countryIndicatorRefreshRuns,
  insightCacheEntries,
  newsSources,
  newsSyncRunSources,
  newsSyncRuns,
  tourismServiceAlerts,
  type InsertCountryIndicator,
  type InsertCountryIndicatorObservation,
  type InsertCountryIndicatorRefreshRunItem,
  type InsertNewsSource,
  type InsertNewsSyncRunSource,
} from "../../drizzle/schema";
import { getDb } from "../db";

export const OPERATIONS_CATALOG_VERSION = "traceability-v1";
export const ENGLISH_KEYWORD_CACHE_NAMESPACE = "english-keyword-terms";

export async function invalidateInsightCacheNamespace(namespace: string) {
  const db = await getDb();
  if (!db) return;
  await db.delete(insightCacheEntries).where(eq(insightCacheEntries.cacheNamespace, namespace));
}

export type SourceSnapshotInput = Pick<InsertNewsSource, "sourceKey" | "displayName" | "adapterKind" | "endpointUrl" | "categoryHint" | "language" | "isRequired" | "isActive">;

export type SyncRunInput = {
  triggerKind: "heartbeat" | "manual_audit" | "operations_replay";
  heartbeatTaskUid?: string;
  cutoffAt: Date;
  sourceTotal: number;
};

export type SyncRunCompletionInput = {
  status: "success" | "partial" | "failed";
  completedAt: Date;
  sourceSucceeded: number;
  sourceFailed: number;
  itemFetched: number;
  itemPersisted: number;
  itemRejected?: number;
  errorSummary?: string | null;
};

export type SourceRunInput = Pick<InsertNewsSyncRunSource, "newsSourceId" | "endpointUrlSnapshot" | "status" | "httpStatus" | "startedAt" | "completedAt" | "itemFetched" | "itemAccepted" | "errorSummary">;

export function hashTraceabilityInput(value: string) {
  return createHash("sha256").update(value).digest("hex");
}

export function normalizeErrorSummary(error: unknown, limit = 1000) {
  const value = String(error ?? "").replace(/\s+/g, " ").trim();
  return value ? value.slice(0, limit) : null;
}

export async function ensureNewsSourceSnapshots(sources: SourceSnapshotInput[], catalogVersion = OPERATIONS_CATALOG_VERSION) {
  const db = await getDb();
  if (!db || sources.length === 0) return new Map<string, number>();

  for (const source of sources) {
    await db.insert(newsSources).values({ ...source, catalogVersion }).onDuplicateKeyUpdate({
      set: {
        displayName: sql.raw("VALUES(displayName)"),
        adapterKind: sql.raw("VALUES(adapterKind)"),
        endpointUrl: sql.raw("VALUES(endpointUrl)"),
        categoryHint: sql.raw("VALUES(categoryHint)"),
        language: sql.raw("VALUES(language)"),
        isRequired: sql.raw("VALUES(isRequired)"),
        isActive: sql.raw("VALUES(isActive)"),
        catalogVersion: sql.raw("VALUES(catalogVersion)"),
      },
    });
  }

  const sourceKeys = sources.map(source => source.sourceKey);
  const rows = await db.select({ id: newsSources.id, sourceKey: newsSources.sourceKey }).from(newsSources).where(inArray(newsSources.sourceKey, sourceKeys));
  return new Map(rows.map(row => [row.sourceKey, row.id]));
}

export async function startNewsSyncRun(input: SyncRunInput) {
  const db = await getDb();
  const id = randomUUID();
  if (!db) return id;
  await db.insert(newsSyncRuns).values({
    id,
    triggerKind: input.triggerKind,
    heartbeatTaskUid: input.heartbeatTaskUid ?? null,
    status: "running",
    cutoffAt: input.cutoffAt,
    sourceTotal: input.sourceTotal,
  });
  return id;
}

export async function completeNewsSyncRun(syncRunId: string, input: SyncRunCompletionInput) {
  const db = await getDb();
  if (!db) return;
  await db.update(newsSyncRuns).set({
    status: input.status,
    completedAt: input.completedAt,
    sourceSucceeded: input.sourceSucceeded,
    sourceFailed: input.sourceFailed,
    itemFetched: input.itemFetched,
    itemPersisted: input.itemPersisted,
    itemRejected: input.itemRejected ?? 0,
    errorSummary: input.errorSummary ?? null,
  }).where(eq(newsSyncRuns.id, syncRunId));
}

export async function getLatestCompletedNewsSyncRun() {
  const db = await getDb();
  if (!db) return null;
  const rows = await db.select().from(newsSyncRuns)
    .where(inArray(newsSyncRuns.status, ["success", "partial"]))
    .orderBy(desc(newsSyncRuns.completedAt))
    .limit(1);
  return rows[0] ?? null;
}

export async function recordNewsSyncRunSources(syncRunId: string, sourceRuns: SourceRunInput[]) {
  const db = await getDb();
  if (!db || sourceRuns.length === 0) return;
  for (const sourceRun of sourceRuns) {
    await db.insert(newsSyncRunSources).values({ ...sourceRun, syncRunId }).onDuplicateKeyUpdate({
      set: {
        endpointUrlSnapshot: sql.raw("VALUES(endpointUrlSnapshot)"),
        status: sql.raw("VALUES(news_sync_run_source_status)"),
        httpStatus: sql.raw("VALUES(httpStatus)"),
        startedAt: sql.raw("VALUES(startedAt)"),
        completedAt: sql.raw("VALUES(completedAt)"),
        itemFetched: sql.raw("VALUES(itemFetched)"),
        itemAccepted: sql.raw("VALUES(itemAccepted)"),
        errorSummary: sql.raw("VALUES(errorSummary)"),
      },
    });
  }
}

export async function upsertTourismServiceAlert(input: {
  newsItemId: number;
  syncRunId?: string;
  severity: "critical" | "warning";
  affectedService: string;
  detectedAt: Date;
  ruleVersion: string;
}) {
  const db = await getDb();
  if (!db) return;
  await db.insert(tourismServiceAlerts).values({
    ...input,
    syncRunId: input.syncRunId ?? null,
    status: "active",
    lastDetectedAt: input.detectedAt,
  }).onDuplicateKeyUpdate({
    set: {
      syncRunId: sql.raw("VALUES(syncRunId)"),
      severity: sql.raw("VALUES(tourism_service_alert_severity)"),
      affectedService: sql.raw("VALUES(affectedService)"),
      status: "active",
      lastDetectedAt: sql.raw("VALUES(lastDetectedAt)"),
      resolvedAt: null,
      ruleVersion: sql.raw("VALUES(ruleVersion)"),
    },
  });
}

export async function getInsightCacheEntry(namespace: string, cacheKeyHash: string, now = new Date()) {
  const db = await getDb();
  if (!db) return undefined;
  const row = (await db.select().from(insightCacheEntries).where(and(
    eq(insightCacheEntries.cacheNamespace, namespace),
    eq(insightCacheEntries.cacheKeyHash, cacheKeyHash),
    gt(insightCacheEntries.expiresAt, now),
  )).limit(1))[0];
  if (!row) return undefined;
  await db.update(insightCacheEntries).set({ lastAccessedAt: now }).where(eq(insightCacheEntries.id, row.id));
  return row;
}

export async function putInsightCacheEntry(input: {
  cacheNamespace: string;
  cacheKeyHash: string;
  inputFingerprint: string;
  payloadJson: Record<string, unknown>;
  promptVersion: string;
  model?: string;
  expiresAt: Date;
}) {
  const db = await getDb();
  if (!db) return;
  await db.insert(insightCacheEntries).values({
    ...input,
    model: input.model ?? null,
  }).onDuplicateKeyUpdate({
    set: {
      inputFingerprint: sql.raw("VALUES(inputFingerprint)"),
      payloadJson: sql.raw("VALUES(payloadJson)"),
      promptVersion: sql.raw("VALUES(promptVersion)"),
      model: sql.raw("VALUES(model)"),
      expiresAt: sql.raw("VALUES(expiresAt)"),
      lastAccessedAt: new Date(),
    },
  });
}

export async function ensureCountryIndicators(indicators: InsertCountryIndicator[]) {
  const db = await getDb();
  if (!db || indicators.length === 0) return new Map<string, number>();
  for (const indicator of indicators) {
    await db.insert(countryIndicators).values(indicator).onDuplicateKeyUpdate({
      set: {
        countryName: sql.raw("VALUES(countryName)"),
        label: sql.raw("VALUES(label)"),
        unit: sql.raw("VALUES(unit)"),
        periodicity: sql.raw("VALUES(periodicity)"),
        sourceName: sql.raw("VALUES(sourceName)"),
        sourceUrl: sql.raw("VALUES(sourceUrl)"),
        definition: sql.raw("VALUES(definition)"),
        refreshPolicy: sql.raw("VALUES(refreshPolicy)"),
        isActive: sql.raw("VALUES(isActive)"),
      },
    });
  }
  const keys = indicators.map(indicator => `${indicator.countryCode}:${indicator.indicatorCode}`);
  const rows = await db.select({ id: countryIndicators.id, countryCode: countryIndicators.countryCode, indicatorCode: countryIndicators.indicatorCode }).from(countryIndicators);
  return new Map(rows.filter(row => keys.includes(`${row.countryCode}:${row.indicatorCode}`)).map(row => [`${row.countryCode}:${row.indicatorCode}`, row.id]));
}

export async function upsertCountryIndicatorObservation(observation: InsertCountryIndicatorObservation) {
  const db = await getDb();
  if (!db) return;
  await db.insert(countryIndicatorObservations).values(observation).onDuplicateKeyUpdate({
    set: {
      value: sql.raw("VALUES(value)"),
      periodStart: sql.raw("VALUES(periodStart)"),
      periodEnd: sql.raw("VALUES(periodEnd)"),
      referenceDate: sql.raw("VALUES(referenceDate)"),
      publishedAt: sql.raw("VALUES(publishedAt)"),
      fetchedAt: sql.raw("VALUES(fetchedAt)"),
      status: sql.raw("VALUES(country_indicator_observation_status)"),
      sourceUrl: sql.raw("VALUES(sourceUrl)"),
      metadataJson: sql.raw("VALUES(metadataJson)"),
      note: sql.raw("VALUES(note)"),
    },
  });
}

export async function startCountryIndicatorRefreshRun(input: {
  triggerKind: "heartbeat" | "manual_audit" | "operations_replay";
  heartbeatTaskUid?: string;
  indicatorTotal: number;
}) {
  const db = await getDb();
  const id = randomUUID();
  if (!db) return id;
  await db.insert(countryIndicatorRefreshRuns).values({
    id,
    triggerKind: input.triggerKind,
    heartbeatTaskUid: input.heartbeatTaskUid ?? null,
    runStatus: "running",
    indicatorTotal: input.indicatorTotal,
  });
  return id;
}

export async function completeCountryIndicatorRefreshRun(refreshRunId: string, input: {
  runStatus: "success" | "partial" | "failed";
  completedAt: Date;
  indicatorSucceeded: number;
  indicatorFailed: number;
  observationPersisted: number;
  errorSummary?: string | null;
}) {
  const db = await getDb();
  if (!db) return;
  await db.update(countryIndicatorRefreshRuns).set({
    runStatus: input.runStatus,
    completedAt: input.completedAt,
    indicatorSucceeded: input.indicatorSucceeded,
    indicatorFailed: input.indicatorFailed,
    observationPersisted: input.observationPersisted,
    errorSummary: input.errorSummary ?? null,
  }).where(eq(countryIndicatorRefreshRuns.id, refreshRunId));
}

export async function recordCountryIndicatorRefreshItems(refreshRunId: string, items: Omit<InsertCountryIndicatorRefreshRunItem, "refreshRunId">[]) {
  const db = await getDb();
  if (!db || items.length === 0) return;
  for (const item of items) {
    await db.insert(countryIndicatorRefreshRunItems).values({ ...item, refreshRunId }).onDuplicateKeyUpdate({
      set: {
        itemStatus: sql.raw("VALUES(itemStatus)"),
        sourceUrlSnapshot: sql.raw("VALUES(sourceUrlSnapshot)"),
        referenceDate: sql.raw("VALUES(referenceDate)"),
        observationPersisted: sql.raw("VALUES(observationPersisted)"),
        errorSummary: sql.raw("VALUES(errorSummary)"),
        completedAt: sql.raw("VALUES(completedAt)"),
      },
    });
  }
}

export async function listLatestSyncRuns(limit = 10) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(newsSyncRuns).orderBy(desc(newsSyncRuns.startedAt)).limit(limit);
}

export async function listLatestCountryIndicatorObservations() {
  const db = await getDb();
  if (!db) return [];
  const rows = await db.select({
    indicatorId: countryIndicators.id,
    countryCode: countryIndicators.countryCode,
    countryName: countryIndicators.countryName,
    indicatorCode: countryIndicators.indicatorCode,
    label: countryIndicators.label,
    unit: countryIndicators.unit,
    periodicity: countryIndicators.periodicity,
    sourceName: countryIndicators.sourceName,
    sourceUrl: countryIndicators.sourceUrl,
    definition: countryIndicators.definition,
    value: countryIndicatorObservations.value,
    referenceDate: countryIndicatorObservations.referenceDate,
    publishedAt: countryIndicatorObservations.publishedAt,
    fetchedAt: countryIndicatorObservations.fetchedAt,
    status: countryIndicatorObservations.status,
    note: countryIndicatorObservations.note,
  }).from(countryIndicators).leftJoin(countryIndicatorObservations, eq(countryIndicators.id, countryIndicatorObservations.countryIndicatorId)).where(eq(countryIndicators.isActive, true)).orderBy(desc(countryIndicatorObservations.referenceDate));
  return Array.from(new Map(rows.map(row => [row.indicatorId, row])).values());
}

export async function getOperationsOverview() {
  const db = await getDb();
  if (!db) {
    return {
      latestRuns: [],
      sourceHealth: [],
      activeAlerts: [],
      cacheEntries: [],
      latestIndicatorObservations: [],
    };
  }

  const [latestRuns, sourceRows, activeAlerts, cacheEntries, indicatorRows] = await Promise.all([
    db.select().from(newsSyncRuns).orderBy(desc(newsSyncRuns.startedAt)).limit(12),
    db.select({
      id: newsSources.id,
      sourceKey: newsSources.sourceKey,
      displayName: newsSources.displayName,
      adapterKind: newsSources.adapterKind,
      endpointUrl: newsSources.endpointUrl,
      isRequired: newsSources.isRequired,
      isActive: newsSources.isActive,
      status: newsSyncRunSources.status,
      httpStatus: newsSyncRunSources.httpStatus,
      completedAt: newsSyncRunSources.completedAt,
      errorSummary: newsSyncRunSources.errorSummary,
      itemFetched: newsSyncRunSources.itemFetched,
    }).from(newsSources).leftJoin(newsSyncRunSources, eq(newsSources.id, newsSyncRunSources.newsSourceId)).orderBy(desc(newsSyncRunSources.completedAt)),
    db.select().from(tourismServiceAlerts).where(eq(tourismServiceAlerts.status, "active")).orderBy(desc(tourismServiceAlerts.lastDetectedAt)).limit(12),
    db.select({
      cacheNamespace: insightCacheEntries.cacheNamespace,
      createdAt: insightCacheEntries.createdAt,
      expiresAt: insightCacheEntries.expiresAt,
      lastAccessedAt: insightCacheEntries.lastAccessedAt,
      promptVersion: insightCacheEntries.promptVersion,
      model: insightCacheEntries.model,
    }).from(insightCacheEntries).orderBy(desc(insightCacheEntries.createdAt)).limit(20),
    db.select({
      indicatorId: countryIndicators.id,
      countryCode: countryIndicators.countryCode,
      countryName: countryIndicators.countryName,
      indicatorCode: countryIndicators.indicatorCode,
      label: countryIndicators.label,
      unit: countryIndicators.unit,
      periodicity: countryIndicators.periodicity,
      sourceName: countryIndicators.sourceName,
      sourceUrl: countryIndicators.sourceUrl,
      value: countryIndicatorObservations.value,
      referenceDate: countryIndicatorObservations.referenceDate,
      publishedAt: countryIndicatorObservations.publishedAt,
      fetchedAt: countryIndicatorObservations.fetchedAt,
      status: countryIndicatorObservations.status,
      note: countryIndicatorObservations.note,
    }).from(countryIndicators).leftJoin(countryIndicatorObservations, eq(countryIndicators.id, countryIndicatorObservations.countryIndicatorId)).where(eq(countryIndicators.isActive, true)).orderBy(desc(countryIndicatorObservations.referenceDate)),
  ]);

  const sourceHealth = Array.from(new Map(sourceRows.map(row => [row.id, row])).values());
  const latestIndicatorObservations = Array.from(new Map(indicatorRows.map(row => [row.indicatorId, row])).values());
  return { latestRuns, sourceHealth, activeAlerts, cacheEntries, latestIndicatorObservations };
}
