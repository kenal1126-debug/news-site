import { createHash } from "node:crypto";
import { and, desc, gte, lt, sql } from "drizzle-orm";
import type { InsertNewsItem } from "../../drizzle/schema";
import { newsItems } from "../../drizzle/schema";
import { normalizeNewsTitle } from "../../shared/newsMerge";
import { getDb } from "../db";

export const PRESERVE_IMAGE_ON_DUPLICATE_SQL = "COALESCE(VALUES(imageUrl), imageUrl)";
export const NEWS_UPSERT_BATCH_SIZE = 50;
export const NEWS_GUID_MAX_LENGTH = 512;

export function preserveExistingImageUrl(existing: string | null | undefined, incoming: string | null | undefined) {
  return incoming?.trim() ? incoming : existing ?? null;
}

export function normalizeNewsGuidForPersistence(guid: string) {
  const normalized = guid.trim();
  if (normalized.length <= NEWS_GUID_MAX_LENGTH) return normalized;
  return `sha256:${createHash("sha256").update(normalized).digest("hex")}`;
}

export function normalizeNewsItemsForPersistence(items: InsertNewsItem[]) {
  return items.map((item) => ({ ...item, guid: normalizeNewsGuidForPersistence(item.guid) }));
}

export async function listRecentNews(since: Date) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(newsItems).where(gte(newsItems.publishedAt, since)).orderBy(desc(newsItems.publishedAt));
}

export async function listNewsBetween(start: Date, end: Date) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(newsItems).where(and(gte(newsItems.publishedAt, start), lt(newsItems.publishedAt, end))).orderBy(desc(newsItems.publishedAt));
}

export function collapseNewsItemsForPersistence(items: InsertNewsItem[]) {
  const collapsed = new Map<string, InsertNewsItem>();
  for (const item of items) {
    const titleKey = normalizeNewsTitle(item.title);
    const key = titleKey.length >= 8 ? `title:${titleKey}` : `url:${item.url}`;
    const previous = collapsed.get(key);
    if (!previous) {
      collapsed.set(key, item);
      continue;
    }
    const preferred = item.imageUrl && !previous.imageUrl ? item : previous.imageUrl && !item.imageUrl ? previous : item.publishedAt > previous.publishedAt ? item : previous;
    collapsed.set(key, {
      ...previous,
      ...preferred,
      imageUrl: preferred.imageUrl || previous.imageUrl || item.imageUrl,
      summary: (preferred.summary?.length ?? 0) >= (previous.summary?.length ?? 0) ? preferred.summary : previous.summary,
    });
  }
  return Array.from(collapsed.values());
}

export function chunkNewsItemsForPersistence(items: InsertNewsItem[], batchSize = NEWS_UPSERT_BATCH_SIZE) {
  if (!Number.isInteger(batchSize) || batchSize < 1) throw new Error("batchSize must be a positive integer");
  const batches: InsertNewsItem[][] = [];
  for (let index = 0; index < items.length; index += batchSize) batches.push(items.slice(index, index + batchSize));
  return batches;
}

export async function insertNewsItems(items: InsertNewsItem[]) {
  const db = await getDb();
  if (!db || items.length === 0) return;
  const persistedItems = collapseNewsItemsForPersistence(normalizeNewsItemsForPersistence(items));
  for (const batch of chunkNewsItemsForPersistence(persistedItems)) {
    await db.insert(newsItems).values(batch).onDuplicateKeyUpdate({
      set: {
        source: sql.raw("VALUES(source)"),
        title: sql.raw("VALUES(title)"),
        summary: sql.raw("VALUES(summary)"),
        url: sql.raw("VALUES(url)"),
        imageUrl: sql.raw(PRESERVE_IMAGE_ON_DUPLICATE_SQL),
        publishedAt: sql.raw("VALUES(publishedAt)"),
      },
    });
  }
}
