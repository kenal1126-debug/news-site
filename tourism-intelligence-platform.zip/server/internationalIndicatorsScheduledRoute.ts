import { createInternationalIndicatorsScheduledHandler } from "./internationalIndicatorsScheduledHandler";

type AppLike = { post: (path: string, handler: ReturnType<typeof createInternationalIndicatorsScheduledHandler>) => unknown };

export function registerInternationalIndicatorsScheduledRoute(app: AppLike, deps: Parameters<typeof createInternationalIndicatorsScheduledHandler>[0]) {
  app.post("/api/scheduled/refresh-international-indicators", createInternationalIndicatorsScheduledHandler(deps));
}
