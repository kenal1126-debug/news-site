import { beforeEach, describe, expect, it, vi } from "vitest";

const { getLatestCompletedNewsSyncRun } = vi.hoisted(() => ({ getLatestCompletedNewsSyncRun: vi.fn() }));

vi.mock("../repositories/operationsRepository", () => ({
  getLatestCompletedNewsSyncRun,
}));

import { newsRouter } from "./newsRouter";

describe("newsRouter.latestSync", () => {
  beforeEach(() => {
    getLatestCompletedNewsSyncRun.mockReset();
  });

  it("returns the latest completed sync record used by the dashboard audit payload", async () => {
    const completedAt = new Date("2026-08-30T02:00:00.000Z");
    getLatestCompletedNewsSyncRun.mockResolvedValue({
      id: "sync-run-20260830-001",
      completedAt,
      status: "success",
    });

    const result = await newsRouter.createCaller({} as never).latestSync();

    expect(result).toEqual({
      id: "sync-run-20260830-001",
      completedAt,
      status: "success",
    });
    expect(getLatestCompletedNewsSyncRun).toHaveBeenCalledOnce();
  });
});

export {};

