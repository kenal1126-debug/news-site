import { beforeEach, describe, expect, it, vi } from "vitest";

const { getOperationsOverview } = vi.hoisted(() => ({ getOperationsOverview: vi.fn() }));

vi.mock("../repositories/operationsRepository", () => ({ getOperationsOverview }));

import { operationsRouter } from "./operationsRouter";

describe("operations router", () => {
  beforeEach(() => {
    getOperationsOverview.mockReset();
  });

  it("returns the immutable operations overview to an administrator", async () => {
    const overview = { latestRuns: [], sourceHealth: [], activeAlerts: [], cacheEntries: [], latestIndicatorObservations: [] };
    getOperationsOverview.mockResolvedValue(overview);
    const caller = operationsRouter.createCaller({ user: { role: "admin" } } as never);
    await expect(caller.overview()).resolves.toEqual(overview);
    expect(getOperationsOverview).toHaveBeenCalledOnce();
  });

  it("rejects a non-administrator without invoking the operations repository", async () => {
    const caller = operationsRouter.createCaller({ user: { role: "user" } } as never);
    await expect(caller.overview()).rejects.toMatchObject({ code: "FORBIDDEN" });
    expect(getOperationsOverview).not.toHaveBeenCalled();
  });
});
