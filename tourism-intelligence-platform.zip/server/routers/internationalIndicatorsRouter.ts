import { publicProcedure, router } from "../_core/trpc";
import { listLatestCountryIndicatorObservations } from "../repositories/operationsRepository";

export const internationalIndicatorsRouter = router({
  latest: publicProcedure.query(async () => listLatestCountryIndicatorObservations()),
});
