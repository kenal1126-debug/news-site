import { beforeEach, describe, expect, it, vi } from "vitest";

const listLatestCountryIndicatorObservations = vi.hoisted(() => vi.fn());
vi.mock("../repositories/operationsRepository", () => ({ listLatestCountryIndicatorObservations }));

import { internationalIndicatorsRouter } from "./internationalIndicatorsRouter";

describe("internationalIndicators.latest", () => {
  beforeEach(() => listLatestCountryIndicatorObservations.mockReset());

  it("returns the read-only latest-observation list for the homepage", async () => {
    const rows = [{ countryCode: "AUS", indicatorCode: "inbound_arrivals", value: "566910.0000", referenceDate: new Date("2026-06-30T00:00:00Z") }];
    listLatestCountryIndicatorObservations.mockResolvedValue(rows);
    const result = await internationalIndicatorsRouter.createCaller({} as never).latest();
    expect(result).toEqual(rows);
    expect(listLatestCountryIndicatorObservations).toHaveBeenCalledTimes(1);
  });
});
