import { router, publicProcedure } from "../_core/trpc";
import { analyzeEnglishTrendKeywords } from "../englishKeywordNlp";
import { listNewsBetween, listRecentNews } from "../repositories/newsRepository";
import { getLatestCompletedNewsSyncRun } from "../repositories/operationsRepository";

function recentNewsSince() {
  return new Date(Date.now() - 14 * 24 * 60 * 60 * 1000);
}

function demandComparisonWindows(now = new Date()) {
  const currentStart = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
  const priorStart = new Date(now.getTime() - 14 * 24 * 60 * 60 * 1000);
  return { currentStart, priorStart, now };
}

export const newsRouter = router({
  recent: publicProcedure.query(async () => listRecentNews(recentNewsSince())),
  englishKeywordTerms: publicProcedure.query(async () => analyzeEnglishTrendKeywords(await listRecentNews(recentNewsSince()))),
  latestSync: publicProcedure.query(async () => getLatestCompletedNewsSyncRun()),
  demandComparison: publicProcedure.query(async () => {
    const { currentStart, priorStart, now } = demandComparisonWindows();
    const [current, prior] = await Promise.all([
      listNewsBetween(currentStart, now),
      listNewsBetween(priorStart, currentStart),
    ]);
    return { current, prior, currentStart, priorStart };
  }),
});
