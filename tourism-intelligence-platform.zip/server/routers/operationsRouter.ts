import { adminProcedure, router } from "../_core/trpc";
import { getOperationsOverview } from "../repositories/operationsRepository";

/** Internal, read-only operations surface for audit and daily sync supervision. */
export const operationsRouter = router({
  overview: adminProcedure.query(async () => getOperationsOverview()),
});
