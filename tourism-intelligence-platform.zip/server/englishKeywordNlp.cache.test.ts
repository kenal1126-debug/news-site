import { beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({
  getInsightCacheEntry: vi.fn().mockResolvedValue(undefined),
  putInsightCacheEntry: vi.fn().mockResolvedValue(undefined),
  invalidateInsightCacheNamespace: vi.fn().mockResolvedValue(undefined),
  invokeLLM: vi.fn().mockResolvedValue({ choices: [{ message: { content: JSON.stringify({ terms: ["airline"] }) } }] }),
}));

vi.mock("./repositories/operationsRepository", () => ({
  ENGLISH_KEYWORD_CACHE_NAMESPACE: "english-keyword-terms",
  getInsightCacheEntry: mocks.getInsightCacheEntry,
  hashTraceabilityInput: (value: string) => `hash:${value}`,
  invalidateInsightCacheNamespace: mocks.invalidateInsightCacheNamespace,
  putInsightCacheEntry: mocks.putInsightCacheEntry,
}));

vi.mock("./_core/llm", () => ({ invokeLLM: mocks.invokeLLM }));

describe("英文文字雲同步後快取", () => {
  beforeEach(() => {
    vi.resetModules();
    mocks.getInsightCacheEntry.mockClear().mockResolvedValue(undefined);
    mocks.putInsightCacheEntry.mockClear().mockResolvedValue(undefined);
    mocks.invalidateInsightCacheNamespace.mockClear().mockResolvedValue(undefined);
    mocks.invokeLLM.mockClear().mockResolvedValue({ choices: [{ message: { content: JSON.stringify({ terms: ["airline"] }) } }] });
  });

  it("invalidates the cached analysis so the next query re-analyzes the latest 14-day news", async () => {
    const { analyzeEnglishTrendKeywords, invalidateEnglishTrendKeywordCache } = await import("./englishKeywordNlp");
    const latestNews = [{ source: "BBC Travel", title: "Airline routes expand", summary: "New airline routes support visitor demand." }];

    await analyzeEnglishTrendKeywords(latestNews);
    await analyzeEnglishTrendKeywords(latestNews);
    expect(mocks.invokeLLM).toHaveBeenCalledTimes(1);

    await invalidateEnglishTrendKeywordCache();
    expect(mocks.invalidateInsightCacheNamespace).toHaveBeenCalledWith("english-keyword-terms");
    await analyzeEnglishTrendKeywords(latestNews);
    expect(mocks.invokeLLM).toHaveBeenCalledTimes(2);
  });
});
