type CronUser = { isCron?: boolean; taskUid?: string };
type RequestLike = { originalUrl?: string };
type ResponseLike = { status: (code: number) => ResponseLike; json: (body: unknown) => unknown };

export function createInternationalIndicatorsScheduledHandler(deps: {
  authenticate: (request: RequestLike) => Promise<CronUser>;
  refresh: (options: { triggerKind: "heartbeat"; heartbeatTaskUid: string }) => Promise<unknown>;
  now?: () => Date;
}) {
  return async (req: RequestLike, res: ResponseLike) => {
    try {
      const user = await deps.authenticate(req);
      if (!user.isCron || !user.taskUid) return res.status(403).json({ error: "cron-only" });
      return res.json({ ok: true, ...(await deps.refresh({ triggerKind: "heartbeat", heartbeatTaskUid: user.taskUid }) as Record<string, unknown>) });
    } catch (error) {
      return res.status(500).json({ error: String(error), context: { url: req.originalUrl }, timestamp: (deps.now ?? (() => new Date()))().toISOString() });
    }
  };
}
