# Google News 標題反查驗證

驗證日期：2026-08-14。

案例標題：烏干達要求台人持中國護照蓋入境章 外交部嚴正關切。

實際首頁卡片顯示來源為「經濟日報」，圖片 src 為 `https://lh3.googleusercontent.com/J6_coFbogxhRI9iM864NL_liGXvsQp2AupsKei7z0cNNfDvGUmWUy20nuUhkREQyrpY4bEeIBuc=s0-w300`，查看原文 href 為 Google News RSS article URL。這表示當經濟日報原文圖片不足時，系統會以標題反查 Google News，採用第一篇標題相符結果的代表圖，並將卡片來源文字更新為 Google News RSS 的 `<source>` 實際媒體名稱。

資料庫回填後，此案例標題維持原文識別，source 已更新為「經濟日報」，imageUrl 保留 Google News 結果的代表圖；原文 href 導向相符的 Google News 項目，點擊後由 Google News 進一步導向該結果的發出媒體。

測試結果：新聞同步測試新增第一篇相符 Google News 結果解析，7 個測試檔、20 項測試、TypeScript 檢查與正式建置均通過。真實同步回填 122 則，唯一失敗來源為自由時報 RSS HTTP 404，與此次 Google News 反查流程無關。

## Direct URL 解碼更新

最終透過 Google News batchexecute 解碼流程，烏干達案例已回填為經濟日報 direct URL：`https://money.udn.com/money/story/7307/9689668?from=edn_newestlist_rank`。資料庫中的 source 為「經濟日報」，imageUrl 為 `https://money.udn.com/static/img/moneyudn.jpg`，首頁卡片因此會直接導向經濟日報文章，而非停留在 `news.google.com/rss/articles/...` 聚合網址。

## 最終前端 DOM 驗證

重新同步後，首頁 DOM 抽查結果為：source「經濟日報」；href `https://money.udn.com/money/story/7307/9689668?from=edn_newestlist_rank`；image `https://money.udn.com/static/img/moneyudn.jpg`。卡片的「查看原文」已不再指向 `news.google.com/rss/articles/...`，而是直接指向經濟日報文章；桌面與手機版截圖均完成，未見水平溢出或來源／圖片欄位錯位。

## 雙斷點交付前驗證

桌面版 DOM 已抽查到 direct href `https://money.udn.com/money/story/7307/9689668?from=edn_newestlist_rank`、source「經濟日報」與 `money.udn.com` 圖片。手機版以 375×812 長頁截圖驗證同一新聞卡片的圖片、來源與查看原文區塊在窄螢幕維持可讀，沒有水平溢出或錯位。
