# 重複新聞合併稽核

指定新聞「數位產業署舉辦AI DEMO DAY 促成科技業者與觀光旅宿產業交流媒合 以AI驅動智慧觀光 八大解方助攻旅宿業數位轉型 - 經濟日報」在資料庫清理後只保留 1 筆，id 30067。保留版本的 source 為「經濟日報」，direct URL 為 `https://money.udn.com/money/story/11799/9691012`，圖片為 `https://pgw.udn.com.tw/gw/photo.php?u=https://uc.udn.com.tw/photo/t3/2026/08/14/35229393.jpg&M=1&s=Y&x=0&y=0&sw=1280&sh=797&sl=W&fw=1050&exp=3600`。

首頁桌面版 DOM 抽查回傳 `count: 1`，且卡片同時具有上述 source、href 與 image。手機版以 375×812 長頁截圖驗證同一保留卡片的圖片、來源與查看原文區塊沒有水平溢出或錯位。共享合併工具及資料庫持久化折疊均加入圖片優先與發布日期 tie-break。

## 手機版抽查補充

指定 AI DEMO DAY 新聞的卡片 DOM 抽查回傳 `count: 1`、source「經濟日報」、href `https://money.udn.com/money/story/11799/9691012` 與圖片 `https://pgw.udn.com.tw/gw/photo.php?...35229393.jpg...`。手機版 375×812 截圖已確認窄螢幕呈現；瀏覽器控制台環境本身維持 1280px viewport，因此 DOM 欄位抽查與手機截圖分開保存，不將桌面 viewport 誤稱為手機 DOM。

## 真正手機 viewport DOM 稽核

使用 375×812 無頭瀏覽器重新載入首頁並以 `article` 節點計數，指定 AI DEMO DAY 新聞結果為 `count: 1`。唯一卡片的 source 為「經濟日報」，href 為 `https://money.udn.com/money/story/11799/9691012`，image src 為 `https://pgw.udn.com.tw/gw/photo.php?u=https://uc.udn.com.tw/photo/t3/2026/08/14/35229393.jpg&M=1&s=Y&x=0&y=0&sw=1280&sh=797&sl=W&fw=1050&exp=3600`。
