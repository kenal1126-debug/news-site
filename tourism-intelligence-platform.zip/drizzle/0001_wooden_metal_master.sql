CREATE TABLE `country_indicator_observations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`countryIndicatorId` int NOT NULL,
	`value` decimal(20,4) NOT NULL,
	`periodStart` timestamp NOT NULL,
	`periodEnd` timestamp NOT NULL,
	`referenceDate` timestamp NOT NULL,
	`publishedAt` timestamp,
	`fetchedAt` timestamp NOT NULL DEFAULT (now()),
	`country_indicator_observation_status` enum('provisional','final','revised') NOT NULL DEFAULT 'final',
	`sourceUrl` varchar(2048) NOT NULL,
	`sourceFingerprint` char(64) NOT NULL,
	`metadataJson` json NOT NULL,
	`note` varchar(1000),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `country_indicator_observations_id` PRIMARY KEY(`id`),
	CONSTRAINT `country_indicator_observations_indicator_fingerprint_unique` UNIQUE(`countryIndicatorId`,`sourceFingerprint`)
);
--> statement-breakpoint
CREATE TABLE `country_indicators` (
	`id` int AUTO_INCREMENT NOT NULL,
	`countryCode` varchar(3) NOT NULL,
	`countryName` varchar(80) NOT NULL,
	`indicatorCode` varchar(80) NOT NULL,
	`label` varchar(160) NOT NULL,
	`unit` varchar(32) NOT NULL,
	`periodicity` varchar(24) NOT NULL,
	`sourceName` varchar(160) NOT NULL,
	`sourceUrl` varchar(2048) NOT NULL,
	`definition` text NOT NULL,
	`refreshPolicy` varchar(64) NOT NULL,
	`isActive` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `country_indicators_id` PRIMARY KEY(`id`),
	CONSTRAINT `country_indicators_country_code_indicator_code_unique` UNIQUE(`countryCode`,`indicatorCode`)
);
--> statement-breakpoint
CREATE TABLE `insight_cache_entries` (
	`id` int AUTO_INCREMENT NOT NULL,
	`cacheNamespace` varchar(80) NOT NULL,
	`cacheKeyHash` char(64) NOT NULL,
	`payloadJson` json NOT NULL,
	`inputFingerprint` char(64) NOT NULL,
	`promptVersion` varchar(64) NOT NULL,
	`model` varchar(64),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`expiresAt` timestamp NOT NULL,
	`lastAccessedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `insight_cache_entries_id` PRIMARY KEY(`id`),
	CONSTRAINT `insight_cache_entries_namespace_key_unique` UNIQUE(`cacheNamespace`,`cacheKeyHash`)
);
--> statement-breakpoint
CREATE TABLE `news_sources` (
	`id` int AUTO_INCREMENT NOT NULL,
	`sourceKey` varchar(128) NOT NULL,
	`displayName` varchar(160) NOT NULL,
	`adapterKind` varchar(48) NOT NULL,
	`endpointUrl` varchar(2048) NOT NULL,
	`categoryHint` varchar(120),
	`language` varchar(16),
	`isRequired` boolean NOT NULL DEFAULT false,
	`isActive` boolean NOT NULL DEFAULT true,
	`catalogVersion` varchar(64) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `news_sources_id` PRIMARY KEY(`id`),
	CONSTRAINT `news_sources_source_key_unique` UNIQUE(`sourceKey`)
);
--> statement-breakpoint
CREATE TABLE `news_sync_run_sources` (
	`id` int AUTO_INCREMENT NOT NULL,
	`syncRunId` varchar(36) NOT NULL,
	`newsSourceId` int NOT NULL,
	`endpointUrlSnapshot` varchar(2048) NOT NULL,
	`news_sync_run_source_status` enum('success','failed','skipped') NOT NULL,
	`httpStatus` int,
	`startedAt` timestamp NOT NULL,
	`completedAt` timestamp NOT NULL,
	`itemFetched` int NOT NULL DEFAULT 0,
	`itemAccepted` int NOT NULL DEFAULT 0,
	`errorSummary` varchar(1000),
	CONSTRAINT `news_sync_run_sources_id` PRIMARY KEY(`id`),
	CONSTRAINT `news_sync_run_sources_run_source_unique` UNIQUE(`syncRunId`,`newsSourceId`)
);
--> statement-breakpoint
CREATE TABLE `news_sync_runs` (
	`id` varchar(36) NOT NULL,
	`triggerKind` varchar(24) NOT NULL,
	`heartbeatTaskUid` varchar(65),
	`news_sync_run_status` enum('running','success','partial','failed') NOT NULL,
	`startedAt` timestamp NOT NULL DEFAULT (now()),
	`completedAt` timestamp,
	`cutoffAt` timestamp NOT NULL,
	`sourceTotal` int NOT NULL DEFAULT 0,
	`sourceSucceeded` int NOT NULL DEFAULT 0,
	`sourceFailed` int NOT NULL DEFAULT 0,
	`itemFetched` int NOT NULL DEFAULT 0,
	`itemPersisted` int NOT NULL DEFAULT 0,
	`itemRejected` int NOT NULL DEFAULT 0,
	`errorSummary` varchar(1000),
	CONSTRAINT `news_sync_runs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `tourism_service_alerts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`newsItemId` int NOT NULL,
	`syncRunId` varchar(36),
	`tourism_service_alert_severity` enum('critical','warning') NOT NULL,
	`affectedService` varchar(255) NOT NULL,
	`tourism_service_alert_status` enum('active','resolved','expired') NOT NULL DEFAULT 'active',
	`detectedAt` timestamp NOT NULL,
	`lastDetectedAt` timestamp NOT NULL,
	`resolvedAt` timestamp,
	`ruleVersion` varchar(64) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `tourism_service_alerts_id` PRIMARY KEY(`id`),
	CONSTRAINT `tourism_service_alerts_news_item_unique` UNIQUE(`newsItemId`)
);
--> statement-breakpoint
ALTER TABLE `country_indicator_observations` ADD CONSTRAINT `fk_obs_indicator` FOREIGN KEY (`countryIndicatorId`) REFERENCES `country_indicators`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `news_sync_run_sources` ADD CONSTRAINT `fk_run_source_run` FOREIGN KEY (`syncRunId`) REFERENCES `news_sync_runs`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `news_sync_run_sources` ADD CONSTRAINT `fk_run_source_source` FOREIGN KEY (`newsSourceId`) REFERENCES `news_sources`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `tourism_service_alerts` ADD CONSTRAINT `fk_alert_news_item` FOREIGN KEY (`newsItemId`) REFERENCES `news_items`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `tourism_service_alerts` ADD CONSTRAINT `fk_alert_sync_run` FOREIGN KEY (`syncRunId`) REFERENCES `news_sync_runs`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `country_indicator_observations_indicator_reference_date_idx` ON `country_indicator_observations` (`countryIndicatorId`,`referenceDate`);--> statement-breakpoint
CREATE INDEX `country_indicator_observations_fetched_at_idx` ON `country_indicator_observations` (`fetchedAt`);--> statement-breakpoint
CREATE INDEX `country_indicators_active_country_idx` ON `country_indicators` (`isActive`,`countryCode`);--> statement-breakpoint
CREATE INDEX `insight_cache_entries_namespace_expires_at_idx` ON `insight_cache_entries` (`cacheNamespace`,`expiresAt`);--> statement-breakpoint
CREATE INDEX `news_sources_adapter_kind_idx` ON `news_sources` (`adapterKind`);--> statement-breakpoint
CREATE INDEX `news_sources_is_active_idx` ON `news_sources` (`isActive`);--> statement-breakpoint
CREATE INDEX `news_sync_run_sources_source_status_completed_at_idx` ON `news_sync_run_sources` (`newsSourceId`,`news_sync_run_source_status`,`completedAt`);--> statement-breakpoint
CREATE INDEX `news_sync_run_sources_run_id_idx` ON `news_sync_run_sources` (`syncRunId`);--> statement-breakpoint
CREATE INDEX `news_sync_runs_status_started_at_idx` ON `news_sync_runs` (`news_sync_run_status`,`startedAt`);--> statement-breakpoint
CREATE INDEX `news_sync_runs_task_uid_idx` ON `news_sync_runs` (`heartbeatTaskUid`);--> statement-breakpoint
CREATE INDEX `news_sync_runs_started_at_idx` ON `news_sync_runs` (`startedAt`);--> statement-breakpoint
CREATE INDEX `tourism_service_alerts_status_detected_at_idx` ON `tourism_service_alerts` (`tourism_service_alert_status`,`detectedAt`);--> statement-breakpoint
CREATE INDEX `tourism_service_alerts_run_id_idx` ON `tourism_service_alerts` (`syncRunId`);
