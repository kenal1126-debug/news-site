CREATE TABLE `country_indicator_refresh_run_items` (
	`id` int AUTO_INCREMENT NOT NULL,
	`refreshRunId` varchar(36) NOT NULL,
	`countryIndicatorId` int NOT NULL,
	`itemStatus` enum('success','failed','skipped') NOT NULL,
	`sourceUrlSnapshot` varchar(2048) NOT NULL,
	`referenceDate` timestamp,
	`observationPersisted` boolean NOT NULL DEFAULT false,
	`errorSummary` varchar(1000),
	`completedAt` timestamp NOT NULL,
	CONSTRAINT `country_indicator_refresh_run_items_id` PRIMARY KEY(`id`),
	CONSTRAINT `country_indicator_refresh_run_items_run_indicator_unique` UNIQUE(`refreshRunId`,`countryIndicatorId`)
);
--> statement-breakpoint
CREATE TABLE `country_indicator_refresh_runs` (
	`id` varchar(36) NOT NULL,
	`triggerKind` varchar(24) NOT NULL,
	`heartbeatTaskUid` varchar(65),
	`runStatus` enum('running','success','partial','failed') NOT NULL,
	`startedAt` timestamp NOT NULL DEFAULT (now()),
	`completedAt` timestamp,
	`indicatorTotal` int NOT NULL DEFAULT 0,
	`indicatorSucceeded` int NOT NULL DEFAULT 0,
	`indicatorFailed` int NOT NULL DEFAULT 0,
	`observationPersisted` int NOT NULL DEFAULT 0,
	`errorSummary` varchar(1000),
	CONSTRAINT `country_indicator_refresh_runs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `country_indicator_refresh_run_items` ADD CONSTRAINT `ind_refresh_item_run_fk` FOREIGN KEY (`refreshRunId`) REFERENCES `country_indicator_refresh_runs`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `country_indicator_refresh_run_items` ADD CONSTRAINT `ind_refresh_item_indicator_fk` FOREIGN KEY (`countryIndicatorId`) REFERENCES `country_indicators`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `country_indicator_refresh_run_items_run_id_idx` ON `country_indicator_refresh_run_items` (`refreshRunId`);--> statement-breakpoint
CREATE INDEX `ind_refresh_item_status_at_idx` ON `country_indicator_refresh_run_items` (`countryIndicatorId`,`itemStatus`,`completedAt`);--> statement-breakpoint
CREATE INDEX `country_indicator_refresh_runs_status_started_at_idx` ON `country_indicator_refresh_runs` (`runStatus`,`startedAt`);--> statement-breakpoint
CREATE INDEX `country_indicator_refresh_runs_task_uid_idx` ON `country_indicator_refresh_runs` (`heartbeatTaskUid`);
