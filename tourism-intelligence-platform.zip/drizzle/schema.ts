import { boolean, char, decimal, index, int, json, mysqlEnum, mysqlTable, text, timestamp, uniqueIndex, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const newsItems = mysqlTable("news_items", {
  id: int("id").autoincrement().primaryKey(),
  source: varchar("source", { length: 120 }).notNull(),
  title: text("title").notNull(),
  summary: text("summary"),
  url: varchar("url", { length: 1000 }).notNull().unique(),
  imageUrl: varchar("imageUrl", { length: 1000 }),
  publishedAt: timestamp("publishedAt").notNull(),
  guid: varchar("guid", { length: 512 }).notNull().unique(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => ({
  publishedAtIdx: index("news_items_published_at_idx").on(table.publishedAt),
}));

export type NewsItem = typeof newsItems.$inferSelect;
export type InsertNewsItem = typeof newsItems.$inferInsert;

/**
 * A configured fetch entry point. This intentionally records the execution
 * catalog separately from the publisher eventually attributed to a news item.
 */
export const newsSources = mysqlTable("news_sources", {
  id: int("id").autoincrement().primaryKey(),
  sourceKey: varchar("sourceKey", { length: 128 }).notNull(),
  displayName: varchar("displayName", { length: 160 }).notNull(),
  adapterKind: varchar("adapterKind", { length: 48 }).notNull(),
  endpointUrl: varchar("endpointUrl", { length: 2048 }).notNull(),
  categoryHint: varchar("categoryHint", { length: 120 }),
  language: varchar("language", { length: 16 }),
  isRequired: boolean("isRequired").default(false).notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  catalogVersion: varchar("catalogVersion", { length: 64 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => ({
  sourceKeyUnique: uniqueIndex("news_sources_source_key_unique").on(table.sourceKey),
  adapterKindIdx: index("news_sources_adapter_kind_idx").on(table.adapterKind),
  isActiveIdx: index("news_sources_is_active_idx").on(table.isActive),
}));

export type NewsSource = typeof newsSources.$inferSelect;
export type InsertNewsSource = typeof newsSources.$inferInsert;

export const newsSyncRunStatus = mysqlEnum("news_sync_run_status", ["running", "success", "partial", "failed"]);

/** A single Heartbeat or authorised audit execution of the canonical news pipeline. */
export const newsSyncRuns = mysqlTable("news_sync_runs", {
  id: varchar("id", { length: 36 }).primaryKey(),
  triggerKind: varchar("triggerKind", { length: 24 }).notNull(),
  heartbeatTaskUid: varchar("heartbeatTaskUid", { length: 65 }),
  status: newsSyncRunStatus.notNull(),
  startedAt: timestamp("startedAt").defaultNow().notNull(),
  completedAt: timestamp("completedAt"),
  cutoffAt: timestamp("cutoffAt").notNull(),
  sourceTotal: int("sourceTotal").default(0).notNull(),
  sourceSucceeded: int("sourceSucceeded").default(0).notNull(),
  sourceFailed: int("sourceFailed").default(0).notNull(),
  itemFetched: int("itemFetched").default(0).notNull(),
  itemPersisted: int("itemPersisted").default(0).notNull(),
  itemRejected: int("itemRejected").default(0).notNull(),
  errorSummary: varchar("errorSummary", { length: 1000 }),
}, table => ({
  statusStartedAtIdx: index("news_sync_runs_status_started_at_idx").on(table.status, table.startedAt),
  heartbeatTaskUidIdx: index("news_sync_runs_task_uid_idx").on(table.heartbeatTaskUid),
  startedAtIdx: index("news_sync_runs_started_at_idx").on(table.startedAt),
}));

export type NewsSyncRun = typeof newsSyncRuns.$inferSelect;
export type InsertNewsSyncRun = typeof newsSyncRuns.$inferInsert;

export const newsSyncRunSourceStatus = mysqlEnum("news_sync_run_source_status", ["success", "failed", "skipped"]);

/** Source-level outcome for one news sync run, including safe error diagnostics and HTTP status. */
export const newsSyncRunSources = mysqlTable("news_sync_run_sources", {
  id: int("id").autoincrement().primaryKey(),
  syncRunId: varchar("syncRunId", { length: 36 }).notNull().references(() => newsSyncRuns.id, { onDelete: "cascade" }),
  newsSourceId: int("newsSourceId").notNull().references(() => newsSources.id),
  endpointUrlSnapshot: varchar("endpointUrlSnapshot", { length: 2048 }).notNull(),
  status: newsSyncRunSourceStatus.notNull(),
  httpStatus: int("httpStatus"),
  startedAt: timestamp("startedAt").notNull(),
  completedAt: timestamp("completedAt").notNull(),
  itemFetched: int("itemFetched").default(0).notNull(),
  itemAccepted: int("itemAccepted").default(0).notNull(),
  errorSummary: varchar("errorSummary", { length: 1000 }),
}, table => ({
  runSourceUnique: uniqueIndex("news_sync_run_sources_run_source_unique").on(table.syncRunId, table.newsSourceId),
  sourceStatusCompletedAtIdx: index("news_sync_run_sources_source_status_completed_at_idx").on(table.newsSourceId, table.status, table.completedAt),
  syncRunIdIdx: index("news_sync_run_sources_run_id_idx").on(table.syncRunId),
}));

export type NewsSyncRunSource = typeof newsSyncRunSources.$inferSelect;
export type InsertNewsSyncRunSource = typeof newsSyncRunSources.$inferInsert;

export const tourismServiceAlertSeverity = mysqlEnum("tourism_service_alert_severity", ["critical", "warning"]);
export const tourismServiceAlertStatus = mysqlEnum("tourism_service_alert_status", ["active", "resolved", "expired"]);

/** Persisted snapshot of a service-disruption alert derived from a source news item. */
export const tourismServiceAlerts = mysqlTable("tourism_service_alerts", {
  id: int("id").autoincrement().primaryKey(),
  newsItemId: int("newsItemId").notNull().references(() => newsItems.id),
  syncRunId: varchar("syncRunId", { length: 36 }).references(() => newsSyncRuns.id),
  severity: tourismServiceAlertSeverity.notNull(),
  affectedService: varchar("affectedService", { length: 255 }).notNull(),
  status: tourismServiceAlertStatus.default("active").notNull(),
  detectedAt: timestamp("detectedAt").notNull(),
  lastDetectedAt: timestamp("lastDetectedAt").notNull(),
  resolvedAt: timestamp("resolvedAt"),
  ruleVersion: varchar("ruleVersion", { length: 64 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => ({
  newsItemUnique: uniqueIndex("tourism_service_alerts_news_item_unique").on(table.newsItemId),
  activeAlertIdx: index("tourism_service_alerts_status_detected_at_idx").on(table.status, table.detectedAt),
  syncRunIdIdx: index("tourism_service_alerts_run_id_idx").on(table.syncRunId),
}));

export type TourismServiceAlert = typeof tourismServiceAlerts.$inferSelect;
export type InsertTourismServiceAlert = typeof tourismServiceAlerts.$inferInsert;

/** Durable cache metadata for computed insight results, with no raw news-content or prompt storage. */
export const insightCacheEntries = mysqlTable("insight_cache_entries", {
  id: int("id").autoincrement().primaryKey(),
  cacheNamespace: varchar("cacheNamespace", { length: 80 }).notNull(),
  cacheKeyHash: char("cacheKeyHash", { length: 64 }).notNull(),
  payloadJson: json("payloadJson").notNull(),
  inputFingerprint: char("inputFingerprint", { length: 64 }).notNull(),
  promptVersion: varchar("promptVersion", { length: 64 }).notNull(),
  model: varchar("model", { length: 64 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  expiresAt: timestamp("expiresAt").notNull(),
  lastAccessedAt: timestamp("lastAccessedAt").defaultNow().notNull(),
}, table => ({
  namespaceKeyUnique: uniqueIndex("insight_cache_entries_namespace_key_unique").on(table.cacheNamespace, table.cacheKeyHash),
  namespaceExpiresAtIdx: index("insight_cache_entries_namespace_expires_at_idx").on(table.cacheNamespace, table.expiresAt),
}));

export type InsightCacheEntry = typeof insightCacheEntries.$inferSelect;
export type InsertInsightCacheEntry = typeof insightCacheEntries.$inferInsert;

/** A country-level metric definition, kept independent from daily news pipeline scheduling. */
export const countryIndicators = mysqlTable("country_indicators", {
  id: int("id").autoincrement().primaryKey(),
  countryCode: varchar("countryCode", { length: 3 }).notNull(),
  countryName: varchar("countryName", { length: 80 }).notNull(),
  indicatorCode: varchar("indicatorCode", { length: 80 }).notNull(),
  label: varchar("label", { length: 160 }).notNull(),
  unit: varchar("unit", { length: 32 }).notNull(),
  periodicity: varchar("periodicity", { length: 24 }).notNull(),
  sourceName: varchar("sourceName", { length: 160 }).notNull(),
  sourceUrl: varchar("sourceUrl", { length: 2048 }).notNull(),
  definition: text("definition").notNull(),
  refreshPolicy: varchar("refreshPolicy", { length: 64 }).notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => ({
  countryIndicatorUnique: uniqueIndex("country_indicators_country_code_indicator_code_unique").on(table.countryCode, table.indicatorCode),
  activeCountryIdx: index("country_indicators_active_country_idx").on(table.isActive, table.countryCode),
}));

export type CountryIndicator = typeof countryIndicators.$inferSelect;
export type InsertCountryIndicator = typeof countryIndicators.$inferInsert;

/** A scheduled or manually initiated refresh of the independent country-indicator pipeline. */
export const countryIndicatorRefreshRuns = mysqlTable("country_indicator_refresh_runs", {
  id: varchar("id", { length: 36 }).primaryKey(),
  triggerKind: varchar("triggerKind", { length: 24 }).notNull(),
  heartbeatTaskUid: varchar("heartbeatTaskUid", { length: 65 }),
  runStatus: mysqlEnum("runStatus", ["running", "success", "partial", "failed"]).notNull(),
  startedAt: timestamp("startedAt").defaultNow().notNull(),
  completedAt: timestamp("completedAt"),
  indicatorTotal: int("indicatorTotal").default(0).notNull(),
  indicatorSucceeded: int("indicatorSucceeded").default(0).notNull(),
  indicatorFailed: int("indicatorFailed").default(0).notNull(),
  observationPersisted: int("observationPersisted").default(0).notNull(),
  errorSummary: varchar("errorSummary", { length: 1000 }),
}, table => ({
  statusStartedAtIdx: index("country_indicator_refresh_runs_status_started_at_idx").on(table.runStatus, table.startedAt),
  heartbeatTaskUidIdx: index("country_indicator_refresh_runs_task_uid_idx").on(table.heartbeatTaskUid),
}));

export type CountryIndicatorRefreshRun = typeof countryIndicatorRefreshRuns.$inferSelect;
export type InsertCountryIndicatorRefreshRun = typeof countryIndicatorRefreshRuns.$inferInsert;

/** Per-indicator outcome for one refresh run; source values continue to live in observations. */
export const countryIndicatorRefreshRunItems = mysqlTable("country_indicator_refresh_run_items", {
  id: int("id").autoincrement().primaryKey(),
  refreshRunId: varchar("refreshRunId", { length: 36 }).notNull().references(() => countryIndicatorRefreshRuns.id, { onDelete: "cascade" }),
  countryIndicatorId: int("countryIndicatorId").notNull().references(() => countryIndicators.id),
  itemStatus: mysqlEnum("itemStatus", ["success", "failed", "skipped"]).notNull(),
  sourceUrlSnapshot: varchar("sourceUrlSnapshot", { length: 2048 }).notNull(),
  referenceDate: timestamp("referenceDate"),
  observationPersisted: boolean("observationPersisted").default(false).notNull(),
  errorSummary: varchar("errorSummary", { length: 1000 }),
  completedAt: timestamp("completedAt").notNull(),
}, table => ({
  runIndicatorUnique: uniqueIndex("country_indicator_refresh_run_items_run_indicator_unique").on(table.refreshRunId, table.countryIndicatorId),
  refreshRunIdIdx: index("country_indicator_refresh_run_items_run_id_idx").on(table.refreshRunId),
  indicatorStatusCompletedAtIdx: index("ind_refresh_item_status_at_idx").on(table.countryIndicatorId, table.itemStatus, table.completedAt),
}));

export type CountryIndicatorRefreshRunItem = typeof countryIndicatorRefreshRunItems.$inferSelect;
export type InsertCountryIndicatorRefreshRunItem = typeof countryIndicatorRefreshRunItems.$inferInsert;

export const countryIndicatorObservationStatus = mysqlEnum("country_indicator_observation_status", ["provisional", "final", "revised"]);

/** A published measurement with its own reference period and source fingerprint for later audit or revision. */
export const countryIndicatorObservations = mysqlTable("country_indicator_observations", {
  id: int("id").autoincrement().primaryKey(),
  countryIndicatorId: int("countryIndicatorId").notNull().references(() => countryIndicators.id, { onDelete: "cascade" }),
  value: decimal("value", { precision: 20, scale: 4 }).notNull(),
  periodStart: timestamp("periodStart").notNull(),
  periodEnd: timestamp("periodEnd").notNull(),
  referenceDate: timestamp("referenceDate").notNull(),
  publishedAt: timestamp("publishedAt"),
  fetchedAt: timestamp("fetchedAt").defaultNow().notNull(),
  status: countryIndicatorObservationStatus.default("final").notNull(),
  sourceUrl: varchar("sourceUrl", { length: 2048 }).notNull(),
  sourceFingerprint: char("sourceFingerprint", { length: 64 }).notNull(),
  metadataJson: json("metadataJson").notNull(),
  note: varchar("note", { length: 1000 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => ({
  indicatorReferenceDateIdx: index("country_indicator_observations_indicator_reference_date_idx").on(table.countryIndicatorId, table.referenceDate),
  indicatorFingerprintUnique: uniqueIndex("country_indicator_observations_indicator_fingerprint_unique").on(table.countryIndicatorId, table.sourceFingerprint),
  fetchedAtIdx: index("country_indicator_observations_fetched_at_idx").on(table.fetchedAt),
}));

export type CountryIndicatorObservation = typeof countryIndicatorObservations.$inferSelect;
export type InsertCountryIndicatorObservation = typeof countryIndicatorObservations.$inferInsert;
