# Yahoo 替代來源盤點

## 國旅人次與支出

可用經濟日報原文：https://money.udn.com/money/story/5648/9668167

可用公視新聞補充：https://news.pts.org.tw/article/820745

## 台灣觀光需要新體驗

可用聯合新聞網原文：https://udn.com/news/story/7266/9659371

## 台中、星宇航空與日本 KOL

可用台中市政府官方原文：https://www.taichung.gov.tw/3342202/post

可用 PChome 新聞轉載：https://news.pchome.com.tw/travel/morenews/20260809/index-78624178933343350015.html

## 其他候選來源

經濟日報曾報導星宇航空中台灣航網：https://money.udn.com/money/story/5612/9236607

目前需要另外為「國籍航空燃油附加費調整」尋找聯合新聞網、NOWnews 或經濟日報的直接原文，再替換 Yahoo 連結。
