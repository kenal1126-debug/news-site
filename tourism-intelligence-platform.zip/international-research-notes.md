# 五國國際旅客意向研究查核

## 日本
來源：日本交通公社（JTBF）DBJ・JTBF 亞洲、歐美豪訪日外國旅客意向調查 2025 年度版外延報告。
網址：https://www.jtb.or.jp/news/news-research/release-asiaeuro-survey-2025-spinout/
頁面重點：研究聚焦地方誘客；亞洲受訪者中，香港、台灣訪日經驗者較多，且地方部落格／地方目的地具有潛在客源價值；隨訪日次數增加，對自然風景、傳統日本料理、祭典等地域資源的體驗需求會深化；地方誘客需要以「為什麼」與「如何」的背景說明促進深度理解，提升體驗附加價值。

## 韓國
來源：韓國觀光公社 Data Lab《2025年潛在訪韓旅客調查》。
網址：https://datalab.visitkorea.or.kr/site/portal/ex/bbs/View.do?bcIdx=310609&cbIdx=1603
頁面重點：調查涵蓋一般外國人與訪韓意向者，提供 26 個居住國及主要訪問意向地區的分析；2025 年起採用更細緻的居住地區抽樣，並對訪韓意向者套用近期入境統計權重；新增醫療觀光等主題形象、非意向／未決定者障礙、偏好季節／時期與交通方式等題項。

## 加拿大
來源：Destination Canada Global Tourism Watch。
網址：https://www.destinationcanada.com/en-ca/global-tourism-watch
頁面重點：以消費者情報追蹤全球 10 個市場及加拿大本地；核心指標包括目的地認知、旅遊意向、品牌相對競爭力、旅客尋求的體驗、成長機會、旅遊動機與障礙，以及 advocacy／口碑角色。

## 澳洲
來源：Tourism Australia Insights（Consumer Demand Project 入口）。
網址：https://www.tourism.australia.com/en/insights.html
頁面重點：官方 Insights 入口集中呈現旅客與市場洞察，作為 Consumer Demand Project 等消費者研究的入口；網站頁面本身未直接列出單一年度 CDP 數據，因此前端以研究用途與策略框架呈現，避免捏造未查核的數值。

## 紐西蘭
來源：Tourism New Zealand Consumer Research（Active Considerer Monitor）。
網址：https://www.tourismnewzealand.com/insights/consumer-research/
頁面重點：Active considerers 定義為認真考慮下一趟假期前往紐西蘭的人；研究追蹤目標市場的受眾規模與前往紐西蘭的情緒／意向，並提供澳洲、美加、中日、印度／韓國／新加坡、英德等市場的深度報告；另有淡季動機與障礙、永續在目的地與業者選擇中的角色等專題研究。

## 前端整合原則

以五個國家各一張趨勢卡呈現「研究觀察」「對台灣啟示」「策略焦點」與官方來源按鈕。只使用已由官方頁面查核的研究定位與 qualitative market signals；不在未讀取報告全文時補寫精確比例或排名數字。
