# 世界 10 大觀光新聞分類稽核

## 改造結果

原本首頁獨立的大型「世界 10 大觀光新聞」專區已移除，改為與「旅遊平台」並列的獨立產業分類「世界10大觀光新聞」。使用者可透過左側產業 INDEX 選取分類，新聞列表沿用既有搜尋、來源篩選、日期排序、圖片 fallback、原文連結與同分類去重流程。

## 海外來源規則

分類只對指定海外英文／國際媒體來源啟用，包括 Reuters、Associated Press、AP News、BBC、The Guardian、Travel Weekly、Skift、PhocusWire、eTurboNews、Cirium、WTTC、UN Tourism、Bloomberg、CNBC、CNN Travel、Euronews、Nikkei Asia、Forbes Travel 與 National Geographic Travel。標題或摘要另須具備 tourism、travel、hotel、hospitality、airline、airport、flight、destination、visitor 等旅遊語意，或相對應中文觀光產業語意。

中文媒體來源不會因為標題包含國際、全球或旅遊字樣而進入此分類；這些內容仍依既有航空運能、旅宿市場、目的地行銷、台灣觀光或旅遊成本規則分類。Fallback 與 live 資料均會傳入來源名稱重新判定，確保資料流一致。

## 驗證結果

2026-08-17 桌面版首頁側欄顯示「世界10大觀光新聞」分類及動態筆數 02，未再顯示大型專區；375×812 手機版首頁與分類導覽未發生溢出或錯位。新增海外來源正向與中文來源排除回歸案例後，完整 Vitest 48 項、TypeScript 與正式建置均通過。
