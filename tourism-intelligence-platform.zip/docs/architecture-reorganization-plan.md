# 觀光趨勢：全面分階段架構重整方案

**決策：D — 全面分階段重整。** 本方案以不中斷台灣時間每日 10:00、16:00、22:00 的新聞同步為前提，先降低首頁與同步服務的耦合，再建立可追溯資料模型與營運能力。

## 1. 重整前基線

| 面向 | 現況基線 | 重整保護條件 |
|---|---:|---|
| 測試品質 | 15 個測試檔、95 項測試通過 | 每個階段維持全數通過 |
| 編譯品質 | TypeScript、正式建置通過 | 不接受型別錯誤或建置失敗 |
| 近 14 天資料 | 865 筆原始新聞、66 個來源 | 不更改新聞保留與排序語意 |
| 首頁可見資料 | 基線截圖為 655 則近期訊號 | 保持篩選、警示、來源與 direct URL 行為 |
| 同步排程 | 每日 10:00、16:00、22:00（台灣時間） | 既有 Heartbeat 與 cron-only 端點持續相容 |

重整前已完成桌面與 375×812 手機版首頁驗證，核心警示、側欄分類、Hero 與新聞資料均可正常呈現。資料筆數會隨每日同步而變動，因此以**篩選規則、更新時段與 direct URL 可用性**作為主要驗收基準，而非固定筆數。

第一階段已先將首頁的資料查詢、篩選狀態、衍生資料與收藏狀態抽離至 `useTourismNewsDashboard`。完成後再次檢查桌面與 375×812 手機版：655 則近期訊號、紅色高優先服務警示、Hero、側欄動態計數與資料庫關鍵詞區塊均維持原有呈現與行為。

接續將側欄、頂端／Hero、關鍵詞雲與總經區塊拆為 feature components。視覺稽核曾發現警示被錯置於 Hero 後方，已改為以 `alertSlot` 保持在工具列下方、Hero 前方；桌面與 375×812 手機版復驗均通過。

第一階段目前已將新聞室、10 大觀光產業訊號與國際趨勢區塊一併遷入 `features/dashboard/components`。`Home.tsx` 現在僅負責掛接 dashboard hook、協調區域／分類／來源互動及組裝 feature sections；既有 CSS class hooks 均保留。新增 dashboard helpers 回歸測試，確保媒體來源正規化、分類顯示名稱、近期日期範圍及 TVBS／ETtoday 選項保持不變。

衍生資料已進一步移至 `selectors/dashboardSelectors.ts`，涵蓋近期故事合併、關鍵詞雲、facet 計數、10 大訊號、服務警示、來源計數與綜合篩選。selector 測試驗證了 TVBS 服務異常警示、ETtoday 群組篩選、零結果空狀態與近期 fallback 合併。正式品質檢查結果為 **17 個測試檔、100 項測試通過**，TypeScript 與正式建置均通過；桌面與 375×812 手機版仍維持警示位於 Hero 前方與既有動態計數。

第一階段最後補上 `Newsroom` 與 `TourismSignalsPanel` 的伺服端渲染測試。前者覆蓋故事卡、來源篩選選項與零結果狀態；後者覆蓋有訊號時的 100 分制評分欄位，以及未達門檻時的空狀態。最終結果為 **19 個測試檔、104 項測試通過**，並再次通過型別檢查與正式建置。

來源篩選亦抽出 `selectNewsroomSource` action 並納入測試，驗證選取來源會同步呼叫來源更新與關閉篩選面板。第一階段最新驗證為 **19 個測試檔、105 項測試通過**，TypeScript 與正式建置均通過。

最後新增來源選取後的重新渲染測試：以 Newsroom action 選取 TVBS新聞網後，selector 會回傳對應故事，重新渲染的頁面不再保留來源篩選面板且保有匹配故事。第一階段的最終品質結果為 **19 個測試檔、106 項測試通過**，TypeScript 與正式建置均通過。

另外導入 jsdom 與 Testing Library，實際開啟 Newsroom 來源篩選面板、點選 ETtoday，並驗證面板關閉、ETtoday 故事立即取代 TVBS 故事；第二個互動案例則確認當來源無結果時顯示空狀態。第一階段最終品質結果為 **20 個測試檔、108 項測試通過**，型別檢查與正式建置均通過。

## 2. 現況責任邊界

```mermaid
flowchart LR
  User[使用者] --> Home[Home.tsx\n資料查詢、狀態、衍生資料、全部版面]
  Home --> TRPC[tRPC news router]
  TRPC --> DB[db.ts\n使用者 + 新聞查詢與寫入]
  Cron[Heartbeat 排程] --> Endpoint[/api/scheduled/sync-news]
  Endpoint --> Sync[news-sync.ts\n來源、解析、解碼、補圖、寫入]
  Sync --> Rules[shared/\n觀光關聯、分類、影響、訊號、文字雲]
  Sync --> DB
  DB --> News[(news_items)]
```

目前平台功能完整，但有三個主要維護風險。第一，`Home.tsx` 同時負責資料查詢、資料轉換、URL 狀態、分類／訊號／警示衍生計算與頁面渲染。第二，`news-sync.ts` 混合來源目錄、RSS／HTML 解析、Google URL 解碼、圖片補強、例外處理與寫入協調。第三，`db.ts` 同時處理使用者與新聞資料；長期新增同步批次、來源健康度或警示紀錄時會提高改動風險。

## 3. 目標架構

```mermaid
flowchart TB
  subgraph Client[前端：功能導向]
    Page[Home 頁面容器]
    Hook[useTourismNewsDashboard]
    Selector[dashboard selectors]
    Sections[Alert / Hero / Filters / Newsroom / Signals / Keywords / Macro]
    Page --> Hook --> Selector --> Sections
  end

  subgraph API[API：領域 router]
    NewsRouter[news router]
    InsightRouter[insights router]
    AuthRouter[auth router]
  end

  subgraph Services[服務層：資料管線]
    Catalog[source catalog]
    Fetcher[source fetchers]
    Parse[parsers]
    Enrich[URL / image enrichment]
    Policy[relevance / category / signal policy]
    Persist[persistence service]
    Catalog --> Fetcher --> Parse --> Enrich --> Policy --> Persist
  end

  subgraph Data[資料與營運]
    NewsRepo[news repository]
    SourceRepo[source repository]
    RunRepo[sync-run repository]
    AlertRepo[service-alert repository]
    Database[(MySQL / Drizzle)]
    NewsRepo --> Database
    SourceRepo --> Database
    RunRepo --> Database
    AlertRepo --> Database
  end

  Client --> API
  API --> NewsRepo
  API --> AlertRepo
  Cron[Heartbeat] --> Fetcher
  Persist --> NewsRepo
```

## 4. 分階段路徑

| 階段 | 改造範圍 | 驗收條件 | 發布節點 |
|---|---|---|---|
| **0. 基線** | 測試、建置、資料與跨裝置畫面稽核 | 同步、首頁、警示與來源篩選維持可用 | 完成 |
| **1. 首頁模組化** | 拆出 dashboard hook／selector；將警示、Hero、篩選、新聞室、訊號、文字雲與總經卡獨立成元件 | URL 篩選、排序、警示、響應式與新聞數語意不變 | checkpoint 1 |
| **2. 同步服務拆分** | 分出 source catalog、RSS parser、Yahoo parser、Google resolver、image enricher、sync orchestrator | 同一組 fixture 的解析／去重／補圖結果一致；排程端點不變 | checkpoint 2 |
| **3. API 與資料存取分層** | `news`、`insights` 等領域 router；news／user repository 分離 | tRPC public contract、英文關鍵字快取與首頁查詢相容 | checkpoint 3 |
| **4. 可追溯營運模型** | 規劃／確認來源、同步批次、來源健康度、服務警示與快取資料表；設計內部營運頁 | 僅在核准 migration 後寫入 schema；保留歷史稽核能力 | checkpoint 4 |

## 5. 第一個實作 checkpoint 的範圍

第一個 checkpoint 僅處理**前端模組化**，不調整資料庫 schema、不改變排程、不更動 RSS／HTML 擷取規則。重點是將頁面容器縮小為資料協調者，並把可測試的衍生資料與呈現區塊移至功能資料夾。

```text
client/src/features/dashboard/
  hooks/useTourismNewsDashboard.ts
  selectors/dashboardSelectors.ts
  components/TourismServiceAlertBanner.tsx
  components/EditorialSidebar.tsx
  components/EditorialHero.tsx
  components/NewsFilters.tsx
  components/Newsroom.tsx
  components/TourismSignalsPanel.tsx
  components/KeywordCloudSection.tsx
  components/MacroTrendSection.tsx
  types.ts
```

> **重整原則：先移動責任、不改變決策。** 在第一階段，不重寫觀光關聯、分類、訊號或資料同步規則；所有行為差異都應由測試與畫面稽核主動發現。

## 7. 第二階段完成紀錄：新聞資料管線與後端服務

第二階段已將新聞資料存取移至 `server/repositories/newsRepository.ts`，把使用者認證的 `db.ts` 與新聞讀寫責任分離。原有的 GUID 正規化、同標題收斂、圖片保留與 50 筆批次 upsert 契約均以既有測試維持。

同步服務已分出 `news/sourceCatalog.ts`、`news/concurrency.ts`、`news/rssParser.ts`、`news/yahooTaiwanParser.ts`、`news/articleEnrichment.ts` 與 `news/syncOrchestrator.ts`。實際同步流程已由新來源目錄、RSS／Yahoo HTML 解析器、Google URL 解碼／圖片補強與 orchestrator 接管；`news-sync.ts` 暫時保留相容匯出，確保手動稽核腳本與既有測試的呼叫介面不變。

API 方面，`newsRouter` 已自 `appRouter` 分離，保留 `news.recent` 與 `news.englishKeywordTerms` 的既有 public contract。排程入口仍呼叫相同的 `syncRecentNews` 協調函式；重整後已實際執行完整同步並完成資料庫稽核，最近 14 天有 **960 筆新聞、67 個來源**，其中 TVBS 36 筆、Yahoo Travel 54 筆、BBC Travel 8 筆，且保留 1 筆政府旅遊服務異常訊號。全量測試、TypeScript 與正式建置均通過。

相容層已進一步收斂為純轉接：`news-sync.ts` 不再包含來源清單、RSS／Yahoo HTML 解析、Google 解碼或圖片補強實作，只提供現有排程、測試與手動稽核腳本所需的相容匯出。新增整合契約測試驗證來源清單的單一實體、`/api/scheduled/sync-news` 端點與手動稽核腳本的 repository／facade 匯入關係。

在最終相容層收斂後已再次執行完整手動同步：本次抓取 **546 筆**，僅自由時報主 RSS 回傳 404；截至資料稽核時最近 14 天為 **963 筆**、英文新聞 68 筆、英文來源 9 個。這確認來源目錄、解析、補強、寫入、排程相容端點與稽核腳本均能由新服務層完成。

排程端點目前由 `createScheduledNewsSyncHandler` 組裝，正式整合測試實際呼叫 handler，驗證 cron 身分可啟動新 `feedSyncService`，非 cron 呼叫會回傳 403；手動稽核則透過 `runManualNewsSyncAudit` 先執行相容 facade 的同步，再由 news repository 讀取最近 14 天資料。第二階段目前為 **23 個測試檔、113 項測試通過**，TypeScript 與正式建置均通過。

最後把 `/api/scheduled/sync-news` 的路由註冊抽為 `registerScheduledNewsSyncRoute`，由實際掛載的 callback 測試成功呼叫新同步服務、非 cron 的 403，以及同步例外時包含 URL 與時間的 500 診斷 JSON。第二階段最終品質結果為 **24 個測試檔、116 項測試通過**，TypeScript 與正式建置均通過。

## 6. 風險控制

重整採用小步移動與每階段 checkpoint。所有資料庫變更會在第三階段設計完成並獲確認後，遵循 schema → migration SQL → 單次執行 → 查核的順序處理。同步服務拆分前會以現有解析／去重測試與手動同步稽核作為等價性基準；前端拆分前後會檢查桌面、375×812 手機版、來源篩選與服務警示。
