# Google 需求早期訊號資料存取查核

## Google Trends

Google 官方於 2025 年公告 Google Trends API Alpha，目前僅接受申請並以有限開發者測試為主，尚未對所有使用者開放。官方文件列出的能力包括滾動五年資料窗、日／週／月／年彙整、國家與次國家區域比較，以及一致尺度的搜尋興趣資料。

因此，在尚未取得 Alpha 存取資格前，本平台不應對 Google Trends 建立自動化擷取或非官方繞行串接。可採取的安全起步做法是人工查閱與定期匯出，僅作為相對需求變化的輔助觀察，不將其轉譯為旅客人次或預訂量。

來源：[Google Trends API Alpha 官方文件](https://developers.google.com/search/apis/trends)

## Google Ads 關鍵字規劃工具

Keyword Planning API 可產生關鍵字建議、歷史指標與預測指標；官方文件指出歷史指標按月更新，且此類服務在標準與基本存取下均有較嚴格的請求速率限制。Google Ads API 的每次呼叫同時需要 OAuth 2.0 憑證與 developer token，授權使用者或服務帳號還必須能存取目標 Google Ads 帳戶。

使用者目前沒有 Google Ads 正式授權，因此本平台不接入關鍵字規劃 API，也不以爬蟲繞行登入或權限。若未來取得授權，應採 server-side OAuth、以機密管理方式保存 token，按月快取歷史指標並記錄資料期別與權限帳戶。

來源：[Keyword Planning 官方概覽](https://developers.google.com/google-ads/api/docs/keyword-planning/overview)；[Google Ads API OAuth 官方說明](https://developers.google.com/google-ads/api/docs/oauth/overview)

## 平台採用決策

| 情境 | 可採資料 | 平台使用方式 | 不可作為 |
| --- | --- | --- | --- |
| 目前：無 Google Ads 授權、未獲 Trends Alpha | 最近 14 天可追溯新聞文字雲、官方入境／航班／旅宿統計、公開產業報告 | 以「需求走強」中的早期訊號呈現高頻需求詞、詞頻與支撐新聞數 | 實際搜尋量、旅客人次、訂單量或市場預測 |
| 未來：獲 Google Trends API Alpha | 一致尺度的 Trends 相對興趣、區域與日／週／月／年彙整 | 以 API 期別與區域記錄相對興趣變化，與文字雲互相驗證 | Google Ads 關鍵字量級或付費搜尋成效 |
| 未來：已取得 Google Ads API 權限 | 關鍵字建議、歷史搜尋指標與預測指標 | 以月度快取與來源稽核呈現關鍵字量級佐證 | 未經說明的個人行為資料或即時旅客訂單 |

目前已採第一種方案。即使未來取得任一 Google 權限，仍應將搜尋訊號視為需求的領先觀察，並以官方入境旅次、運能與旅宿統計交叉驗證。
