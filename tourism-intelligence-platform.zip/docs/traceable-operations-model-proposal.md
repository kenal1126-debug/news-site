# 可追溯營運資料模型提案

**狀態：待確認；本文件不包含任何資料庫 migration 或既有資料修改。**

## 1. 目標與不變條件

本階段將目前由程式目錄、同步回傳值與前端衍生規則承載的營運資訊，轉為可查詢的稽核紀錄。範圍是回答四個問題：某則新聞由哪一個同步入口取得、某次同步哪些來源成功或失敗、首頁旅遊服務警示根據哪則新聞與哪個規則產生，以及英文關鍵字分析是否命中快取與使用何種模型／提示版本。

既有新聞首頁、`news.recent` 公開契約、每日台灣時間 10:00／16:00／22:00 的 Heartbeat 排程與最近 14 天保留規則均維持不變。來源目錄在第一版仍由 `sourceCatalog.ts` 作為執行設定的單一真實來源；資料庫只保存每次執行時的來源快照，因此不會在未完成營運介面前意外開放線上修改抓取 URL 或篩選策略。

| 原則 | 設計決定 |
| --- | --- |
| 排程可靠性 | 同步批次在工作開始時建立；單一來源失敗只標記該來源失敗，其他來源持續執行；最終狀態為 `success`、`partial` 或 `failed`。 |
| 冪等與重試 | 每次觸發均有獨立 `sync_run_id`；新聞仍沿用現有 GUID、URL、標題收斂與圖片保留 upsert，不以重試批次重複建立新聞。 |
| 來源血緣 | 區分「擷取入口」與「新聞發布媒體」；Google News 擷取後回填的原始媒體不覆寫入口紀錄。 |
| 可讀性 | 儲存狀態、筆數、HTTP 狀態、耗時與安全截斷的錯誤摘要，不保存完整來源 HTML、Cookie、憑證或第三方回應內文。 |
| 時間一致性 | 所有時間以 UTC timestamp 儲存；營運介面再轉為台灣時間顯示。 |

## 2. 目標資料模型

### 2.1 `news_sources`：同步入口目錄快照

此表代表可被排程擷取的入口，而非最終刊登新聞的媒體品牌。它以穩定 `source_key` 對應 `sourceCatalog.ts` 中的項目，例如 `bbc-travel-google-rss`、`yahoo-tw-food` 或 `government-service-disruption-google-rss`。

| 欄位 | 型別／索引 | 用途 |
| --- | --- | --- |
| `id` | bigint PK | 內部關聯鍵。 |
| `source_key` | varchar(128), unique | 穩定程式識別值；來源名稱或 URL 可調整而不改變歷史關聯。 |
| `display_name` | varchar(160) | 排程時的人類可讀來源名稱。 |
| `adapter_kind` | varchar(48), indexed | `rss`、`yahoo_category_html` 或 `required_article`。 |
| `endpoint_url` | varchar(2048) | 同步入口 URL；不作索引。 |
| `category_hint` | varchar(120), nullable | Yahoo 台灣玩樂等入口的固定分類提示。 |
| `language` | varchar(16), nullable | `zh-Hant`、`en` 等入口預設語言。 |
| `is_required` / `is_active` | boolean, indexed | 必收文章與目前啟用狀態。 |
| `catalog_version` | varchar(64) | 本次程式目錄版本或設定雜湊。 |
| `created_at` / `updated_at` | timestamp | 目錄首次／最近同步時間。 |

### 2.2 `news_sync_runs`：一次同步的總帳

每次 cron、手動稽核或未來受保護的營運重跑都建立一筆 run。它提供排程成功率、總耗時、資料截點與總量，但不把來源層級錯誤塞進單一 JSON 欄位。

| 欄位 | 型別／索引 | 用途 |
| --- | --- | --- |
| `id` | varchar(36) PK | 程式產生的關聯 ID，供日誌、來源執行與警示回溯。 |
| `trigger_kind` | varchar(24), indexed | `heartbeat`、`manual_audit` 或後續的 `operations_replay`。 |
| `heartbeat_task_uid` | varchar(65), nullable, indexed | Heartbeat 回呼時的工作 UID；不可由 request body 作為授權依據。 |
| `status` | varchar(16), indexed | `running`、`success`、`partial`、`failed`。 |
| `started_at` / `completed_at` | timestamp, indexed | 供耗時與最近成功同步判讀。 |
| `cutoff_at` | timestamp | 本次最近 14 天的計算截點。 |
| `source_total` / `source_succeeded` / `source_failed` | int | 來源健康度總覽。 |
| `item_fetched` / `item_persisted` / `item_rejected` | int | 入口抓取、寫入與政策排除後的量化結果。 |
| `error_summary` | varchar(1000), nullable | 僅在整批無法完成時保存截斷診斷。 |

### 2.3 `news_sync_run_sources`：來源層級執行與健康紀錄

每個同步批次對每個入口留下一筆紀錄。這是判斷「自由時報主 RSS 404 是否連續發生」或「Yahoo 台灣五分類是否都按時處理」的主要資料來源。

| 欄位 | 型別／索引 | 用途 |
| --- | --- | --- |
| `id` | bigint PK | 內部關聯鍵。 |
| `sync_run_id` | varchar(36), indexed | 對應 `news_sync_runs`。 |
| `news_source_id` | bigint, indexed | 對應 `news_sources`。 |
| `endpoint_url_snapshot` | varchar(2048) | 執行當下入口 URL，保留設定變更前後歷史。 |
| `status` | varchar(16), indexed | `success`、`failed`、`skipped`。 |
| `http_status` | int, nullable | 有 HTTP 回應時保存狀態碼。 |
| `started_at` / `completed_at` | timestamp | 單一來源耗時與逾時分析。 |
| `item_fetched` / `item_accepted` | int | 解析出的新聞量與通過最近 14 天／政策處理後量。 |
| `error_summary` | varchar(1000), nullable | 錯誤名稱、HTTP 狀態或安全截斷訊息。 |

### 2.4 `news_sync_run_items`：新聞入口血緣（第二次 migration）

此表是完整的「一則新聞在哪一次、透過哪個入口被看見」審計層。由於來源同步會有同標題收斂、Google URL 解碼、圖片補強與政策排除，此表保存處理結果而不是儲存完整原始 HTML。

| 欄位 | 型別／索引 | 用途 |
| --- | --- | --- |
| `id` | bigint PK | 內部關聯鍵。 |
| `sync_run_source_id` | bigint, indexed | 指向本次執行的來源入口。 |
| `news_item_id` | int, nullable, indexed | 寫入或匹配成功時指向現有新聞；被排除時可為空。 |
| `disposition` | varchar(24), indexed | `inserted`、`updated`、`deduplicated`、`rejected`。 |
| `publisher_name` / `article_url` / `guid_hash` | varchar | 保留可追溯的原始媒體與識別值；GUID 使用既有正規化／SHA-256 邏輯。 |
| `rejection_reason` | varchar(120), nullable | 例如 `outside_window`、`non_tourism`、`election`、`duplicate`。 |
| `policy_version` / `enrichment_version` | varchar(64), nullable | 對應當時分類、排除與補圖的規則版本。 |
| `created_at` | timestamp, indexed | 入口觀測時間。 |

第一個 migration 不建立此表；先以 `news_sync_run_sources` 取得來源健康度。待同步寫入層改為能回傳 inserted／updated／deduplicated 統計、且測試確認無效能退化後，再以獨立 checkpoint 加入新聞級血緣。

### 2.5 `tourism_service_alerts`：衍生警示快照

首頁目前依新聞即時計算「嚴重・紅色」與「注意・黃色」。新表將保存判定快照與生命週期，讓營運端可以回答警示何時出現、最後一次被偵測到，以及它對應哪一則原始新聞。

| 欄位 | 型別／索引 | 用途 |
| --- | --- | --- |
| `id` | bigint PK | 內部關聯鍵。 |
| `news_item_id` | int, indexed | 對應觸發警示的既有新聞。 |
| `sync_run_id` | varchar(36), indexed | 首次偵測此警示的同步批次。 |
| `severity` | varchar(16), indexed | `critical` 或 `warning`；沿用既有紅／黃規則。 |
| `affected_service` | varchar(255) | 如「國旅補助申請官網」。 |
| `status` | varchar(16), indexed | `active`、`resolved`、`expired`。 |
| `detected_at` / `last_detected_at` / `resolved_at` | timestamp | 支援警示時序與解除判讀。 |
| `rule_version` | varchar(64) | 保存當時服務異常 regex／解析邏輯版本。 |

第一版首頁仍可用既有純函式計算，並以此表作營運歷史與交叉驗證；待平行比對無差異後才切換首頁讀取 active 警示，避免以新資料遺漏造成橫幅消失。

### 2.6 `insight_cache_entries`：分析快取稽核

目前英文關鍵字是記憶體內 6 小時快取，工作程序重啟後即遺失。資料表只保存可重用分析結果與推導中繼資料，不保存完整 prompt 或新聞摘要。

| 欄位 | 型別／索引 | 用途 |
| --- | --- | --- |
| `id` | bigint PK | 內部關聯鍵。 |
| `cache_namespace` | varchar(80), indexed | 第一個命名空間為 `english-keyword-terms`。 |
| `cache_key_hash` | char(64), unique | 對候選詞頻、新聞內容指紋、提示版本的 SHA-256。 |
| `payload_json` | JSON | 選定字詞、`usedNlp`、模型名稱與分析時間。 |
| `input_fingerprint` | char(64), indexed | 追溯本次新聞集合是否改變。 |
| `prompt_version` / `model` | varchar | 追溯模型與規則。 |
| `created_at` / `expires_at` / `last_accessed_at` | timestamp, indexed | 維持既有 6 小時 TTL 與快取健康分析。 |

## 3. 執行流程與相容策略

```mermaid
sequenceDiagram
  participant H as Heartbeat
  participant R as scheduledSyncHandler
  participant S as feedSyncService
  participant O as syncOrchestrator
  participant D as MySQL

  H->>R: POST /api/scheduled/sync-news
  R->>R: 驗證 isCron 與 taskUid
  R->>S: syncRecentNews(now)
  S->>D: 建立 news_sync_runs (running)
  O->>D: 每一來源寫入 news_sync_run_sources
  O->>D: 沿用既有 news_items 去重與圖片保留 upsert
  O->>D: 更新來源結果與 run 總計
  S-->>R: 維持 fetched / failedFeeds / cutoff 回傳契約
  R-->>H: 200 或具診斷 JSON 的 500
```

導入順序採「影子寫入」：第一輪先建立來源與 run 紀錄、仍使用原有 `news_items` 寫入；第二輪確認 10:00／16:00／22:00 各至少一次成功排程且 run 統計與既有回傳相符；第三輪才加入警示與快取的讀取切換。所有 migration 均採新增表／新增索引，**不刪除、不重新命名現有 `news_items` 欄位，也不回填或覆寫歷史新聞。**

## 4. 內部營運頁範圍

第一版新增僅供管理者使用的 `/operations`，以現有管理後台版型提供唯讀稽核，不對外使用者公開。它不直接編輯來源、也不允許未授權的手動同步，避免把來源設定與排程控制暴露在首頁。

| 區塊 | 顯示內容 | 第一版操作 |
| --- | --- | --- |
| 同步總覽 | 最近成功時間、最近 run 狀態、耗時、抓取／寫入／失敗來源筆數 | 只讀。 |
| 來源健康度 | 每個入口最後成功時間、最近 HTTP 狀態、連續失敗與錯誤摘要 | 篩選／展開明細。 |
| 服務警示 | active／已解除警示、紅黃程度、受影響服務、新聞原文與規則版本 | 篩選／開啟原文。 |
| 分析快取 | 命名空間、TTL、是否使用 NLP、模型與最近分析時間 | 只讀；不顯示新聞全文或 prompt。 |

後續第二版才評估受保護的「重新執行單一來源」與「停用／啟用來源」；該版本必須另行確認權限、重試上限、寫入稽核與對每日排程的互斥規則。

## 5. 需確認的決策

建議先核准以下第一個 migration 範圍：`news_sources`、`news_sync_runs`、`news_sync_run_sources`、`tourism_service_alerts` 與 `insight_cache_entries`。`news_sync_run_items` 會在同步寫入層能精確回傳處理結果後，以第二個 checkpoint 導入。

| 決策 | 建議 | 確認後行動 |
| --- | --- | --- |
| 執行設定來源 | 第一版維持程式目錄為唯一可編輯設定，DB 保存快照 | 建立來源同步／upsert 與批次紀錄。 |
| 資料保留 | 保留 run 與來源健康度至少 365 天；警示保留 730 天；快取依 TTL 清理 | 建立資料保留常數與非破壞性清理策略。 |
| 營運介面 | 先做管理者唯讀 `/operations`，再討論操作型控制 | 建立 admin router、repository、介面與測試。 |
| 新聞級血緣 | 第二個 migration 才建立 `news_sync_run_items` | 先驗證來源級稽核不影響同步，再擴充每筆新聞血緣。 |

> 核准前不會產生 migration SQL、不會呼叫資料庫變更，也不會調整現有三個每日同步時段。

## 6. 國際入境旅客與人口指標擴充

既有六國總體經濟卡片可以擴充兩項來源可追溯的國際指標：**最新可用入境旅客旅次**與**最新可用總人口**。首頁不可把兩者誤稱為同一期間或同一個體；前者通常是月度邊境移動／旅次，後者是年中或期末常住人口估計。

| 首頁欄位 | 定義 | 顯示規則 |
| --- | --- | --- |
| 最新入境旅客 | 各國官方發布的短期境外訪客、海外居民到達或外國旅客入境之最近可用期 | 顯示數值、月份／季度、旅次／到達／訪客的原始定義與官方來源。 |
| 近 12 月入境累計 | 以官方月度序列加總的滾動 12 個月流量；無月度序列時顯示官方年度統計 | 作為跨月比較與旅遊活動量的主指標。 |
| 總人口 | 官方常住人口估計或登記人口的最近可用統計基準日 | 顯示人口數、基準日及「估計」或「登記」性質。 |
| 旅遊強度 | `近 12 月入境旅次 ÷ 總人口` | 僅作目的地承載與外來旅遊相對規模的比較，不宣稱為每位居民接待的獨立旅客數。 |

為使數據具稽核性，建議在可追溯模型第一輪的後續 migration 增加 `country_indicators` 與 `country_indicator_observations`：前者定義國家、指標代碼、原始統計定義與官方來源；後者保存數值、統計期間起訖、發布日、抓取時間、單位、初步／正式狀態、來源 URL 與內容指紋。這兩張表應與新聞同步批次分離，因為經濟與人口資料的發布時點不等於每日新聞同步時點。

第一版可先由與資料發布頻率相符的背景更新讀取官方入口：日本 JNTO、韓國官方觀光統計、加拿大 Statistics Canada、澳洲 ABS、紐西蘭 Stats NZ 及泰國觀光與體育部；人口則優先各國官方統計機關。若個別來源只有公告頁或 PDF，系統會保留原始 URL、發布期別與最後成功更新時間，並在卡片標註「最近可用」，不以推估值補空白。

| 國家 | 入境旅客官方來源 | 旅客資料頻率與主要定義 | 人口官方來源 | 人口基準與實作注意事項 |
| --- | --- | --- | --- | --- |
| 日本 | [JNTO](https://statistics.jnto.go.jp/en/graph/) | 月度 Visitor Arrivals；保留 JNTO 的 provisional／確報狀態。 | [Statistics Bureau](https://www.stat.go.jp/english/data/jinsui/2024np/index.html) | 年度人口推計；保存 10 月 1 日等基準日。 |
| 韓國 | [MCST／官方觀光統計](https://www.mcst.go.kr/english/statistics/statistics.jsp) | 月度境外旅客統計；在串接前固定 KOSIS 或資料實驗室的可下載表。 | [KOSIS](https://kosis.kr/eng/) | 使用實際人口統計表，不使用輪播中的人口預測。 |
| 加拿大 | [Statistics Canada](https://www150.statcan.gc.ca/n1/daily-quotidien/260820/dq260820b-eng.htm) | 月度；區分海外非居民、美国居民與加拿大居民返國。 | [表 17-10-0009-01](https://www150.statcan.gc.ca/t1/tbl1/en/tv.action?pid=1710000901) | 季度人口估計，保存表號、統計季與發布日。 |
| 澳洲 | [ABS Overseas Arrivals and Departures](https://www.abs.gov.au/statistics/industry/tourism-and-transport/overseas-arrivals-and-departures-australia/latest-release) | 月度短期訪客到達；必須標示為邊境旅次，非獨立人數。 | [ABS Population](https://www.abs.gov.au/statistics/people/population/national-state-and-territory-population/latest-release) | 季度 Estimated Resident Population。 |
| 紐西蘭 | [Stats NZ International Travel](https://www.stats.govt.nz/information-releases/international-travel-january-2026/) | 每週 provisional 與月度正式／詳細資料；保存版本狀態。 | [Stats NZ Population](https://www.stats.govt.nz/topics/population/) | Estimated Resident Population，保存 census-base 與基準日。 |
| 泰國 | [Ministry of Tourism and Sports](https://www.mots.go.th/news/category/411) | 月度外國旅客入境；公告格式需容錯解析與來源快照。 | [National Statistical Office](https://www.nso.go.th/nsoweb/nso/statistics_and_indicators?set_lang) | 先鎖定官方可下載人口表，並標示常住／登記口徑。 |
