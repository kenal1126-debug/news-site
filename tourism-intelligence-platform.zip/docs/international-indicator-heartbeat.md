# 國際指標背景更新工作

| 欄位 | 值 |
| --- | --- |
| 工作名稱 | `daily-international-indicators-refresh` |
| 工作識別 | `5jPWTKSTdrDeeeLMHtEX3Y` |
| 回呼端點 | `POST /api/scheduled/refresh-international-indicators` |
| Cron（UTC） | `0 30 0 * * *` |
| 執行時間 | 每日台灣時間 08:30 |
| 狀態 | 已啟用 |

此工作與新聞同步 `daily-tourism-news-sync` 分離。每次執行均會由已驗證的 cron 身分呼叫獨立 handler，並在 `country_indicator_refresh_runs` 及其逐指標結果表保存工作識別、成功／失敗／跳過狀態與診斷資訊。平台會對 `5xx`／`429` 執行重試；更新服務以來源指紋 upsert，因此重複觸發不會累積重複觀測值。
