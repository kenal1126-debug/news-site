# 國際入境旅客與人口資料來源研究紀錄

**研究狀態：進行中。** 本文件只記錄已驗證的公開官方資料入口與資料定義；實際首頁數值必須在實作前依各來源最新發布期別重新讀取。

| 國家／地區 | 入境旅客官方入口 | 已確認的資料定義與頻率 | 人口官方入口 | 自動更新適配性 |
| --- | --- | --- | --- | --- |
| 日本 | [JNTO Japan Tourism Statistics](https://statistics.jnto.go.jp/en/graph/) | 官方頁面提供最新 `Visitor Arrivals to Japan`、按國家／地區拆分及下載檔案；適合月度擷取。 | 待查核 Statistics Bureau of Japan 人口估計入口。 | 高：資料入口穩定、可保留下載／發布期別。 |
| 紐西蘭 | [Stats NZ International travel](https://www.stats.govt.nz/information-releases/international-travel-january-2026/) | 官方定義為短期海外訪客與紐西蘭居民進出境；頁面提供可下載資料，並說明每週發布 provisional international travel statistics。 | 待查核 Stats NZ 人口估計資料入口。 | 高：可分別保存 provisional／正式版本及其發布日期。 |
| 韓國 | [韓國文化體育觀光部 Statistics](https://www.mcst.go.kr/english/statistics/statistics.jsp) | 官方統計頁包含 Tourism 類別，並連結文化統計入口；月度境外旅客數建議以韓國觀光資料實驗室的官方資料介面作為第一順位。 | 待查核韓國國家資料與統計部／KOSIS 人口估計入口。 | 中高：須先固定可機器讀取的 Tourism 子頁或下載表格。 |
| 泰國 | [泰國觀光與體育部 Tourist arrival statistics](https://www.mots.go.th/news/category/411) | 官方首頁連結「外國旅客進入泰國人數」並提供歷年／月份統計頁面；需依每期公告解析實際數字與截至月份。 | 待查核泰國國家統計局或內政部登記人口公開統計。 | 中：官方入口已確認，但公告格式需要加入容錯解析與來源快照。 |
| 澳洲 | [澳洲統計局 Overseas Arrivals and Departures](https://www.abs.gov.au/statistics/industry/tourism-and-transport/overseas-arrivals-and-departures-australia/latest-release) | 官方每月發布短期訪客入境與可下載 XLSX；2026 年 6 月短期訪客入境為 566,910 旅次。該局明確說明資料是國際邊境移動，**不得解讀為人數**。 | 待查核 ABS National, state and territory population estimates。 | 高：月度資料與下載表格明確，需在介面以「旅次」而非「人次／獨立旅客」標示。 |
| 加拿大 | [Statistics Canada Travel between Canada and other countries](https://www150.statcan.gc.ca/n1/daily-quotidien/260820/dq260820b-eng.htm) | 官方月度發布區分加拿大居民返國、美国居民入境與海外居民抵達；2026 年 6 月海外居民抵達 811,000。應只採海外非居民到達，不與加拿大居民返國混合。 | 待查核 Statistics Canada 人口估計資料表。 | 高：已有月度表與可重複引用的表號；需在來源中保存是否包含美國邊境日歸旅次。 |

## 初步資料治理結論

入境旅客是「流量」：應同時呈現**最新單月（或最近可用期）**與**過去 12 個月／年度累計**，不可直接把月度流量與人口存量比較。人口是「存量」：應顯示統計基準日、估計或普查性質與年中／年末定義。

首頁若顯示「入境旅客／人口」，建議使用最近 12 個月入境人次除以最新可用總人口，標註為**旅遊強度指標**，而非「每位居民實際接待的獨立旅客數」。跨國卡片仍需保留各國官方定義，例如短期訪客、外國訪客或所有國際到達旅客的差異。

## 已確認的人口來源補充

加拿大可採 [Statistics Canada 表 17-10-0009-01](https://www150.statcan.gc.ca/t1/tbl1/en/tv.action?pid=1710000901)，其為按季人口估計，2026-06-17 發布。紐西蘭可採 [Stats NZ Population](https://www.stats.govt.nz/topics/population/) 的常住人口估計，該機關明示最新估計以 2023 Census 為基礎，並在圖表中提供截至 2026-06-30 的估計居民人口。兩者都應將統計基準日和發布日分開保存。

日本可採 [Statistics Bureau of Japan 人口推計](https://www.stat.go.jp/english/data/jinsui/2024np/index.html)，最近已核對英文發布為截至 2024-10-01 的 123,802 千人，並提供 e-Stat 官方統計表。澳洲可採 [ABS National, state and territory population](https://www.abs.gov.au/statistics/people/population/national-state-and-territory-population/latest-release)，最近已核對為截至 2025-12-31 的 27,801,023 人，按季發布並提供 XLSX 下載。兩國均應以來源上的參考期而非網頁讀取日標示人口數。

韓國可採 [KOSIS](https://kosis.kr/eng/) 的官方 Population 資料庫與韓國國家資料與統計部發布頁；該站已呈現 2026 年人口預測值及月度人口主題更新，實作時應固定使用可下載的實際人口統計表，而非預測輪播數字。泰國可採 [National Statistical Office 重要統計與指標](https://www.nso.go.th/nsoweb/nso/statistics_and_indicators?set_lang) 作為官方統計入口，並優先定位可下載的常住／登記人口資料表；如需年末登記人口，應同時保存內政登記單位的發布機關、基準日與覆蓋範圍，避免與國際人口估計混用。

## 首批已寫入之可追溯官方觀測值

| 國家／指標 | 數值 | 統計期別／基準日 | 資料定義與來源 |
| --- | ---: | --- | --- |
| 日本／入境旅次 | 3,148,600 | 2026 年 6 月 | JNTO `Visitor Arrivals to Japan`；為入境旅次。<https://statistics.jnto.go.jp/en/graph/> |
| 日本／人口 | 123,802,000 | 2024-10-01 | Statistics Bureau of Japan 人口推計。<https://www.stat.go.jp/english/data/jinsui/2024np/index.html> |
| 韓國／入境旅次 | 10,709,919 | 2026 年 1–6 月累計 | 韓國文化體育觀光部官方發布的上半年國際訪客總數；為累計旅次。<https://www.mcst.go.kr/english/policy/pressView.jsp?pSeq=658> |
| 加拿大／海外非居民到達 | 811,000 | 2026 年 6 月 | Statistics Canada 海外非居民到達，不含加拿大居民返國旅次。<https://www150.statcan.gc.ca/n1/daily-quotidien/260820/dq260820b-eng.htm> |
| 加拿大／人口 | 41,417,056 | 2026-04-01 | Statistics Canada 人口初步估計。<https://www150.statcan.gc.ca/n1/daily-quotidien/260617/dq260617a-eng.htm> |
| 澳洲／短期訪客入境 | 566,910 | 2026 年 6 月 | ABS 短期訪客入境，明確標示為旅次／邊境移動。<https://www.abs.gov.au/statistics/industry/tourism-and-transport/overseas-arrivals-and-departures-australia/latest-release> |
| 澳洲／人口 | 27,801,023 | 2025-12-31 | ABS 國家人口估計。<https://www.abs.gov.au/statistics/people/population/national-state-and-territory-population/latest-release> |
| 紐西蘭／海外訪客入境 | 203,300 | 2026 年 5 月 | Stats NZ overseas visitor arrivals；頁面定義為短期國際移動。<https://www.stats.govt.nz/information-releases/international-travel-may-2026/> |
| 紐西蘭／人口 | 5,357,300 | 2026-06-30 | Stats NZ estimated resident population；暫定估計可按季修訂。<https://www.stats.govt.nz/indicators/population-of-nz/> |

自動更新服務的第一批可機器驗證解析器已啟用於澳洲 ABS 與紐西蘭 Stats NZ 的月度入境公告；其餘官方來源已先建立定義與來源稽核，待各入口的結構化表格／穩定下載規格完成專屬解析器後再啟用，以避免由不穩定頁面臆測數字。

### 泰國官方入口查核（2026-08-21）

泰國觀光與體育部英文首頁直接連至 [Tourist arrival statistics](https://www.mots.go.th/news/category/411)，且標示統計主題為「Number of foreign tourists entering Thailand」。目前首頁嵌入區塊僅顯示「January–December 2025」與空白／視覺化占位內容，未提供可追溯的 2026 月度或半年數值；因此此輪不寫入泰國入境觀測，並維持首頁「待官方資料」與背景更新的 skipped 稽核狀態。

後續透過泰國 [中央銀行觀光指標表](https://app.bot.or.th/BTWS_STAT/statistics/ReportPage.aspx?reportID=875&language=eng) 取得最新可讀官方表格。該表註明資料來源為觀光與體育部，2026 年 6 月外國旅客訪泰為 **1,841.55 千人**，資料更新日為 2026-07-31，且標示為 provisional；已換算為 1,841,550 旅次入庫。

泰國 [國家統計局 2025 Population and Housing Census 初步結果](https://www.nso.go.th/nsoweb/main/summano/aE?set_lang=en) 則公布居住於泰國的總人口為 **7,030 萬人**。此值已以「2025 普查初步／居住人口」口徑入庫，並與可能較低的戶籍登記人口分開解讀。

### 韓國 KOSIS 人口表查核（2026-08-21）

KOSIS 已成功載入 [Population, Households and Housing Units](https://kosis.kr/statHtml/statHtml.do?sso=ok&returnurl=https%3A%2F%2Fkosis.kr%3A443%2FstatHtml%2FstatHtml.do%3FtblId%3DDT_1IN1502%26language%3Den%26orgId%3D101%26) 的 2025 表格，包含 `Whole country` 列與總人口欄。此表為實際人口統計入口，與 KOSIS 首頁的 `Population Projections` 預測數字分開；下一步僅擷取全國列的實際數值與資料更新日後才入庫。

已擷取 `Whole country` 的 **51,817,499 人**，資料期為 2025 年、表格更新日為 2026-08-04；此數字含韓國人與外國居民，已連同統計口徑寫入國別指標觀測值。

### 紐西蘭與泰國人口頁的自動更新條件（2026-08-21）

Stats NZ 的 [Population 主題頁](https://www.stats.govt.nz/topics/population/) 直接以可讀文字公布 `Estimated resident population, as at 31 December 5,344,500`，並註記其為 2026-05-18 發布、會在約 6 個季度內持續修訂的暫定估計；該頁同時連結最新 2026-06 的人口發布，可作為固定 URL 的每日檢查來源。泰國 [國家統計局 2025 人口及住宅普查](https://www.nso.go.th/nsoweb/main/summano/aE?set_lang=en) 直接公布居住人口 70.3 百萬人；此值屬普查初步結果，應保留居住人口而非戶籍人口的統計口徑。

伺服器端抓取測試顯示，Stats NZ 的主題頁未穩定輸出摘要表，但固定的 [Estimated population of NZ](https://www.stats.govt.nz/indicators/population-of-nz/) 指標頁會在 HTML metadata 中按發布順序提供最新摘要；2026-08-18 更新內容為截至 2026-06-30 的 **5,357,300 人（暫定）**。自動更新應優先擷取該頁第一筆最新的季度觀測，並以來源本身最新修訂值取代先前摘要。
