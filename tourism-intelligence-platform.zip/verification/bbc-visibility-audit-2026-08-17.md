# BBC Travel 首頁可見性稽核

預覽頁面：目前首頁全文顯示 166 則近14天新聞，產業 INDEX 為「全部、世界10大觀光產業訊號、台灣觀光、旅宿市場、航空運能、旅遊成本、觀光行銷」。

首頁全文搜尋結果確認兩篇 BBC Travel 均存在於「全部」新聞列表：

| 來源 | 標題 | 日期 | 狀態 |
|---|---|---|---|
| BBC Travel | Why travellers are obsessed with foreign supermarkets - BBC | 08/13/2026 | 可見、具圖片、BBC來源 |
| BBC Travel | The invisible price of travelling safely as a woman - BBC | 08/10/2026 | 可見、具圖片、BBC來源 |

目前問題不是資料完全不存在，而是 BBC 文章埋在 166 則全部新聞中，且來源篩選選單尚未提供「BBC Travel」快速入口；世界10大訊號前十名也不保證包含 BBC。下一步應加入 BBC Travel 到 sourceOptions，並在來源篩選面板中可直接選取；同時可增加 BBC Travel 來源明確的可見提示或快速索引，讓使用者不用在長列表中尋找。

頁面現況的直接證據：`browser_find_keyword` 搜尋 `BBC Travel` 找到第一篇；搜尋 `The invisible price` 找到第二篇，卡片均標示 `BBC Travel ● 已索引`、英文標題及 BBC 來源。


快速索引互動驗證：首頁新增「BBC Travel 2」快速按鈕可見；點選後「本週情報」由166則變為2則，兩篇文章均保留英文標題、圖片、`BBC Travel`來源標示與 `bbc.com/travel/article/...` direct URL。這確認使用者現在可以直接找到 BBC Travel，而不必在全部新聞中捲動搜尋。
