# BBC Travel 與 Yahoo Travel 來源稽核

## BBC Travel 指定文章

官方頁面：https://www.bbc.com/travel/article/20260814-the-worlds-best-countries-for-expats-in-2026

官方文章標題為「The world's best countries for expats in 2026」，頁面摘要指出 2026 Expat Insider survey 評估31個目的地，涵蓋生活品質、落地適應、海外工作、個人財務、住房與數位服務；官方 og:image 可解析，圖片為 BBC ichef.bbci.co.uk 圖片。同步入庫 direct URL 為上述 bbc.com/travel/article URL，來源為 BBC Travel，發布日期為 2026-08-14。

## Yahoo Travel 公開來源

使用者指定首頁：https://travel.yahoo.com/

首頁公開索引可讀取英文文章、圖片與 direct URL，例如：

- https://travel.yahoo.com/guides/article/where-europeans-vacation-in-the-summer-145633365.html
- https://travel.yahoo.com/guides/united-states/article/best-states-for-swimming-150852648.html
- https://travel.yahoo.com/guides/portugal/article/most-affordable-portugal-destinations-183659014.html

Yahoo Travel 常見 `/rss`、`/rss.xml`、`/feed` 與 `/feed.xml` 端點回應404；`https://travel.yahoo.com/sitemap.xml` 回應200 application/xml。為取得日期與文章集合，平台目前採用限定 `site:travel.yahoo.com` 的公開 Google News RSS 查詢，再解析並回填 Yahoo Travel direct URL；Yahoo Travel feed 改為最近14天全量保留，不再要求每篇文章先通過一般觀光關鍵字門檻。

## 2026-08-17 同步稽核

同步稽核檔案：`verification/yahoo-bbc-sync-2026-08-17.json`

最近14天資料庫總數為243則，英文來源／英文標題稽核為31則，英文來源數5個；來源包含 BBC Travel、Yahoo Travel、Skift、Google News／海外英文與 UDN。BBC 指定文章已入庫並具圖片與 direct URL。Yahoo Travel 多篇近14天文章已入庫，例如：

- The 9 Tipping Mistakes That Embarrass Americans Overseas - Yahoo
- This Nevada ‘Star Train’ Is One of the Best Ways to See the U.S. Night Sky—Including the Milky Way - Yahoo
- Cruise Line Announces 10 Unique Cruises to the Caribbean - Yahoo
- This Secluded Paradise Outshines Hawaii And Bora Bora As The World's Most Scenic Island Of 2026 - Yahoo
- Dirtiest Cruise Ships in 2026 Based on the CDC’s Health Inspections - Yahoo
- Black Forest coolcation: tourism in Germany surges in 2026 - Yahoo

多數文章具圖片；沒有 RSS 圖片的文章仍會透過文章頁 metadata 補抓，並保留 Yahoo Travel 原文直連。


## 首頁驗證

重新載入首頁後，前端顯示 173 則最近14天新聞，世界10大觀光產業訊號顯示10則；快速索引顯示 BBC Travel 2 與 Yahoo Travel 6。首頁搜尋結果可見 Yahoo Travel 文章，例如 Black Forest coolcation、Cambodia island smoke-free tourism、Ithaca tourism surge、Portugal destinations、Favignana film tourism 與 Syria tourism revival；文章保留 Yahoo Travel 來源標示與原文直連。BBC Travel 指定文章已在同步稽核中確認入庫。


Yahoo Travel 快速索引互動驗證：點選「Yahoo Travel 6」後，首頁列表由173則縮減為6則；可見文章如 Black Forest coolcation、Cambodia island smoke-free tourism、Ithaca tourism surge 與 Portugal destinations，均呈現英文原文標題、Yahoo Travel來源、圖片及 travel.yahoo.com direct URL。


## BBC 指定文章前端驗證

修正來源可見性後重新載入首頁，快速索引顯示 BBC Travel 3、Yahoo Travel 29，首頁總新聞數為197。搜尋「The world's best countries for expats in 2026」成功找到第89則卡片，顯示日期 08/14/2026、來源 BBC Travel、英文原文標題與中文頁面摘要；指定文章因此已不再被首頁二次觀光關聯過濾隱藏。


## 世界10大訊號評分驗證

切換至「世界10大觀光產業訊號」後，10則達標卡片中已包含 Yahoo Travel 2則與 BBC Travel 1則。Yahoo Travel 卡片分數為70與70，BBC Travel 卡片分數為70；三者均顯示可信度20分，且來源優先影響力加成已反映於影響分數。其餘候選仍依觀光關聯、時效、跨國影響、台灣關聯、題型多樣性與60分門檻排序。
