# BBC Travel 同步驗證紀錄

同步時間：2026-08-17 04:03 UTC（台灣時間約 12:03）。

RSS 預檢：BBC Travel 站內查詢 RSS 回應 HTTP 200，約 110,852 bytes，解析出 2 則最近 14 天文章。直接測試 `https://www.bbc.com/travel/rss.xml`、`/travel/feed` 與 `https://feeds.bbci.co.uk/travel/rss.xml` 均為 404，因此採用 Google News RSS 的 `site:bbc.com/travel` 限定查詢，並在同步時解析為 BBC Travel direct URL；此方式只返回 BBC Travel 網域文章，不以 BBC News 一般新聞代替。

資料庫稽核：重新同步共取得 109 則，只有自由時報主 RSS 回應 404；最近 14 天資料共 210 則。英文來源統計包含 BBC Travel、Skift、Google News／海外英文與 UDN；BBC Travel 共有 2 則，均具備原文網址與圖片：

| 來源 | 英文原文標題 | 原文網址 | 圖片 |
|---|---|---|---|
| BBC Travel | Why travellers are obsessed with foreign supermarkets - BBC | https://www.bbc.com/travel/article/20260811-the-supermarket-is-becoming-a-tourist-attraction | 有 |
| BBC Travel | The invisible price of travelling safely as a woman - BBC | https://www.bbc.com/travel/article/20260807-the-controversial-economics-of-women-only-travel | 有 |

首頁驗證：預覽頁面顯示最近 14 天資料 182 則，左側「世界10大觀光產業訊號」顯示 10；全文搜尋 `BBC Travel` 找到上述兩則文章，來源標籤、英文標題與 direct URL 均可見。RSS 同步與 BBC Travel 回歸測試共 10 項通過，新聞分類與訊號評分測試亦通過。


訊號分類驗證：切換至「世界10大觀光產業訊號」後，頁面顯示 10 則達標訊號；目前前十名列表未包含 BBC Travel。BBC Travel 的兩則文章已在「全部」新聞列表可見，但因現有評分與新鮮度／台灣關聯排序，尚未進入前十名。這表示英文內容已成功同步與呈現；若需求是 BBC Travel 必須固定出現在世界10大分類，還需要另行加入來源保障或提高英文國際來源的候選排序權重，而非僅確認來源已入庫。
