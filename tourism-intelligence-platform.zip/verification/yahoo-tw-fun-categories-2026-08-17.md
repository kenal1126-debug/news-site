# Yahoo 台灣版「玩樂」五分類來源盤點

截至 2026-08-17，已確認 Yahoo 台灣版公開分類頁面如下：

| 使用者指定分類 | 官方頁面 | 頁面標題／觀察 |
|---|---|---|
| 最新熱門景點新聞 | https://tw.news.yahoo.com/tourist-spots/ | 頁面標題為「熱門景點 - Yahoo新聞」，頁首顯示「最新熱門景點新聞」 |
| 最新熱門美食新聞 | https://tw.news.yahoo.com/food/ | 頁首顯示「最新熱門美食新聞」 |
| 最新日韓旅遊新聞 | 尚待從 Yahoo 玩樂首頁導航取得精確 href | 玩樂首頁分類標題明確顯示「日韓旅遊」 |
| 最新賞花步道新聞 | https://tw.news.yahoo.com/outdoors/ | 頁首顯示「最新賞花步道新聞」，內容涵蓋步道與戶外旅遊 |
| 旅遊達人 | https://tw.news.yahoo.com/travel-blogger/ | 頁首顯示「旅遊達人」 |

Yahoo 玩樂首頁：https://tw.yahoo.com/travel/ 與 https://tw.news.yahoo.com/fun/。分類頁均公開列出文章標題、相對發布時間、來源、摘要、Yahoo direct URL 與圖片 metadata；目前同步模組只納入 Yahoo Travel 英文來源，尚未納入上述台灣版五個分類頁，因此需要新增頁面索引擷取與資料庫 upsert 入口。日韓旅遊的首頁導航文字已確認，但精確 href 尚待以頁面 DOM 取得。
