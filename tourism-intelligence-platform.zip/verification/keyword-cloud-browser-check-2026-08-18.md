# 雙語新聞關鍵詞雲瀏覽器驗證

- 驗證時間：2026-08-18（台灣時間）
- 驗證位置：首頁「總體經濟趨勢」正上方。
- 資料範圍：最近14天資料庫新聞標題與摘要。
- 呈現結果：中文與英文分為兩張獨立文字雲卡片，當次資料分別顯示中文280則、英文36則。
- 視覺檢查：桌面版以雙欄並列；中文使用中文排版字體，英文使用英文襯線字體；高頻詞以較大字級呈現。
- 修正：已排除 Yahoo、BBC 與 `nbsp` 等來源／HTML殘留字，避免非新聞主題字詞進入英文詞雲。
- 清理後驗證：英文雲保留 `tourism`、`scenic`、`town`、`trip`、`world`、`hotel`、`beach`、`forests` 等實際新聞詞彙，不再出現 Yahoo、BBC 或 `nbsp`。
- 桌面版視覺檢查：中文與英文卡片並列於總體經濟區塊正上方；中文與英文詞彙使用不同字體並依詞頻形成明確的字級層級。
- 雲狀版驗證：兩張卡片已改為獨立橢圓雲狀輪廓；最高頻中文詞「觀光」與英文詞「tourism」置中放大，其餘詞彙以固定、可重現的座標環繞。桌面瀏覽器檢查確認文字沒有重疊或截斷。
- 擴充版驗證：每朵雲已擴充至最多30個詞彙，並讓外圍低頻詞以較低字級與透明度適度重疊，形成更密集的自然雲形；中心最高頻詞仍保持可辨識。
- 泛用詞排除驗證：中文雲不再出現「觀光」「旅遊」「旅行」等泛用詞；英文雲不再出現 tourism、travel、tourist、trip 等泛用字形，改呈現經濟日報、日本、高雄、旅客、旅宿、景點、住宿及 hotel、scenic、beaches、overseas、coastal、forests 等具區辨力詞彙。
- 媒體名稱與熱力色階驗證：中文雲已移除「經濟日報」，英文雲已移除 Skift、BBC、Yahoo 等媒體名稱；詞彙依實際詞頻使用藍綠、綠、黃至紅的連續熱力色階，中心高頻詞「日本」及「most」呈紅色，低頻外圍詞呈藍綠色，卡片底部的「低—高」圖例可見。
- 英文 NLP 詞性分析驗證：英文雲已顯示「NLP 詞性篩選」註記，most、these、where、scenic、towns 等泛用或修飾字已從候選詞移除，保留 hotel、beach、forests、island、industry、countries、growth 等名詞與較具語意的詞彙；後續仍應持續用低訊號字表排除 away、unpack 等缺乏觀光市場判讀價值的詞。
- 情境式 NLP 最終驗證：伺服器端詞性服務成功回傳 `usedNlp: true`；英文雲目前顯示 hotel、beaches、island、industry、countries、growth、courses、cruise、flights、Florida、forest、Italy 等受近期英文新聞內容支持的名詞與具體市場詞。most、before、between、black、away、coastal、red、unpack 等功能詞、修飾詞與低訊號敘事詞未再出現；服務回應具6小時快取，且異常時回退至限制18詞的確定性篩選結果。
