import { createElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it } from "vitest";
import { TourismServiceAlertBanner } from "@/components/TourismServiceAlertBanner";

describe("首頁旅遊服務警示橫幅", () => {
  it("渲染事件、受影響服務、完整發布時間與原始來源連結", () => {
    const markup = renderToStaticMarkup(createElement(TourismServiceAlertBanner, {
      alerts: [{
        id: 810105,
        title: "國旅補助申請官網首日當掉 觀光署長：人數遠超預期",
        summary: "申請服務一度無法使用。",
        source: "TVBS新聞網",
        date: "08/20/2026",
        publishedAt: new Date("2026-08-20T07:49:00.000Z"),
        url: "https://news.tvbs.com.tw/life/4010102",
      }],
    }));

    expect(markup).toContain("國旅補助申請官網首日當掉");
    expect(markup).toContain("受影響服務");
    expect(markup).toContain("國旅補助申請官網");
    expect(markup).toContain("08/20 15:49");
    expect(markup).toContain("嚴重 · 紅色");
    expect(markup).toContain("is-critical");
    expect(markup).toContain('href="https://news.tvbs.com.tw/life/4010102"');
  });

  it("讓流量異常事件使用黃色注意樣式", () => {
    const markup = renderToStaticMarkup(createElement(TourismServiceAlertBanner, {
      alerts: [{
        id: 810106,
        title: "觀光署旅遊補助平台流量暴增、系統壅塞",
        summary: "部分旅客需稍後再試。",
        source: "中央社",
        date: "08/20/2026",
        url: "https://example.com/tourism-service-warning",
      }],
    }));

    expect(markup).toContain("注意 · 黃色");
    expect(markup).toContain("流量異常／壅塞");
    expect(markup).toContain("is-warning");
  });

  it("沒有高優先事件時不產生示範警示", () => {
    expect(renderToStaticMarkup(createElement(TourismServiceAlertBanner, { alerts: [] }))).toBe("");
  });
});
