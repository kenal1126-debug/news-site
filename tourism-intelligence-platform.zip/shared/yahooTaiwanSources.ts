export const YAHOO_TAIWAN_FUN_SOURCES = [
  "Yahoo台灣｜最新熱門景點新聞",
  "Yahoo台灣｜最新熱門美食新聞",
  "Yahoo台灣｜最新日韓旅遊新聞",
  "Yahoo台灣｜最新賞花步道新聞",
  "Yahoo台灣｜旅遊達人",
] as const;

export const YAHOO_TAIWAN_FUN_FILTER = "Yahoo 台灣玩樂";
export const INDUSTRY_MEDIA_SOURCES = ["旅奇週刊", "旅報", "旅奇傳媒"] as const;
export const INDUSTRY_MEDIA_FILTER = "產業媒體";

const SOURCE_FILTER_GROUPS: Record<string, readonly string[]> = {
  "ETtoday": ["ETtoday"],
  "中央社": ["中央社"],
  "三立新聞": ["三立"],
  "中時新聞網": ["中時"],
  "公視新聞網": ["公視"],
};

export function isYahooTaiwanFunSource(source: string) {
  return (YAHOO_TAIWAN_FUN_SOURCES as readonly string[]).includes(source);
}

export function isIndustryMediaSource(source: string) {
  return (INDUSTRY_MEDIA_SOURCES as readonly string[]).includes(source);
}

export function matchesNewsSourceFilter(source: string, selectedSource: string) {
  if (selectedSource === "全部來源") return true;
  if (selectedSource === YAHOO_TAIWAN_FUN_FILTER) return isYahooTaiwanFunSource(source);
  if (selectedSource === INDUSTRY_MEDIA_FILTER) return isIndustryMediaSource(source);
  const groupTerms = SOURCE_FILTER_GROUPS[selectedSource];
  if (groupTerms) return groupTerms.some((term) => source.includes(term));
  return source === selectedSource;
}
