export type NewsCategory = "旅遊平台" | "旅宿市場" | "航空運能" | "目的地行銷" | "台灣觀光" | "旅遊成本";

const TAIWAN_TERMS = [
  "台灣", "臺灣", "台北", "臺北", "新北", "桃園", "台中", "臺中", "台南", "高雄", "基隆", "新竹",
  "苗栗", "彰化", "南投", "雲林", "嘉義", "屏東", "宜蘭", "花蓮", "台東", "臺東", "澎湖", "金門", "馬祖",
  "東北角", "中台灣", "北海岸", "國旅", "觀光署", "交通部觀光署", "台灣旅遊業者", "臺灣旅遊業者",
];

const DESTINATION_MARKETING_TERMS = ["目的地", "朝聖", "世界三大", "海外", "國際", "推廣", "行銷", "拓展客源", "客源市場", "跨境"];
const TRANSPORT_TERMS = /機場|航班|航線|航空|飛機|客座率|機票|airport|airline|flight|aircraft|seat capacity/i;
const TRAVEL_PLATFORM_TERMS = /OTA|線上旅遊平台|線上旅行平台|Klook|KKday|ezTravel|易遊網|雄獅旅遊|可樂旅遊|東南旅遊|旅行社/;
export function hasTaiwanTourismContext(text: string) {
  return TAIWAN_TERMS.some((term) => text.includes(term));
}

export function inferNewsCategory(title: string, summary = "", source = ""): NewsCategory {
  const text = `${title} ${summary}`;
  void source;
  const hasTaiwan = hasTaiwanTourismContext(text);
  const isDestinationMarketing = DESTINATION_MARKETING_TERMS.some((term) => text.includes(term));

  const isOutboundPromotion = /海外|跨境|拓展客源|客源市場|前進(日本|韓國|釜山|新加坡|曼谷)/.test(text);
  if (TRANSPORT_TERMS.test(text)) return "航空運能";
  if (TRAVEL_PLATFORM_TERMS.test(text)) return "旅遊平台";
  if ((!hasTaiwan || isOutboundPromotion) && isDestinationMarketing) return "目的地行銷";
  if (/油價|燃油|附加費|票價|費用|成本|匯率|價格/.test(text)) return "旅遊成本";
  if (hasTaiwan && !isOutboundPromotion) return "台灣觀光";
  if (isDestinationMarketing) return "目的地行銷";
  if (/旅宿|飯店|酒店|民宿|住宿|住房|房價/.test(text)) return "旅宿市場";
  return hasTaiwan ? "台灣觀光" : "目的地行銷";
}
