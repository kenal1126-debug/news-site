import { describe, expect, it } from "vitest";
import { getTourismTopics, hasTourismContext, isElectionRelated, isGovernmentTourismServiceOutage, isIndustryMediaPromotion, isTourismRelated } from "./tourismTopics";

describe("tourism topic context", () => {
  it("excludes election-related tourism headlines", () => {
    expect(isElectionRelated("陸客大減 日本觀光依舊熱門 2026九合一選舉")).toBe(true);
    expect(isElectionRelated("張秀卿前夫宣布參選里長，防詐救觀光")).toBe(true);
    expect(isTourismRelated("新北願景 李四川提雙北生活圈 蘇巧慧暢談觀光政見")).toBe(false);
    expect(isTourismRelated("張秀卿前夫宣布參選里長，防詐救觀光")).toBe(false);
    expect(getTourismTopics("Global tourism campaign and candidate election platform")).toEqual([]);
  });

  it("keeps BBC Travel and Yahoo Travel recent articles visible as full-feed sources", () => {
    expect(isTourismRelated("The world's best countries for expats in 2026", "BBC Travel")).toBe(true);
    expect(isTourismRelated("Portugal announces a new entry policy for 2026", "Yahoo Travel")).toBe(true);
    expect(isTourismRelated("Yahoo Travel election campaign policy", "Yahoo Travel")).toBe(false);
  });

  it("excludes transaction and clearly promotional industry-media posts while retaining industry reporting", () => {
    expect(isIndustryMediaPromotion("暑假最後召集！四人房最低三千有找", "旅奇傳媒")).toBe(true);
    expect(isTourismRelated("暑假最後召集！四人房最低三千有找 旅遊住宿", "旅奇傳媒")).toBe(false);
    expect(isTourismRelated("菲律賓觀光部亮相旅展限定優惠搶攻市場", "旅報")).toBe(false);
    expect(isTourismRelated("高雄觀光滿意度連三年蟬聯六都第一", "旅奇傳媒")).toBe(true);
  });

  it("keeps non-election tourism policy announcements", () => {
    expect(isElectionRelated("觀光署公布國際旅客便利措施與旅遊安全政策")).toBe(false);
    expect(isTourismRelated("觀光署公布國際旅客便利措施與旅遊安全政策", "觀光署")).toBe(true);
    expect(isTourismRelated("交通部長宣布郵輪旅客安全政策", "交通部")).toBe(true);
  });

  it("keeps government tourism service outages as high-priority visitor-facing signals", () => {
    const text = "國旅補助申請官網首日當掉，觀光署啟動分流";
    expect(isGovernmentTourismServiceOutage(text)).toBe(true);
    expect(isTourismRelated(text, "TVBS新聞網")).toBe(true);
    expect(getTourismTopics(text)).toContain("遊");
  });

  it("rejects a generic government website outage without tourism-service context", () => {
    const text = "市府圖書館網站當機，民眾暫時無法登入借閱系統";
    expect(isGovernmentTourismServiceOutage(text)).toBe(false);
    expect(isTourismRelated(text, "地方新聞網")).toBe(false);
  });

  it("classifies tourism dining and lodging activity", () => {
    expect(getTourismTopics("旅客入住飯店並安排地方美食行程")).toEqual(expect.arrayContaining(["食", "宿", "遊"]));
  });

  it("classifies tourism transport but rejects unrelated transport news", () => {
    expect(getTourismTopics("觀光客搭乘高鐵前往景點")).toContain("行");
    expect(getTourismTopics("一般交通建設工程進度")).toEqual([]);
  });

  it("rejects a general community accessible-parking dispute", () => {
    const text = "社區要求撤趙建銘診所旁身障車位 交通局打回票";
    expect(getTourismTopics(text)).toEqual([]);
  });

  it("rejects resident parking enforcement without tourism context", () => {
    const text = "豐原新生北路兩側黃線停機車常挨罰 居民：機車要停哪裡？";
    expect(isTourismRelated(text)).toBe(false);
    expect(getTourismTopics(text)).toEqual([]);
  });

  it("keeps visitor-facing transport stories with concrete tourism context", () => {
    const text = "旅客前往豐原景點，市府規劃觀光接駁與合法停車資訊";
    expect(isTourismRelated(text)).toBe(true);
    expect(getTourismTopics(text)).toContain("行");
  });

  it("requires explicit tourism context for generic commerce terms", () => {
    expect(hasTourismContext("百貨公司公布年度營收")).toBe(false);
    expect(getTourismTopics("百貨公司公布年度營收")).toEqual([]);
    expect(getTourismTopics("旅客購買免稅伴手禮")).toContain("購");
  });

  it("rejects school construction news that only mentions a community concept", () => {
    const text = "興南國中遷建新校舍完工 融入客家聚落概念獲2026國家卓越建設獎 桃園機場捷運A21環北站附近興建新校";
    expect(isTourismRelated(text)).toBe(false);
    expect(getTourismTopics(text)).toEqual([]);
  });

  it("keeps cultural-place stories when they describe an actual tourism activity", () => {
    const text = "客家聚落規劃文化導覽與旅遊行程，開放遊客參觀景點";
    expect(isTourismRelated(text)).toBe(true);
    expect(getTourismTopics(text)).toContain("遊");
  });

  it.each([
    "歷史建築修復工程獲公共建設獎，改善社區生活環境",
    "客家聚落整建公共工程完工，地方政府舉辦啟用典禮",
    "文化中心新館落成，建築設計獲年度獎項肯定",
  ])("rejects non-tourism cultural or built-environment news: %s", (text) => {
    expect(isTourismRelated(text)).toBe(false);
    expect(getTourismTopics(text)).toEqual([]);
  });

  it("keeps a cultural tourism story with visitor-facing programming", () => {
    const text = "歷史建築轉型觀光景點，推出文化導覽與遊客參訪行程";
    expect(isTourismRelated(text)).toBe(true);
    expect(getTourismTopics(text)).toEqual(expect.arrayContaining(["遊"]));
  });
});
