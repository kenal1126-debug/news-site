export type FacetStory = {
  region: string;
  category: string;
  topics?: readonly string[];
};

export function countNewsFacets<T extends FacetStory>(stories: readonly T[]) {
  const count = (values: readonly string[]) => values.reduce<Record<string, number>>((result, value) => {
    result[value] = (result[value] ?? 0) + 1;
    return result;
  }, {});

  return {
    regions: count(stories.map((story) => story.region)),
    categories: count(stories.map((story) => story.category)),
    topics: count(stories.flatMap((story) => story.topics ?? [])),
  };
}
