export type NewsAnalysis = {
  impact: string;
  strategy: string;
};

type AnalysisRule = {
  keywords: string[];
  impact: string;
  strategy: string;
};

// Rules are intentionally content-led rather than source-led. BBC and other
// English-language stories use the same semantic rules as Chinese stories.
// The matching score lets a specific event (for example a wildfire) beat a
// broad destination or tourism keyword.
const RULES: AnalysisRule[] = [
  {
    keywords: [
      "強震", "地震", "震災", "天災", "颱風", "洪水", "土石流", "海嘯", "災害", "避難", "撤離", "災後", "受災", "停電",
      "earthquake", "aftershock", "wildfire", "wildfires", "flood", "flooding", "storm", "hurricane", "typhoon", "cyclone", "landslide", "tsunami", "disaster", "evacuation", "evacuate", "emergency", "heatwave", "heat wave", "drought",
    ],
    impact: "天災或極端氣候首先提高旅客與觀光從業人員的人身安全風險，並可能造成行程中斷、住宿退訂、交通受阻與旅宿及地方商圈的營運損失；後續影響還包括設施修復、觀光信心與災後重建成本。",
    strategy: "優先建立旅客與員工的預警、撤離、聯絡與安置機制，主動提供交通、住宿與行程變更資訊，並以彈性退改與保險／理賠協助降低損失；災後再盤點設施、現金流與供應鏈，與地方政府及業者協作復原重建，分階段恢復安全可營運的旅遊產品。",
  },
  {
    keywords: [
      "網站當機", "網站當掉", "官網當機", "官網當掉", "系統當機", "系統當掉", "系統壅塞", "系統塞爆", "網站壅塞", "當掉", "塞爆", "流量異常", "流量暴增", "服務中斷", "申請異常", "無法登入", "無法申請",
      "website outage", "site outage", "system outage", "server outage", "website crash", "traffic surge", "overloaded", "service disruption", "cannot log in", "unable to book",
    ],
    impact: "政府旅遊服務網站壅塞或中斷會直接阻礙旅客查詢、登錄、申請補助與完成預訂，也會增加旅行社、旅宿與客服的人工作業負荷；若發生在活動或補助上線初期，可能造成需求遞延、申訴增加與政策效益折損。",
    strategy: "優先公告受影響服務、替代申請管道、排隊進度與恢復時程，並以分流、延長申請期限、保留交易紀錄與客服回覆範本降低旅客不確定性；恢復後應檢視尖峰流量、失敗率與重試行為，作為下一次活動容量規劃依據。",
  },
  {
    keywords: [
      "飯店", "旅宿", "住宿", "住房", "民宿", "房價", "hotel", "hotels", "accommodation", "lodging", "room rate", "occupancy", "resort", "hostel",
    ],
    impact: "旅宿需求、房價與入住結構將直接影響目的地收益；若新聞涉及政策、氣候或交通變化，還會改變旅客的停留天數、訂房時點與退訂風險。",
    strategy: "以分眾定價調整平假日價格、房型與退改條件，將交通、餐飲與在地體驗綁入訂房流程；同步追蹤入住率、平均房價、取消率與平均停留天數，避免只用單一住房率判斷市場。",
  },
  {
    keywords: [
      "航班", "航空", "航線", "機場", "直飛", "班機", "改票", "airline", "airlines", "flight", "flights", "route", "airport", "direct flight", "capacity", "seat capacity", "air connectivity", "visa-free flight",
    ],
    impact: "航網、航班與票價變化會改變客源可達性、旺淡季流量與轉機路徑，並連動旅宿、旅行社、機場服務與景點的預訂需求；運能縮減時，熱門時段的價格與替代路線壓力會同步上升。",
    strategy: "依新增或縮減航線重新配置市場與產品，設計短天數及區域串聯行程，提前準備新航點與替代航點、接駁與改票方案；以航班量、客座率、票價、到站客流及轉換率檢查策略是否有效。",
  },
  {
    keywords: [
      "旅行社", "旅遊團", "套裝", "行程", "自由行", "旅遊商品", "tour operator", "package holiday", "package tour", "itinerary", "travel agency", "group tour", "independent travel",
    ],
    impact: "旅遊產品與通路調整會改變客源分配、產品毛利與目的地停留方式，業者也需要同步更新銷售內容、導遊安排與接待能力；資訊若不完整，容易放大取消與客服成本。",
    strategy: "把新聞事件轉成可直接上架的主題行程，提供分級價格、彈性退改與在地加購，並為受影響路段準備替代方案；以詢問到成交漏斗、取消率、毛利與旅客回饋迭代產品。",
  },
  {
    keywords: [
      "餐飲", "美食", "餐廳", "伴手禮", "購物", "商圈", "消費", "food", "foodie", "restaurant", "dining", "shopping", "retail", "consumer spending", "night market",
    ],
    impact: "餐飲與購物訊號會影響旅客的目的地選擇與單次消費；地方商圈若能承接流量，觀光人次才會轉化為在地收益，但成本上升或客流集中也可能壓縮店家毛利與服務品質。",
    strategy: "以美食、伴手禮與夜間商圈串成可步行或可接駁路線，提供多語資訊、預約與分流機制；追蹤客單價、回訪率、商圈停留時間及不同客源的消費轉換。",
  },
  {
    keywords: [
      "外派", "移居", "適合居住", "國家排名", "目的地", "景點", "觀光", "旅遊", "節慶", "展覽", "活動", "destination", "destinations", "attraction", "tourism", "travel", "festival", "event", "best countries", "best country", "expats", "expat", "livability", "quality of life",
    ],
    impact: "目的地聲量、生活品質或活動內容的變化會重新分配旅客與長住客的選擇、停留時間及季節需求；若只有一次性曝光，可能帶來人潮卻無法形成穩定住宿、交通與消費。",
    strategy: "先辨識新聞吸引的是短期旅客、長住客或特定興趣客群，再把目的地內容延伸為季節路線、交通接駁、長住服務與周邊消費地圖；以搜尋聲量、到訪、停留、回訪及客源結構檢驗是否形成可持續需求。",
  },
  {
    keywords: [
      "補助", "政策", "規定", "簽證", "入境", "免稅", "永續", "visa", "visa-free", "border", "entry rules", "entry requirement", "travel rules", "policy", "regulation", "tax-free", "sustainability", "carbon",
    ],
    impact: "政策與制度變化會改變旅遊成本、入境門檻、碳排要求與業者合規責任，市場反應通常會先反映在訂單時點、客源結構與取消率。",
    strategy: "把政策條文轉成旅客與第一線人員看得懂的價格、文件、接待與行銷調整，設定影響市場的監測表；同步準備不同政策情境的產品、退改與客服方案，避免只在規定生效後被動處理。",
  },
];

function addArticleAngle(text: string, analysis: NewsAnalysis): NewsAnalysis {
  const isPositive = ["增加", "成長", "上升", "回升", "新增", "開放", "復甦", "增長", "increase", "growth", "rising", "adds", "added", "opens", "recovery", "boom"].some((term) => text.includes(term));
  const isNegative = ["下降", "下滑", "減少", "退訂", "取消", "危機", "衰退", "縮減", "減班", "decline", "fall", "drop", "cut", "cuts", "cancel", "cancellation", "crisis", "risk", "threat"].some((term) => text.includes(term));
  const isRankingOrInspiration = ["排名", "最佳", "推薦", "童話", "奇幻", "best", "ranking", "ranked", "whimsical", "enchant", "inspiring", "guide"].some((term) => text.includes(term));
  const isPolicyOrRules = ["政策", "規定", "簽證", "入境", "visa", "policy", "regulation", "entry rule", "border"].some((term) => text.includes(term));

  if (isNegative) {
    return {
      impact: `${analysis.impact} 本篇同時帶有下滑、取消或風險訊號，短期應留意需求遞延、退訂與現金流壓力。`,
      strategy: `${analysis.strategy} 執行上先設定縮減、替代與復原情境，並每日追蹤取消率、客流與服務中斷狀況。`,
    };
  }
  if (isPositive) {
    return {
      impact: `${analysis.impact} 本篇呈現新增、成長或復甦訊號，機會在於把短期聲量轉成可衡量的訂單與在地消費。`,
      strategy: `${analysis.strategy} 執行上可先做小規模產品與通路測試，再依轉換率、客單價及停留時間擴大投入。`,
    };
  }
  if (isRankingOrInspiration) {
    return {
      impact: `${analysis.impact} 本篇屬於排名或靈感型內容，主要影響是提高目的地被發現與被比較的機會，未能直接證明實際旅客人次增加。`,
      strategy: `${analysis.strategy} 執行上應把文章中的景點與客群轉成可驗證的搜尋、點擊、到訪與消費指標，不宜只以曝光量判定成效。`,
    };
  }
  if (isPolicyOrRules) {
    return {
      impact: `${analysis.impact} 本篇的政策或規則變化仍需確認生效日期、適用對象與例外條件，否則不宜直接推估市場規模。`,
      strategy: `${analysis.strategy} 執行上先建立文件、價格與客服的版本控管，待官方細節確認後再調整產品與行銷投放。`,
    };
  }
  return analysis;
}

export function buildNewsAnalysis(title: string, summary = "", source = ""): NewsAnalysis {
  const text = `${title} ${summary} ${source}`.toLocaleLowerCase();
  const ranked = RULES.map((rule, index) => ({
    rule,
    index,
    score: rule.keywords.reduce((score, keyword) => score + (text.includes(keyword.toLocaleLowerCase()) ? 1 : 0), 0),
  }))
    .filter(({ score }) => score > 0)
    .sort((a, b) => b.score - a.score || a.index - b.index);

  const matched = ranked[0]?.rule;
  if (matched) return addArticleAngle(text, { impact: matched.impact, strategy: matched.strategy });

  return addArticleAngle(text, {
    impact: "此則訊號涉及觀光需求、供給或市場競爭的變化，可能透過客源、成本與旅客停留方式影響台灣觀光業者；目前內容不足以判定更細的衝擊面向。",
    strategy: "先補充事件的客源、產品與營運資訊，再建立一週內可執行的調整項目；在資料完整前，以流量、轉換、取消與消費結果持續觀察，不把推測當成確定結論。",
  });
}
