import { isElectionRelated, isTourismRelated } from "./tourismTopics";

export type SignalStory = {
  id: number;
  title: string;
  summary: string;
  source: string;
  date: string;
  url: string;
  image?: string;
  category: string;
  region: string;
  scope: string;
};

export type SignalScore = {
  impact: number;
  credibility: number;
  timeliness: number;
  crossBorder: number;
  taiwanRelevance: number;
  diversity: number;
  total: number;
};

export type TourismSignal = SignalStory & { score: SignalScore };

const TRUSTED_SOURCE_TERMS = [
  "Reuters", "Associated Press", "AP News", "BBC", "BBC Travel", "Yahoo Travel", "The Guardian", "Skift", "PhocusWire",
  "Travel Weekly", "eTurboNews", "Cirium", "UN Tourism", "WTTC", "PATA", "Tourism Administration",
  "觀光署", "交通部", "外交部", "經濟部", "文化部", "農業部", "觀旅局",
];

const PRIORITY_INTERNATIONAL_SOURCES = ["BBC Travel", "Yahoo Travel"];

const IMPACT_TERMS = [
  "tourism", "travel", "hotel", "hospitality", "airline", "airport", "flight", "destination",
  "market", "policy", "investment", "sustainability", "technology", "旅遊", "觀光", "旅宿", "航空", "航線", "政策", "市場", "永續", "數位",
];

const CROSS_BORDER_TERMS = [
  "global", "international", "asia", "europe", "america", "middle east", "跨境", "國際", "海外", "日本", "韓國", "美國", "歐洲", "東南亞", "中亞",
];

const TAIWAN_TERMS = ["Taiwan", "台灣", "臺灣", "觀光署", "交通部", "台北", "高雄", "台中", "Taipei", "Kaohsiung"];

const TAIWAN_DIRECT_REFERENCE_PATTERN = /\bTaiwan(?:ese)?\b|台灣|臺灣|台湾/i;

const GOVERNMENT_TOURISM_SERVICE_DISRUPTION_PATTERN = /(觀光署|觀旅局|觀光局|國旅補助|旅宿網|旅遊補助).{0,48}(網站當機|網站當掉|官網當機|官網當掉|系統當機|系統當掉|系統壅塞|系統塞爆|網站壅塞|當掉|塞爆|流量異常|流量暴增|服務中斷|申請異常|無法登入|無法申請)|(網站當機|網站當掉|官網當機|官網當掉|系統當機|系統當掉|系統壅塞|系統塞爆|網站壅塞|當掉|塞爆|流量異常|流量暴增|服務中斷|申請異常|無法登入|無法申請).{0,48}(觀光署|觀旅局|觀光局|國旅補助|旅宿網|旅遊補助)/i;

function isForeignNewsSite(story: SignalStory) {
  if (story.region !== "國際") return false;

  try {
    const hostname = new URL(story.url).hostname.toLowerCase();
    return !hostname.endsWith(".tw") && hostname !== "tw.news.yahoo.com";
  } catch {
    return false;
  }
}

function hasDirectTaiwanReference(story: SignalStory) {
  return TAIWAN_DIRECT_REFERENCE_PATTERN.test(`${story.title} ${story.summary}`);
}

export function isGovernmentTourismServiceDisruption(story: Pick<SignalStory, "title" | "summary">) {
  return GOVERNMENT_TOURISM_SERVICE_DISRUPTION_PATTERN.test(`${story.title} ${story.summary}`);
}

export type TourismServiceAlertSeverity = "critical" | "warning";

export function classifyTourismServiceAlertSeverity(story: Pick<SignalStory, "title" | "summary">): {
  level: TourismServiceAlertSeverity;
  label: string;
  description: string;
} {
  const text = `${story.title} ${story.summary}`;
  if (/(當機|當掉|服務中斷|無法登入|無法申請)/.test(text)) {
    return { level: "critical", label: "嚴重 · 紅色", description: "完全當機／服務中斷" };
  }
  return { level: "warning", label: "注意 · 黃色", description: "流量異常／壅塞" };
}

export function extractAffectedTourismService(story: Pick<SignalStory, "title" | "summary">) {
  const text = `${story.title} ${story.summary}`;
  if (/國旅補助.{0,20}(申請|官網|網站|系統)/.test(text)) return "國旅補助申請官網";
  if (/旅宿網/.test(text)) return "旅宿網服務平台";
  if (/旅遊補助.{0,20}(申請|官網|網站|系統)/.test(text)) return "旅遊補助申請平台";
  if (/(觀光署|觀旅局|觀光局).{0,20}(申請系統|系統)/.test(text)) return "政府旅遊申請系統";
  if (/(觀光署|觀旅局|觀光局).{0,20}(官網|網站)/.test(text)) return "政府旅遊資訊官網";
  return "政府旅遊服務平台";
}

function normalize(text: string) {
  return text.toLowerCase();
}

function countMatches(text: string, terms: string[]) {
  const normalized = normalize(text);
  return terms.filter((term) => normalized.includes(term.toLowerCase())).length;
}

function parseDate(value: string) {
  const parts = value.replace(/\//g, ".").split(".").map(Number);
  if (parts.length === 3 && parts.every(Number.isFinite)) return new Date(parts[2], parts[0] - 1, parts[1]);
  if (parts.length === 2 && parts.every(Number.isFinite)) return new Date(parts[1], parts[0] - 1, 1);
  const parsed = new Date(value);
  return Number.isNaN(parsed.getTime()) ? new Date(0) : parsed;
}

function timelinessScore(date: string, now: Date) {
  const ageDays = Math.max(0, (now.getTime() - parseDate(date).getTime()) / 86_400_000);
  if (ageDays <= 2) return 15;
  if (ageDays <= 5) return 12;
  if (ageDays <= 9) return 8;
  if (ageDays <= 14) return 4;
  return 0;
}

function baseScore(story: SignalStory, now: Date): Omit<SignalScore, "diversity" | "total"> {
  const text = `${story.title} ${story.summary} ${story.category} ${story.scope}`;
  const impactMatches = countMatches(text, IMPACT_TERMS);
  const sourcePriorityBoost = PRIORITY_INTERNATIONAL_SOURCES.some((term) => story.source.toLowerCase().includes(term.toLowerCase())) ? 6 : 0;
  const foreignTaiwanImpactBoost = isForeignNewsSite(story) && hasDirectTaiwanReference(story) ? 20 : 0;
  const serviceDisruptionImpactBoost = isGovernmentTourismServiceDisruption(story) ? 12 : 0;
  const impact = Math.min(30, impactMatches * 6 + (story.category !== "" ? 6 : 0) + sourcePriorityBoost + foreignTaiwanImpactBoost + serviceDisruptionImpactBoost);
  const credibility = TRUSTED_SOURCE_TERMS.some((term) => story.source.toLowerCase().includes(term.toLowerCase())) ? 20 : 8;
  const crossBorder = story.region === "國際" || countMatches(text, CROSS_BORDER_TERMS) > 0 ? 15 : 6;
  const taiwanRelevance = countMatches(text, TAIWAN_TERMS) > 0 ? 10 : 4;
  return { impact, credibility, timeliness: timelinessScore(story.date, now), crossBorder, taiwanRelevance };
}

export function scoreTourismSignal(story: SignalStory, now = new Date(), diversity = 10): SignalScore {
  const score = baseScore(story, now);
  const total = score.impact + score.credibility + score.timeliness + score.crossBorder + score.taiwanRelevance + diversity;
  return { ...score, diversity, total };
}

export function rankTourismSignals(stories: SignalStory[], now = new Date(), limit = 10): TourismSignal[] {
  const candidates = stories
    .filter((story) => !isElectionRelated(`${story.title} ${story.summary}`))
    .filter((story) => !/(no visitor|without visitor|no tourism|not tourism|無旅客|無旅遊|與觀光無關)/i.test(`${story.title} ${story.summary}`))
    .filter((story) => isTourismRelated(`${story.title} ${story.summary}`, story.source))
    .map((story) => ({ story, base: baseScore(story, now) }))
    .sort((a, b) => {
      const aBase = Object.values(a.base).reduce((sum, value) => sum + value, 0);
      const bBase = Object.values(b.base).reduce((sum, value) => sum + value, 0);
      return bBase - aBase;
    });

  const selected: TourismSignal[] = [];
  const usedCategories = new Set<string>();
  for (const candidate of candidates) {
    if (selected.length >= limit) break;
    const diversity = usedCategories.has(candidate.story.category) ? 4 : 10;
    const score = scoreTourismSignal(candidate.story, now, diversity);
    if (score.total < 60) continue;
    selected.push({ ...candidate.story, score });
    usedCategories.add(candidate.story.category);
  }
  return selected.sort((a, b) => b.score.total - a.score.total || parseDate(b.date).getTime() - parseDate(a.date).getTime());
}
