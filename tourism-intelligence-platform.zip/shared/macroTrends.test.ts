import { describe, expect, it } from "vitest";
import { macroTrends } from "./macroTrends";

describe("macroTrends", () => {
  it("labels Japan GDP as 2026 Q1 and CPI as June 2026", () => {
    const japan = macroTrends.find((trend) => trend.country === "日本");
    expect(japan).toMatchObject({
      quarter: "2026 Q1｜1–3 月・第一速報",
      gdp: "+0.5%",
      cpi: "+1.7%",
      cpiNote: expect.stringContaining("2026 年 6 月"),
    });
    expect(japan?.url).toContain("esri.cao.go.jp");
    expect(japan?.cpiUrl).toContain("stat.go.jp");
  });

  it("labels Korea GDP as 2026 Q2 and CPI as July 2026", () => {
    const korea = macroTrends.find((trend) => trend.country === "韓國");
    expect(korea).toMatchObject({
      quarter: "2026 Q2｜4–6 月・第一速報",
      gdp: "+0.6%",
      cpi: "119.77",
      cpiNote: expect.stringContaining("2026 年 7 月月增 -0.2%"),
    });
    expect(korea?.url).toContain("nttId=11063106");
    expect(korea?.cpiUrl).toContain("mods.go.kr");
  });

  it("includes official macro cards for Canada, Australia, and New Zealand", () => {
    expect(macroTrends).toEqual(expect.arrayContaining([
      expect.objectContaining({ country: "加拿大", quarter: "2026 Q1｜1–3 月・第一季", gdp: "0.0%", cpi: "+3.0%", url: expect.stringContaining("statcan.gc.ca"), cpiUrl: expect.stringContaining("statcan.gc.ca") }),
      expect.objectContaining({ country: "澳洲", quarter: "2025 Q4｜10–12 月・第一季", gdp: "+0.8%", cpi: "+3.8%", url: expect.stringContaining("abs.gov.au"), cpiUrl: expect.stringContaining("abs.gov.au") }),
      expect.objectContaining({ country: "紐西蘭", quarter: "2026 Q1｜1–3 月・第一季", gdp: "+0.8%", cpi: "+4.1%", url: expect.stringContaining("stats.govt.nz"), cpiUrl: expect.stringContaining("stats.govt.nz") }),
      expect.objectContaining({ country: "泰國", quarter: "2026 Q1｜1–3 月・第一季", gdp: "+2.8%", cpi: "102.10", url: expect.stringContaining("nesdc.go.th"), cpiUrl: expect.stringContaining("tpso.go.th") }),
    ]));
  });
});
