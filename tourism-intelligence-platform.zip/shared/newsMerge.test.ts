import { describe, expect, it } from "vitest";
import { mergeNewsByIdentity } from "./newsMerge";

describe("mergeNewsByIdentity", () => {
  it("stacks live and fallback stories without hiding fallback stories", () => {
    const live = [{ source: "Google News／聯合新聞網", title: "同步新聞", url: "https://example.com/live" }];
    const fallback = [
      { source: "自由時報", title: "既有新聞", url: "https://example.com/fallback" },
      { source: "舊來源", title: "同步新聞舊版本", url: "https://example.com/live" },
    ];

    expect(mergeNewsByIdentity(live, fallback)).toEqual([live[0], fallback[0]]);
  });

  it("merges equivalent titles even when RSS providers expose different URLs", () => {
    const primary = [{ source: "經濟日報", title: "數位產業署舉辦 AI DEMO DAY 促成科技業者與觀光旅宿產業交流媒合", url: "https://money.udn.com/without-image", image: "" }];
    const secondary = [{ source: "經濟日報", title: "數位產業署舉辦 AI DEMO DAY 促成科技業者與觀光旅宿產業交流媒合 - 經濟日報", url: "https://money.udn.com/with-image", image: "https://money.udn.com/article.jpg", summary: "完整新聞摘要" }];
    const result = mergeNewsByIdentity(primary, secondary);

    expect(result).toHaveLength(1);
    expect(result[0].url).toBe("https://money.udn.com/with-image");
    expect(result[0].image).toBe("https://money.udn.com/article.jpg");
  });

  it("keeps the newer row when duplicate quality is otherwise equal", () => {
    const older = [{ source: "經濟日報", title: "相同內容的觀光旅宿新聞", url: "https://example.com/older", image: "https://example.com/old.jpg", summary: "同一摘要", date: "08.13.2026" }];
    const newer = [{ source: "經濟日報", title: "相同內容的觀光旅宿新聞 - 經濟日報", url: "https://example.com/newer", image: "https://example.com/new.jpg", summary: "同一摘要", date: "08.14.2026" }];
    expect(mergeNewsByIdentity(older, newer)[0].url).toBe("https://example.com/newer");
  });

  it("uses source and title when a story has no URL", () => {
    const primary = [{ source: "A", title: "同標題" }];
    const secondary = [{ source: "A", title: "同標題" }, { source: "B", title: "另一則短標題" }];
    expect(mergeNewsByIdentity(primary, secondary)).toHaveLength(2);
  });

  it("merges titles with more than two thirds overlap in every category", () => {
    const primary = [
      { source: "A", category: "目的地行銷", title: "經濟放緩影響消費信心 中國人下半年出境游料低於預期", url: "https://example.com/a" },
      { source: "B", category: "航空運能", title: "日本千葉縣暴雨 成田機場航班受影響", url: "https://example.com/b" },
    ];
    const secondary = [
      { source: "C", category: "目的地行銷", title: "經濟放緩影響消費信心，中國人下半年出境游料低於預期分析", url: "https://example.com/c", image: "https://example.com/article.jpg" },
      { source: "D", category: "航空運能", title: "日本千葉縣暴雨 成田機場航班受影響：旅客可免費改期", url: "https://example.com/d" },
    ];
    const result = mergeNewsByIdentity(primary, secondary);
    expect(result).toHaveLength(2);
    expect(result.find((story) => story.category === "目的地行銷")?.url).toBe("https://example.com/c");
    expect(result.find((story) => story.category === "航空運能")?.url).toBe("https://example.com/b");
  });

  it("does not merge similar titles across different categories", () => {
    const result = mergeNewsByIdentity(
      [{ source: "A", category: "目的地行銷", title: "中國人下半年出境游料低於預期", url: "https://example.com/marketing" }],
      [{ source: "B", category: "旅遊成本", title: "中國人下半年出境游料低於預期", url: "https://example.com/cost" }],
    );
    expect(result).toHaveLength(2);
  });

  it("merges the three syndicated versions of the China outbound-travel story", () => {
    const result = mergeNewsByIdentity([
      { source: "經濟日報", category: "目的地行銷", title: "經濟放緩影響消費信心 中國人下半年出境游料低於預期 | 大陸政經 | 兩岸 - 經濟日報", url: "https://money.udn.com/money/story/5603/9662364" },
      { source: "Google News／經濟日報", category: "目的地行銷", title: "經濟放緩影響消費信心 中國人下半年出境游料低於預期 - 經濟日報", url: "https://money.udn.com/money/story/5603/9690843", image: "https://money.udn.com/article.jpg" },
    ], [
      { source: "UDN", category: "目的地行銷", title: "經濟放緩影響消費信心 中國人下半年出境旅遊料低於預期 - UDN", url: "https://udn.com/news/amp/story/7333/9690843" },
    ]);
    expect(result).toHaveLength(1);
    expect(result[0].image).toBe("https://money.udn.com/article.jpg");
    expect(result[0].url).toBe("https://money.udn.com/money/story/5603/9690843");
  });
});
