import { describe, expect, it } from "vitest";
import { buildNewsAnalysis } from "./newsAnalysis";

describe("buildNewsAnalysis", () => {
  it("prioritizes safety and recovery for a Kumamoto earthquake story", () => {
    const result = buildNewsAnalysis("熊本強震後住宿狂退訂…台灣旅客照赴約 留「1紙條」暖哭老闆", "地震後旅客安全、退訂與旅宿營運受到影響", "經濟日報");
    expect(result.impact).toContain("人身安全風險");
    expect(result.impact).toContain("營運損失");
    expect(result.strategy).toContain("撤離");
    expect(result.strategy).toContain("災後");
  });

  it("produces lodging-specific impact and strategy", () => {
    const result = buildNewsAnalysis("旅宿住房率回升", "飯店房價與住宿需求同步增加", "聯合新聞網");
    expect(result.impact).toContain("旅宿需求");
    expect(result.strategy).toContain("分眾定價");
  });

  it("produces airline-specific impact and strategy", () => {
    const result = buildNewsAnalysis("新增台北直飛航線", "航空公司增加航班", "自由時報");
    expect(result.impact).toContain("航網");
    expect(result.strategy).toContain("新航點");
  });

  it("prioritizes traveler communication for a government tourism service outage", () => {
    const result = buildNewsAnalysis("國旅補助申請官網首日當掉", "觀光署指出人數遠超預期，旅客暫時無法登入申請", "TVBS新聞網");
    expect(result.impact).toContain("旅客");
    expect(result.impact).toContain("申請補助");
    expect(result.strategy).toContain("替代申請管道");
    expect(result.strategy).toContain("恢復時程");
  });

  it("produces content-specific analyses for different BBC English stories", () => {
    const climate = buildNewsAnalysis(
      "Wildfires force evacuations across a popular European destination",
      "Tourists were advised to leave as smoke affected roads and hotels.",
      "BBC Travel",
    );
    const aviation = buildNewsAnalysis(
      "Airline adds new direct flight route to Asia",
      "The extra service is expected to increase seat capacity.",
      "BBC Travel",
    );
    const expat = buildNewsAnalysis(
      "The world's best countries for expats in 2026",
      "The ranking compares livability and quality of life for people considering a move abroad.",
      "BBC Travel",
    );

    expect(climate.impact).toContain("人身安全風險");
    expect(climate.strategy).toContain("撤離");
    expect(aviation.impact).toContain("航網");
    expect(aviation.strategy).toContain("替代航點");
    expect(expat.impact).toContain("生活品質");
    expect(expat.strategy).toContain("長住客");
    expect(new Set([climate.impact, aviation.impact, expat.impact]).size).toBe(3);
    expect(new Set([climate.strategy, aviation.strategy, expat.strategy]).size).toBe(3);
  });

  it("uses story content rather than publisher identity", () => {
    const bbc = buildNewsAnalysis(
      "Wildfires force evacuations across a popular European destination",
      "Tourists were advised to leave as smoke affected roads and hotels.",
      "BBC Travel",
    );
    const yahoo = buildNewsAnalysis(
      "Wildfires force evacuations across a popular European destination",
      "Tourists were advised to leave as smoke affected roads and hotels.",
      "Yahoo Travel",
    );
    const lodging = buildNewsAnalysis(
      "Hotels cut room rates during the quiet season",
      "Accommodation operators are targeting longer stays.",
      "BBC Travel",
    );

    expect(bbc).toEqual(yahoo);
    expect(bbc).not.toEqual(lodging);
    expect(lodging.impact).toContain("旅宿需求");
    expect(lodging.strategy).toContain("分眾定價");
  });

  it("adds a different article angle within the same destination category", () => {
    const growth = buildNewsAnalysis(
      "New festival opens in a coastal destination",
      "The event is expected to increase visitor interest.",
      "BBC Travel",
    );
    const risk = buildNewsAnalysis(
      "Storm warnings threaten a coastal destination",
      "Visitors were advised to avoid the area.",
      "BBC Travel",
    );
    const inspiration = buildNewsAnalysis(
      "A whimsical destination guide for a coastal town",
      "The article highlights colorful streets and unusual attractions.",
      "BBC Travel",
    );

    expect(growth.impact).toContain("新增、成長或復甦訊號");
    expect(risk.impact).toContain("風險訊號");
    expect(inspiration.impact).toContain("靈感型內容");
    expect(new Set([growth.impact, risk.impact, inspiration.impact]).size).toBe(3);
    expect(new Set([growth.strategy, risk.strategy, inspiration.strategy]).size).toBe(3);
  });

  it("always produces a concrete fallback analysis", () => {
    const result = buildNewsAnalysis("觀光產業市場訊號", "地方業者持續觀察市場變化", "測試來源");
    expect(result.impact).not.toContain("正在建立");
    expect(result.strategy).not.toContain("完成編輯審閱");
    expect(result.impact.length).toBeGreaterThan(20);
    expect(result.strategy.length).toBeGreaterThan(20);
  });
});
