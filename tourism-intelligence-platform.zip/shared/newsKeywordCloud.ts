export type NewsKeywordCloudLanguage = "中文" | "英文";

export type NewsKeywordCloudItem = {
  source: string;
  title: string;
  summary?: string | null;
};

export type NewsKeywordCloudTerm = {
  term: string;
  count: number;
  size: number;
};

export type NewsKeywordCloud = {
  language: NewsKeywordCloudLanguage;
  articleCount: number;
  terms: NewsKeywordCloudTerm[];
};

export type NewsKeywordCloudLayout = { left: number; top: number; rotate: number };

const CLOUD_LAYOUTS: NewsKeywordCloudLayout[] = [
  { left: 50, top: 48, rotate: 0 },
  { left: 28, top: 29, rotate: -6 },
  { left: 73, top: 30, rotate: 5 },
  { left: 20, top: 54, rotate: 4 },
  { left: 80, top: 56, rotate: -4 },
  { left: 50, top: 20, rotate: 1 },
  { left: 50, top: 78, rotate: -2 },
  { left: 29, top: 70, rotate: 6 },
  { left: 74, top: 72, rotate: -4 },
  { left: 20, top: 39, rotate: -4 },
  { left: 82, top: 40, rotate: 4 },
  { left: 39, top: 59, rotate: 3 },
  { left: 64, top: 59, rotate: -4 },
  { left: 35, top: 89, rotate: -2 },
  { left: 67, top: 89, rotate: 3 },
  { left: 50, top: 96, rotate: 0 },
  { left: 17, top: 67, rotate: -8 },
  { left: 83, top: 67, rotate: 8 },
  { left: 41, top: 36, rotate: -5 },
  { left: 60, top: 36, rotate: 6 },
  { left: 33, top: 47, rotate: 4 },
  { left: 68, top: 48, rotate: -7 },
  { left: 45, top: 66, rotate: 6 },
  { left: 56, top: 66, rotate: -5 },
  { left: 24, top: 87, rotate: -2 },
  { left: 78, top: 87, rotate: 4 },
  { left: 15, top: 25, rotate: -5 },
  { left: 86, top: 25, rotate: 6 },
  { left: 50, top: 34, rotate: 0 },
  { left: 50, top: 61, rotate: 2 },
];

const CHINESE_SOURCE_PATTERN = /[\u4e00-\u9fff]|(?:^|\.)udn(?:\.com)?|travel\.udn|money\.udn|woman\.udn|ltn\.com|storm\.mg|nownews\.com|tw\.news\.yahoo/i;
const ENGLISH_SOURCE_PATTERN = /BBC|Yahoo Travel|^Yahoo$|Skift|TaiwanPlus|Travel Weekly|eTurboNews|Reuters|Cirium|CNN|Bloomberg|Forbes|National Geographic|WTTC|UN Tourism/i;
const CHINESE_STOPWORDS = new Set(["最新", "新聞", "表示", "指出", "今年", "今日", "目前", "相關", "以及", "包括", "將會", "可以", "進行", "持續", "成為", "推出", "提供", "分享", "透過", "針對", "觀光", "旅遊", "旅行", "觀光旅遊", "旅遊業", "旅遊市場", "觀光產業", "台灣旅客", "旅遊新聞", "旅遊資訊", "完整", "一次", "看", "曝光", "報導", "台灣", "經濟日報", "自由時報", "聯合新聞網", "聯合報", "中央社", "中國時報", "中時新聞網", "工商時報", "風傳媒", "鏡週刊", "三立新聞網", "民視新聞網", "壹蘋新聞網", "台灣好新聞", "雅虎", "今日新聞"]);
const ENGLISH_STOPWORDS = new Set(["about", "actually", "adding", "after", "again", "all", "almost", "also", "almosafer", "already", "americans", "and", "another", "antidote", "any", "are", "around", "arrives", "article", "artsy", "audiences", "away", "avert", "back", "bad", "based", "bay", "bbc", "becoming", "been", "before", "being", "best", "between", "big", "black", "blockbuster", "bloomberg", "boaters", "bora", "both", "braces", "but", "california", "cambodia", "came", "can", "capital", "capsule", "caribbean", "cdc", "cheaper", "checking", "charm", "christopher", "cities", "city", "cirium", "cleaner", "cnn", "coastal", "completely", "congress", "cup", "despite", "during", "each", "eturbonews", "even", "every", "few", "first", "for", "forbes", "forests", "from", "geographic", "getting", "global", "great", "has", "have", "here", "high", "how", "into", "its", "just", "last", "little", "live", "local", "many", "more", "most", "much", "national", "nbsp", "new", "next", "news", "nolan's", "not", "now", "odyssey", "one", "only", "other", "out", "over", "overseas", "place", "places", "really", "red", "retire", "reuters", "scenic", "skift", "small", "some", "space", "state", "states", "still", "such", "taiwanplus", "than", "that", "the", "their", "these", "they", "this", "those", "three", "through", "to", "top", "town", "towns", "tour", "tours", "tourism", "tourist", "tourists", "travel", "traveler", "travelers", "traveller", "travellers", "traveling", "travelling", "trip", "trips", "two", "unpack", "very", "weekly", "what", "when", "where", "which", "who", "why", "will", "with", "without", "world", "wttc", "yahoo", "year", "you", "your"]);

type SegmenterEntry = { segment: string; isWordLike?: boolean };
type SegmenterLike = { segment(value: string): Iterable<SegmenterEntry> };
type IntlWithSegmenter = typeof Intl & { Segmenter?: new (locale: string, options: { granularity: "word" }) => SegmenterLike };

function hasChineseCharacters(value: string) {
  return /[\u4e00-\u9fff]/.test(value);
}

export function getNewsKeywordCloudLayout(index: number): NewsKeywordCloudLayout {
  return CLOUD_LAYOUTS[index % CLOUD_LAYOUTS.length];
}

export function getNewsKeywordHeatColor(count: number, highestCount: number, lowestCount: number) {
  const range = highestCount - lowestCount;
  const intensity = range === 0 ? 0.6 : Math.min(1, Math.max(0, (count - lowestCount) / range));
  const hue = Math.round(208 - intensity * 208);
  const lightness = Math.round(39 + intensity * 10);
  return `hsl(${hue} 67% ${lightness}%)`;
}

export function classifyNewsKeywordLanguage(item: NewsKeywordCloudItem): NewsKeywordCloudLanguage {
  if (CHINESE_SOURCE_PATTERN.test(item.source)) return "中文";
  if (ENGLISH_SOURCE_PATTERN.test(item.source)) return "英文";
  return hasChineseCharacters(`${item.title} ${item.summary ?? ""}`) ? "中文" : "英文";
}

function chineseTokens(value: string) {
  const Segmenter = (Intl as IntlWithSegmenter).Segmenter;
  if (Segmenter) {
    const segmenter = new Segmenter("zh-Hant", { granularity: "word" });
    return Array.from(segmenter.segment(value))
      .filter((entry) => entry.isWordLike !== false && /^[\u4e00-\u9fff]{2,8}$/.test(entry.segment))
      .map((entry) => entry.segment);
  }
  return value.match(/[\u4e00-\u9fff]{2,6}/g) ?? [];
}

function englishTokens(value: string) {
  return (value.toLowerCase().match(/[a-z][a-z'-]{2,}/g) ?? []).map((token) => token.replace(/^'+|'+$/g, ""));
}

function addTokens(frequencies: Map<string, number>, tokens: string[], stopwords: Set<string>, weight: number) {
  for (const token of tokens) {
    if (stopwords.has(token)) continue;
    frequencies.set(token, (frequencies.get(token) ?? 0) + weight);
  }
}

function mapTerms(frequencies: Map<string, number>, limit: number) {
  const ranked = Array.from(frequencies, ([term, count]) => ({ term, count }))
    .sort((a, b) => b.count - a.count || a.term.localeCompare(b.term, "zh-Hant"))
    .slice(0, limit);
  const highest = ranked[0]?.count ?? 1;
  const lowest = ranked.at(-1)?.count ?? highest;
  return ranked.map((item) => ({
    ...item,
    size: highest === lowest ? 22 : Math.round(12 + ((item.count - lowest) / (highest - lowest)) * 24),
  }));
}

export function buildNewsKeywordClouds(items: NewsKeywordCloudItem[], limit = 30): NewsKeywordCloud[] {
  const groups: Record<NewsKeywordCloudLanguage, NewsKeywordCloudItem[]> = { 中文: [], 英文: [] };
  for (const item of items) groups[classifyNewsKeywordLanguage(item)].push(item);

  return (["中文", "英文"] as const).map((language) => {
    const frequencies = new Map<string, number>();
    for (const item of groups[language]) {
      const title = item.title ?? "";
      const summary = item.summary ?? "";
      if (language === "中文") {
        addTokens(frequencies, chineseTokens(title), CHINESE_STOPWORDS, 3);
        addTokens(frequencies, chineseTokens(summary), CHINESE_STOPWORDS, 1);
      } else {
        addTokens(frequencies, englishTokens(title), ENGLISH_STOPWORDS, 3);
        addTokens(frequencies, englishTokens(summary), ENGLISH_STOPWORDS, 1);
      }
    }
    return { language, articleCount: groups[language].length, terms: mapTerms(frequencies, limit) };
  });
}
