import { describe, expect, it } from "vitest";
import { rankTourismSignals, scoreTourismSignal, type SignalStory } from "./tourismSignals";

const story = (overrides: Partial<SignalStory> = {}): SignalStory => ({
  id: 1,
  title: "Global tourism and airline market outlook",
  summary: "International travel, hotel demand and destination policy are changing across Asia.",
  source: "Reuters",
  date: "08.17.2026",
  url: "https://example.com/story",
  category: "航空運能",
  region: "國際",
  scope: "全球／航空",
  ...overrides,
});

describe("tourism industry signal scoring", () => {
  it("uses the six requested weights and totals 100 points or less", () => {
    const score = scoreTourismSignal(story(), new Date("2026-08-17T00:00:00Z"));
    expect(score.impact).toBeLessThanOrEqual(30);
    expect(score.credibility).toBeLessThanOrEqual(20);
    expect(score.timeliness).toBeLessThanOrEqual(15);
    expect(score.crossBorder).toBeLessThanOrEqual(15);
    expect(score.taiwanRelevance).toBeLessThanOrEqual(10);
    expect(score.diversity).toBeLessThanOrEqual(10);
    expect(score.total).toBe(score.impact + score.credibility + score.timeliness + score.crossBorder + score.taiwanRelevance + score.diversity);
  });

  it("qualifies BBC Travel as a trusted English tourism signal", () => {
    const result = rankTourismSignals([
      story({ source: "BBC Travel", title: "Why travellers are obsessed with foreign supermarkets", summary: "Travelers are changing how destinations and local food experiences shape tourism demand.", url: "https://www.bbc.com/travel/article/example" }),
    ], new Date("2026-08-17T00:00:00Z"));
    expect(result).toHaveLength(1);
    expect(result[0]?.score.total).toBeGreaterThanOrEqual(60);
    expect(result[0]?.score.credibility).toBe(20);
    expect(result[0]?.score.impact).toBeGreaterThanOrEqual(12);
  });

  it("gives Yahoo Travel the highest source credibility and qualifies a destination policy signal", () => {
    const result = rankTourismSignals([
      story({ source: "Yahoo Travel", title: "Portugal announces a new entry policy for 2026", summary: "International travel policy changes affect destinations, visitors, hotels and airline planning.", url: "https://travel.yahoo.com/news/article/portugal-policy.html" }),
    ], new Date("2026-08-17T00:00:00Z"));
    expect(result).toHaveLength(1);
    expect(result[0]?.score.credibility).toBe(20);
    expect(result[0]?.score.impact).toBeGreaterThanOrEqual(12);
    expect(result[0]?.score.total).toBeGreaterThanOrEqual(60);
  });

  it("adds 20 impact points when a foreign news site directly references Taiwan in English or Chinese", () => {
    const now = new Date("2026-08-17T00:00:00Z");
    const baseline = scoreTourismSignal(story({
      source: "BBC Travel",
      title: "Regional visitor outlook",
      summary: "A cultural note for visitors.",
      category: "",
      scope: "國際",
      url: "https://www.bbc.com/travel/article/regional-outlook",
    }), now);
    const taiwanStory = scoreTourismSignal(story({
      source: "BBC Travel",
      title: "Taiwan visitor outlook",
      summary: "A cultural note for visitors.",
      category: "",
      scope: "國際",
      url: "https://www.bbc.com/travel/article/taiwan-outlook",
    }), now);
    const chineseTaiwanStory = scoreTourismSignal(story({
      source: "Yahoo Travel",
      title: "臺灣 visitor outlook",
      summary: "A cultural note for visitors.",
      category: "",
      scope: "國際",
      url: "https://travel.yahoo.com/news/taiwan-outlook.html",
    }), now);

    expect(taiwanStory.impact).toBe(Math.min(30, baseline.impact + 20));
    expect(chineseTaiwanStory.impact).toBeGreaterThanOrEqual(20);
  });

  it("does not add the foreign-site Taiwan impact bonus to Taiwan-domain or domestic stories", () => {
    const now = new Date("2026-08-17T00:00:00Z");
    const foreignTaiwan = scoreTourismSignal(story({
      source: "BBC Travel",
      title: "Taiwan visitor outlook",
      summary: "A cultural note for visitors.",
      category: "",
      scope: "國際",
      url: "https://www.bbc.com/travel/article/taiwan-outlook",
    }), now);
    const domesticTaiwan = scoreTourismSignal(story({
      source: "Yahoo 奇摩",
      title: "台灣旅客動態",
      summary: "旅客出遊觀察。",
      category: "",
      region: "國內",
      scope: "國內",
      url: "https://tw.news.yahoo.com/taiwan-visitor-outlook.html",
    }), now);

    expect(domesticTaiwan.impact).toBeLessThan(foreignTaiwan.impact);
    expect(foreignTaiwan.impact).toBeLessThanOrEqual(30);
  });

  it("raises the impact score for an official tourism-service disruption", () => {
    const now = new Date("2026-08-20T00:00:00Z");
    const score = scoreTourismSignal(story({
      title: "國旅補助申請官網首日當掉",
      summary: "觀光署表示人數遠超預期，旅客暫時無法登入申請平日住宿補助。",
      source: "TVBS新聞網",
      date: "08.20.2026",
      category: "台灣觀光",
      region: "國內",
      scope: "台灣／國旅補助",
      url: "https://news.tvbs.com.tw/travel/4009859",
    }), now);
    expect(score.impact).toBe(24);
    expect(score.total).toBeGreaterThanOrEqual(60);
  });

  it("keeps only qualified tourism signals and ranks them by total score", () => {
    const result = rankTourismSignals([
      story(),
      story({ id: 2, title: "Small unrelated community notice", summary: "A local administrative update.", source: "Unknown", category: "", region: "國內" }),
    ], new Date("2026-08-17T00:00:00Z"));
    expect(result.length).toBe(1);
    expect(result[0]?.score.total).toBeGreaterThanOrEqual(60);
  });

  it("excludes election and general public-construction stories", () => {
    const result = rankTourismSignals([
      story({ id: 3, title: "Tourism policy and 2026 election campaign", summary: "Candidate campaign platform for travel.", source: "Reuters" }),
      story({ id: 4, title: "School building wins public construction award", summary: "A campus architecture project with no visitor program.", source: "Unknown", category: "台灣觀光", region: "國內" }),
    ], new Date("2026-08-17T00:00:00Z"));
    expect(result).toEqual([]);
  });

  it("returns no more than ten signals", () => {
    const result = rankTourismSignals(Array.from({ length: 15 }, (_, index) => story({ id: index + 10, title: `Global tourism destination signal ${index}` })), new Date("2026-08-17T00:00:00Z"));
    expect(result.length).toBeLessThanOrEqual(10);
  });
});
