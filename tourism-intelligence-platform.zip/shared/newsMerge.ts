export type NewsIdentity = {
  url?: string;
  source: string;
  title: string;
  summary?: string;
  image?: string;
  date?: string;
  category?: string;
};

const AGGREGATOR_HOSTS = ["news.google.com", "news.yahoo.com"];
const DEFAULT_IMAGE_MARKERS = ["atlas-hero-map", "default", "placeholder"];
const TITLE_SIMILARITY_THRESHOLD = 2 / 3;

export function normalizeNewsTitle(title: string) {
  return title
    .normalize("NFKC")
    .replace(/\s*[-|｜]\s*[^-|｜]{2,30}$/, "")
    .toLocaleLowerCase()
    .replace(/[\s、，。！？；：:,.!?（）()【】\[\]「」『』“”"'’‘·•…—–_-]+/g, "")
    .trim();
}

/**
 * Returns ordered character overlap against the longer normalized title.
 * A score greater than 2/3 is the editorial duplicate threshold.
 */
export function titleSimilarity(leftTitle: string, rightTitle: string) {
  const left = normalizeNewsTitle(leftTitle);
  const right = normalizeNewsTitle(rightTitle);
  if (!left || !right) return 0;
  if (left === right) return 1;

  const previous = new Array<number>(right.length + 1).fill(0);
  for (let i = 1; i <= left.length; i += 1) {
    let diagonal = 0;
    for (let j = 1; j <= right.length; j += 1) {
      const saved = previous[j];
      if (left[i - 1] === right[j - 1]) {
        previous[j] = diagonal + 1;
      } else {
        previous[j] = Math.max(previous[j], previous[j - 1]);
      }
      diagonal = saved;
    }
  }

  return previous[right.length] / Math.max(left.length, right.length);
}

function isAggregatorUrl(url?: string) {
  if (!url) return false;
  try {
    return AGGREGATOR_HOSTS.includes(new URL(url).hostname.replace(/^www\./, ""));
  } catch {
    return false;
  }
}

function hasUsefulImage(image?: string) {
  if (!image?.trim()) return false;
  const normalized = image.toLocaleLowerCase();
  return !DEFAULT_IMAGE_MARKERS.some((marker) => normalized.includes(marker));
}

function qualityScore<T extends NewsIdentity>(story: T) {
  return (
    (hasUsefulImage(story.image) ? 100 : 0) +
    (story.url && !isAggregatorUrl(story.url) ? 20 : 0) +
    (story.summary?.trim().length ?? 0) / 1000
  );
}

function publishedTime(story: NewsIdentity) {
  if (!story.date) return 0;
  const dotDate = story.date.match(/^(\d{2})\.(\d{2})\.(\d{4})$/);
  const time = dotDate ? Date.parse(`${dotDate[3]}-${dotDate[1]}-${dotDate[2]}`) : Date.parse(story.date);
  return Number.isFinite(time) ? time : 0;
}

function mergePair<T extends NewsIdentity>(left: T, right: T) {
  const rightScore = qualityScore(right);
  const leftScore = qualityScore(left);
  const preferred = rightScore > leftScore || (rightScore === leftScore && publishedTime(right) > publishedTime(left)) ? right : left;
  const other = preferred === left ? right : left;
  return {
    ...other,
    ...preferred,
    image: preferred.image || other.image,
    url: preferred.url || other.url,
    source: preferred.source || other.source,
    summary: preferred.summary?.trim() ? preferred.summary : other.summary,
  } as T;
}

function sameEditorialCategory(left: NewsIdentity, right: NewsIdentity) {
  return (left.category ?? "") === (right.category ?? "");
}

function isDuplicateTitle(left: NewsIdentity, right: NewsIdentity) {
  const leftTitle = normalizeNewsTitle(left.title);
  const rightTitle = normalizeNewsTitle(right.title);
  if (leftTitle === rightTitle) return Boolean(leftTitle);
  if (leftTitle.length < 8 || rightTitle.length < 8) return false;
  return titleSimilarity(left.title, right.title) > TITLE_SIMILARITY_THRESHOLD;
}

function isDuplicateStory(left: NewsIdentity, right: NewsIdentity) {
  const sameUrl = Boolean(left.url && right.url && left.url === right.url);
  return sameUrl || (sameEditorialCategory(left, right) && isDuplicateTitle(left, right));
}

/**
 * Merge live and fallback stories. Duplicate detection is applied within every
 * editorial category: exact normalized titles or titles with more than two
 * thirds ordered character overlap are treated as the same story.
 */
export function mergeNewsByIdentity<T extends NewsIdentity>(primary: T[], secondary: T[]) {
  const merged: T[] = [];
  for (const story of [...primary, ...secondary]) {
    const duplicateIndex = merged.findIndex((existing) => isDuplicateStory(existing, story));
    if (duplicateIndex < 0) {
      merged.push(story);
    } else {
      merged[duplicateIndex] = mergePair(merged[duplicateIndex], story);
    }
  }
  return merged;
}
