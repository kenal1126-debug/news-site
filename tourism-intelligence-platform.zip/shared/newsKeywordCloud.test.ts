import { describe, expect, it } from "vitest";
import { buildNewsKeywordClouds, classifyNewsKeywordLanguage, getNewsKeywordCloudLayout, getNewsKeywordHeatColor } from "./newsKeywordCloud";

describe("新聞關鍵詞雲", () => {
  const news = [
    { source: "Yahoo台灣｜最新熱門美食新聞", title: "經濟日報：台中美食與旅宿旅遊觀光熱度上升", summary: "美食旅遊帶動台中旅宿與景點需求" },
    { source: "經濟日報", title: "航空旅遊需求升溫", summary: "航空航線與旅客市場持續成長" },
    { source: "BBC Travel", title: "Taiwan tourism demand lifts hotel bookings", summary: "Travel demand and hotel bookings grow in Taiwan" },
    { source: "Skift", title: "Skift: Airline capacity reshapes tourism markets", summary: "Airline demand and tourism capacity remain key travel signals" },
  ];

  it("assigns Chinese websites and English websites to separate clouds", () => {
    expect(classifyNewsKeywordLanguage(news[0])).toBe("中文");
    expect(classifyNewsKeywordLanguage(news[1])).toBe("中文");
    expect(classifyNewsKeywordLanguage(news[2])).toBe("英文");
    expect(classifyNewsKeywordLanguage(news[3])).toBe("英文");
  });

  it("counts title terms more heavily and maps each cloud to independent terms", () => {
    const [chinese, english] = buildNewsKeywordClouds(news, 10);
    expect(chinese.articleCount).toBe(2);
    expect(english.articleCount).toBe(2);
    expect(chinese.terms.some((term) => ["觀光", "旅遊", "旅行", "觀光旅遊"].includes(term.term))).toBe(false);
    expect(chinese.terms.some((term) => term.term === "經濟日報")).toBe(false);
    expect(english.terms.some((term) => term.term === "demand")).toBe(true);
    expect(english.terms.some((term) => ["bbc", "nbsp", "yahoo", "skift", "tourism", "travel", "most", "scenic", "towns", "where", "americans", "these", "away", "coastal", "red", "unpack"].includes(term.term))).toBe(false);
    expect(english.terms.every((term) => term.size >= 12 && term.size <= 36)).toBe(true);
  });

  it("uses reproducible center-and-orbit coordinates for a cloud-shaped layout", () => {
    expect(getNewsKeywordCloudLayout(0)).toEqual({ left: 50, top: 48, rotate: 0 });
    expect(getNewsKeywordCloudLayout(1)).not.toEqual(getNewsKeywordCloudLayout(2));
    expect(getNewsKeywordCloudLayout(16)).not.toEqual(getNewsKeywordCloudLayout(0));
    expect(getNewsKeywordCloudLayout(30)).toEqual(getNewsKeywordCloudLayout(0));
  });

  it("maps actual term frequency to a cold-to-warm heat color", () => {
    expect(getNewsKeywordHeatColor(1, 10, 1)).toBe("hsl(208 67% 39%)");
    expect(getNewsKeywordHeatColor(10, 10, 1)).toBe("hsl(0 67% 49%)");
    expect(getNewsKeywordHeatColor(5, 10, 1)).not.toBe(getNewsKeywordHeatColor(1, 10, 1));
  });
});
