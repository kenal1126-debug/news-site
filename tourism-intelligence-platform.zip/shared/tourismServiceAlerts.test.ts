import { describe, expect, it } from "vitest";
import { classifyTourismServiceAlertSeverity, extractAffectedTourismService, isGovernmentTourismServiceDisruption } from "./tourismSignals";

describe("政府旅遊服務異常警示", () => {
  it("辨識國旅補助申請官網首日當掉事件", () => {
    expect(isGovernmentTourismServiceDisruption({
      title: "國旅補助申請官網首日當掉 觀光署長：人數遠超預期",
      summary: "申請服務一度無法使用，觀光署正在排除異常。",
    })).toBe(true);
  });

  it("不把一般企業網站故障誤判為政府旅遊服務異常", () => {
    expect(isGovernmentTourismServiceDisruption({
      title: "電商平台網站當機，使用者暫時無法結帳",
      summary: "業者表示正在排除系統問題。",
    })).toBe(false);
  });

  it("說明國旅補助事件受影響的服務", () => {
    expect(extractAffectedTourismService({
      title: "國旅補助申請官網首日當掉 觀光署長：人數遠超預期",
      summary: "申請服務一度無法使用。",
    })).toBe("國旅補助申請官網");
  });

  it("將完全當機與服務中斷標示為紅色嚴重事件", () => {
    expect(classifyTourismServiceAlertSeverity({
      title: "國旅補助申請官網首日當掉",
      summary: "服務一度中斷。",
    })).toMatchObject({ level: "critical", label: "嚴重 · 紅色" });
  });

  it("將流量異常與壅塞標示為黃色注意事件", () => {
    expect(classifyTourismServiceAlertSeverity({
      title: "觀光署旅遊補助平台流量暴增、系統壅塞",
      summary: "部分旅客需稍後再試。",
    })).toMatchObject({ level: "warning", label: "注意 · 黃色" });
  });
});
