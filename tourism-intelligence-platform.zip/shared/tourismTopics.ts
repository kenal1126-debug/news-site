export const TOURISM_TOPIC_KEYWORDS = {
  食: ["餐飲", "美食", "餐廳", "小吃", "伴手禮"],
  宿: ["旅宿", "飯店", "酒店", "民宿", "住宿", "露營", "溫泉"],
  遊: ["旅遊", "旅行", "觀光", "景點", "景區", "樂園", "郵輪", "旅展", "國旅", "出境", "入境", "行程", "tourism", "travel", "traveler", "traveller", "destination", "visitor"],
  購: ["商圈", "免稅", "百貨", "伴手禮", "消費", "購物"],
  行: ["航空", "航班", "航線", "機場", "高鐵", "台鐵", "客運", "交通", "租車", "接駁"],
  旅行社: ["旅行社", "旅遊團", "跟團", "自由行", "套裝行程", "旅遊商品"],
} as const;

const TOURISM_CONTEXT_KEYWORDS = [
  "旅遊", "旅行", "觀光", "旅客", "遊客", "景點", "景區", "目的地", "行程", "遊程",
  "旅行社", "旅宿", "住宿", "飯店", "民宿", "航班", "航線", "機場", "入境", "出境",
  "國旅", "旅展", "自由行", "跟團", "郵輪", "遊樂園", "免稅店", "觀光署", "旅遊業", "旅遊市場", "旅遊活動", "観光", "旅行者", "観光客", "訪日", "訪問客", "宿泊", "宿泊旅行", "入国", "出国", "観光庁", "tourism", "travel", "traveler", "traveller", "hotel", "hospitality", "airline", "airport", "flight", "destination", "visitor",
];

// Public works and school-construction articles can contain generic transport or
// official-tourism terms without describing a tourism activity. They require a
// concrete visitor, itinerary, destination, accommodation, or travel-operation signal.
const NON_TOURISM_INFRASTRUCTURE_TERMS = [
  "校舍", "學校", "國中", "國小", "校區", "校園", "遷校", "文中用地", "建設獎", "校舍完工",
  "文化", "客家", "聚落", "建築", "歷史建築", "文化資產", "文化中心", "公共建設", "school", "school building", "campus", "building", "architecture", "public construction",
];

const ELECTION_TERMS = [
  "選舉", "投票", "政黨", "候選人", "參選", "競選", "政見", "選票", "民調", "選區", "總統大選", "立委選舉", "九合一",
  "election", "candidate", "campaign", "voting", "ballot", "polling", "political party",
];

const CONCRETE_TOURISM_SIGNALS = [
  "旅遊", "旅行", "旅客", "遊客", "觀光客", "景點", "景區", "行程", "遊程", "目的地",
  "旅行社", "旅宿", "住宿", "飯店", "民宿", "航班", "航線", "航空", "飛機", "客座率", "機票", "登機",
  "入境", "出境", "國旅", "旅展", "自由行", "跟團", "郵輪", "遊樂園", "免稅店", "旅遊業", "旅遊市場", "旅遊活動", "導覽", "観光", "旅行者", "観光客", "訪日", "訪問客", "宿泊", "宿泊旅行", "入国", "出国", "観光庁", "tourism", "travel", "traveler", "traveller", "hotel", "hospitality", "airline", "airport", "flight", "destination", "visitor",
];

// These terms describe ordinary resident mobility or enforcement rather than
// visitor-facing transportation. They are rejected unless the same story also
// contains a concrete tourism signal such as a destination, visitor, itinerary,
// accommodation, airport, flight, or tourism operator.
const DAILY_TRANSPORT_TERMS = [
  "居民", "住戶", "社區", "機車", "停機車", "停車位", "停車", "違停", "取締", "開罰", "挨罰", "罰單",
  "黃線", "紅線", "車位", "道路", "路邊", "交通局", "警方", "拖吊", "通勤", "日常通行",
];

const TOURISM_SERVICE_OUTAGE_TERMS = [
  "網站當機", "網站當掉", "官網當機", "官網當掉", "系統當機", "系統當掉", "系統壅塞", "系統塞爆", "網站壅塞", "當掉", "塞爆", "流量異常", "流量暴增", "服務中斷", "申請異常", "無法登入", "無法申請",
];

const GOVERNMENT_TOURISM_SERVICE_TERMS = [
  "觀光署", "觀旅局", "觀光局", "交通部觀光署", "國旅補助", "旅宿網", "台灣旅宿網", "旅遊補助", "旅行業管理", "旅遊資訊網",
];

const INDUSTRY_MEDIA_SOURCES = /^(旅奇週刊|旅報|旅奇傳媒)$/;
const INDUSTRY_MEDIA_PROMOTION_TERMS = /(?:最低\s*(?:\d|[一二三四五六七八九十百千萬])|優惠|立即搶購|團費只要|抽獎送|贈品|票券轉讓|住宿券轉讓|\[交易\]|\[徵求\])/;

export function isIndustryMediaPromotion(text: string, source = "") {
  return INDUSTRY_MEDIA_SOURCES.test(source.trim()) && INDUSTRY_MEDIA_PROMOTION_TERMS.test(text);
}

function hasConcreteTourismSignal(text: string) {
  return CONCRETE_TOURISM_SIGNALS.some((keyword) => text.includes(keyword));
}

export function isDailyTransportOnly(text: string) {
  const normalized = text.replace(/\s+/g, "").toLowerCase();
  const dailyMatches = DAILY_TRANSPORT_TERMS.filter((keyword) => normalized.includes(keyword.toLowerCase())).length;
  return dailyMatches >= 2 && !hasConcreteTourismSignal(normalized);
}

export function isGovernmentTourismServiceOutage(text: string) {
  const normalized = text.replace(/\s+/g, "").toLowerCase();
  return TOURISM_SERVICE_OUTAGE_TERMS.some((keyword) => normalized.includes(keyword))
    && GOVERNMENT_TOURISM_SERVICE_TERMS.some((keyword) => normalized.includes(keyword.toLowerCase()));
}

export type TourismTopic = keyof typeof TOURISM_TOPIC_KEYWORDS;

export function hasTourismContext(text: string) {
  return TOURISM_CONTEXT_KEYWORDS.some((keyword) => text.includes(keyword));
}

export function isElectionRelated(text: string) {
  const normalized = text.replace(/\s+/g, "").toLowerCase();
  return ELECTION_TERMS.some((keyword) => normalized.includes(keyword.replace(/\s+/g, "").toLowerCase()));
}

export function getTourismTopics(text: string): TourismTopic[] {
  const normalized = text.replace(/\s+/g, "");
  if (isElectionRelated(normalized)) return [];
  if (isDailyTransportOnly(normalized)) return [];
  if (isGovernmentTourismServiceOutage(normalized)) return ["遊"];
  if (!hasTourismContext(normalized)) return [];

  const isInfrastructureOnly = NON_TOURISM_INFRASTRUCTURE_TERMS.some((keyword) => normalized.includes(keyword));
  if (isInfrastructureOnly && !hasConcreteTourismSignal(normalized)) return [];

  return (Object.entries(TOURISM_TOPIC_KEYWORDS) as [TourismTopic, readonly string[]][]) 
    .filter(([, keywords]) => keywords.some((keyword) => normalized.includes(keyword)))
    .map(([topic]) => topic);
}

export function isTourismRelated(text: string, source = "") {
  if (isElectionRelated(text)) return false;
  if (isIndustryMediaPromotion(text, source)) return false;
  if (isDailyTransportOnly(text)) return false;
  if (isGovernmentTourismServiceOutage(text)) return true;
  if (/^(BBC Travel|Yahoo Travel)$/i.test(source.trim())) return true;
  if (getTourismTopics(text).length > 0) return true;
  const isOfficialSource = /觀光署|交通部|外交部|經濟部|文化部|農業部|觀旅局|Tourism Administration|Ministry of Transportation|Ministry of Foreign Affairs/i.test(source);
  const isPolicyAnnouncement = /部長|署長|局長|部會|政策|措施|記者會|新聞稿|minister|ministry|policy|press release/i.test(text);
  return isOfficialSource && isPolicyAnnouncement && hasTourismContext(text);
}
