import { describe, expect, it } from "vitest";
import { isYahooTaiwanFunSource, matchesNewsSourceFilter, YAHOO_TAIWAN_FUN_FILTER, YAHOO_TAIWAN_FUN_SOURCES } from "./yahooTaiwanSources";

describe("Yahoo 台灣玩樂來源群組", () => {
  it("defines all five mandatory travel and food sources", () => {
    expect(YAHOO_TAIWAN_FUN_SOURCES).toHaveLength(5);
    expect(YAHOO_TAIWAN_FUN_SOURCES).toContain("Yahoo台灣｜最新熱門美食新聞");
    expect(YAHOO_TAIWAN_FUN_FILTER).toBe("Yahoo 台灣玩樂");
  });

  it("matches only the mandatory Yahoo Taiwan Fun sources", () => {
    expect(isYahooTaiwanFunSource("Yahoo台灣｜最新熱門景點新聞")).toBe(true);
    expect(isYahooTaiwanFunSource("Yahoo台灣｜旅遊達人")).toBe(true);
    expect(isYahooTaiwanFunSource("Yahoo Travel")).toBe(false);
    expect(isYahooTaiwanFunSource("經濟日報")).toBe(false);
  });

  it("filters all five Yahoo Taiwan Fun sources with one selected filter", () => {
    expect(matchesNewsSourceFilter("Yahoo台灣｜最新熱門美食新聞", YAHOO_TAIWAN_FUN_FILTER)).toBe(true);
    expect(matchesNewsSourceFilter("Yahoo台灣｜旅遊達人", YAHOO_TAIWAN_FUN_FILTER)).toBe(true);
    expect(matchesNewsSourceFilter("Yahoo Travel", YAHOO_TAIWAN_FUN_FILTER)).toBe(false);
    expect(matchesNewsSourceFilter("經濟日報", "全部來源")).toBe(true);
    expect(matchesNewsSourceFilter("經濟日報", "BBC Travel")).toBe(false);
  });

  it("filters newly added domestic media sources and can return to all sources", () => {
    expect(matchesNewsSourceFilter("TVBS新聞網", "TVBS新聞網")).toBe(true);
    expect(matchesNewsSourceFilter("ETtoday旅遊雲", "ETtoday")).toBe(true);
    expect(matchesNewsSourceFilter("ETtoday", "ETtoday")).toBe(true);
    expect(matchesNewsSourceFilter("中央社好生活", "中央社")).toBe(true);
    expect(matchesNewsSourceFilter("三立娛樂星聞", "三立新聞")).toBe(true);
    expect(matchesNewsSourceFilter("中時新聞網", "中時新聞網")).toBe(true);
    expect(matchesNewsSourceFilter("TVBS新聞網", "全部來源")).toBe(true);
    expect(matchesNewsSourceFilter("ETtoday", "全部來源")).toBe(true);
  });
});
