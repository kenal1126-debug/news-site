import { describe, expect, it } from "vitest";
import { hasTaiwanTourismContext, inferNewsCategory } from "./newsClassification";

describe("inferNewsCategory", () => {
  it("classifies an overseas pilgrimage route as destination marketing", () => {
    const title = "【趣吧】世界三大朝聖之路入門｜不只是徒步，一場走進內心的慢旅| 美食旅遊 - udn 女子漾";
    expect(hasTaiwanTourismContext(title)).toBe(false);
    expect(inferNewsCategory(title, "介紹西班牙、義大利與日本的海外朝聖路線與慢旅行體驗")).toBe("目的地行銷");
  });

  it("keeps Taiwan destination content in Taiwan tourism when it names Taiwan geography", () => {
    expect(inferNewsCategory("台中推廣中台灣山海屯城旅遊", "邀請旅客體驗台灣景點與旅宿")).toBe("台灣觀光");
  });

  it("does not classify a Taiwan outbound promotion as generic Taiwan tourism", () => {
    expect(inferNewsCategory("觀光署前進釜山拓展韓國客源", "在海外推廣台灣旅遊產品與目的地體驗")).toBe("目的地行銷");
  });

  it("prioritizes aviation capacity when a Taiwan tourism story mentions an airport", () => {
    expect(inferNewsCategory("日本千葉縣50年來大暴雨 觀光署：台灣團未受影響", "成田機場與航班運作是旅客行程判斷的重要資訊")).toBe("航空運能");
  });

  it.each([
    "Klook",
    "KKday",
    "ezTravel 易遊網",
    "雄獅旅遊",
    "可樂旅遊",
    "東南旅遊",
  ])("classifies %s as a travel platform or agency", (operator) => {
    expect(inferNewsCategory(`${operator} 推出熱門景點與在地體驗商品`, "提供旅客預訂旅遊服務")).toBe("旅遊平台");
  });

  it("does not use a generic group-tour keyword alone to classify a story as a travel platform", () => {
    expect(inferNewsCategory("日本團體行程未受影響", "機場維持正常運作")).toBe("航空運能");
  });

  it("classifies overseas tourism media by its actual industry category", () => {
    expect(inferNewsCategory("Global tourism demand reshapes destinations", "International travelers and hotel markets continue to shift", "Reuters")).toBe("目的地行銷");
    expect(inferNewsCategory("Hotels and airlines prepare for global travel demand", "Visitor flows are changing across markets", "Travel Weekly")).toBe("航空運能");
  });
});
