import { describe, expect, it } from "vitest";
import { countNewsFacets } from "./newsCounts";

describe("countNewsFacets", () => {
  it("counts regions, categories, and tourism topics from the same story set", () => {
    const counts = countNewsFacets([
      { region: "國內", category: "台灣觀光", topics: ["遊", "行"] },
      { region: "國內", category: "航空運能", topics: ["行"] },
      { region: "國際", category: "旅宿市場", topics: ["宿", "食"] },
    ]);
    expect(counts.regions).toEqual({ 國內: 2, 國際: 1 });
    expect(counts.categories).toEqual({ 台灣觀光: 1, 航空運能: 1, 旅宿市場: 1 });
    expect(counts.topics).toEqual({ 遊: 1, 行: 2, 宿: 1, 食: 1 });
  });
});
