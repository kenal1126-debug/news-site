import { describe, expect, it } from "vitest";
import { decodeHtmlEntities, normalizeHtmlText } from "./textNormalization";

describe("HTML text normalization", () => {
  it("decodes nbsp and numeric space entities before collapsing redundant whitespace", () => {
    expect(normalizeHtmlText("觀光&nbsp;&nbsp;市場&#160;需求&#xA0;回升")).toBe("觀光 市場 需求 回升");
  });

  it("preserves textual ampersands while removing markup and CDATA wrappers", () => {
    expect(decodeHtmlEntities("<![CDATA[旅宿 &amp; 航空]]>")).toBe("旅宿 & 航空");
    expect(normalizeHtmlText("<p>台灣&nbsp;旅遊</p> <strong>市場</strong>")).toBe("台灣 旅遊 市場");
  });
});
