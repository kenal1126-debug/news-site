export type MacroTrend = {
  country: string;
  quarter: string;
  gdp: string;
  gdpNote: string;
  cpi: string;
  cpiNote: string;
  reading: string;
  url: string;
  cpiUrl: string;
  fx: string;
  fxNote: string;
  fxUrl: string;
};

export const macroTrends: MacroTrend[] = [
  {
    country: "日本",
    quarter: "2026 Q1｜1–3 月・第一速報",
    gdp: "+0.5%",
    gdpNote: "實質 GDP 季增；年化 +2.1%",
    cpi: "+1.7%",
    cpiNote: "CPI 年增，2026 年 6 月；2025 基期連結資料",
    fx: "JPY/TWD 0.1991–0.2031",
    fxNote: "台銀現貨買入／賣出，2026-08-14",
    reading: "第一季實質經濟溫和復甦；6 月物價仍年增，與日圓匯率共同影響台灣旅客的日本旅遊成本。產品設計可聚焦短程、季節與地方深度體驗。",
    url: "https://www.esri.cao.go.jp/en/sna/data/sokuhou/files/2026/qe261/gdemenuea.html",
    cpiUrl: "https://www.stat.go.jp/english/data/cpi/index.html",
    fxUrl: "https://rate.bot.com.tw/xrt?Lang=en-US",
  },
  {
    country: "韓國",
    quarter: "2026 Q2｜4–6 月・第一速報",
    gdp: "+0.6%",
    gdpNote: "實質 GDP 季增；年增 +3.7%",
    cpi: "119.77",
    cpiNote: "CPI 指數，2020=100；2026 年 7 月月增 -0.2%",
    fx: "KRW/TWD 0.02086–0.02476",
    fxNote: "台銀現貨買入／賣出，2026-08-14",
    reading: "第二季實質 GDP 延續成長；7 月物價指數與匯率反映韓國旅客赴台的購買力條件。台灣可用短天數、交通便利與季節活動降低決策門檻。",
    url: "https://www.bok.or.kr/eng/bbs/E0000634/view.do?nttId=11063106&menuNo=400423&relate=Y&depth=400423&programType=newsDataEng",
    cpiUrl: "https://mods.go.kr/anse/",
    fxUrl: "https://rate.bot.com.tw/xrt?Lang=en-US",
  },
  {
    country: "加拿大",
    quarter: "2026 Q1｜1–3 月・第一季",
    gdp: "0.0%",
    gdpNote: "實質 GDP 季增；人均 GDP +0.2%",
    cpi: "+3.0%",
    cpiNote: "CPI 年增，2026 年 7 月",
    fx: "CAD/TWD 22.45–23.36",
    fxNote: "台銀現金買入／賣出，2026-08-18",
    reading: "第一季實質 GDP 持平，家庭支出仍小幅增加，但出境旅行支出走弱；7 月 CPI 年增 3.0%，加拿大旅客的海外旅遊預算與目的地價格敏感度仍需觀察。台灣可用高價值體驗與透明套裝價格降低決策阻力。",
    url: "https://www150.statcan.gc.ca/n1/daily-quotidien/260529/dq260529a-eng.htm",
    cpiUrl: "https://www.statcan.gc.ca/en/subjects-start/prices_and_price_indexes/consumer_price_indexes",
    fxUrl: "https://rate.bot.com.tw/xrt?Lang=en-US",
  },
  {
    country: "澳洲",
    quarter: "2025 Q4｜10–12 月・第一季",
    gdp: "+0.8%",
    gdpNote: "實質 GDP 季增；年增 +2.6%",
    cpi: "+3.8%",
    cpiNote: "CPI 年增，2026 年 6 月；月減 0.1%",
    fx: "AUD/TWD 22.23–23.01",
    fxNote: "台銀現金買入／賣出，2026-08-18",
    reading: "澳洲經濟在 2025 年第四季成長，家庭支出與活動消費回升；6 月 CPI 年增 3.8%，旅遊需求仍受住宿、交通與娛樂價格影響。台灣可鎖定長程高意向客源，提供季節、航線與多日產品的清楚價值組合。",
    url: "https://www.abs.gov.au/media-centre/media-releases/australian-economy-grew-08-december-quarter",
    cpiUrl: "https://www.abs.gov.au/statistics/economy/price-indexes-and-inflation/consumer-price-index-australia/latest-release",
    fxUrl: "https://rate.bot.com.tw/xrt?Lang=en-US",
  },
  {
    country: "紐西蘭",
    quarter: "2026 Q1｜1–3 月・第一季",
    gdp: "+0.8%",
    gdpNote: "實質 GDP 季增；年增 +0.8%",
    cpi: "+4.1%",
    cpiNote: "CPI 年增，2026 年 6 月季；季增 +1.5%",
    fx: "NZD/TWD 18.31–19.16",
    fxNote: "台銀現金買入／賣出，2026-08-18",
    reading: "紐西蘭第一季 GDP 成長，零售、住宿與運輸等服務活動仍有支撐；但 6 月 CPI 年增 4.1%，燃料與能源價格會提高長程旅遊成本。台灣可強化淡季、自然體驗與多站式行程的價格透明度。",
    url: "https://www.stats.govt.nz/information-releases/gross-domestic-product-march-2026-quarter/",
    cpiUrl: "https://www.stats.govt.nz/information-releases/consumers-price-index-june-2026-quarter/",
    fxUrl: "https://rate.bot.com.tw/xrt?Lang=en-US",
  },
  {
    country: "泰國",
    quarter: "2026 Q1｜1–3 月・第一季",
    gdp: "+2.8%",
    gdpNote: "實質 GDP 年增；季增 +0.7%（季調）",
    cpi: "102.10",
    cpiNote: "CPI 指數；2026 年 7 月年增 +1.95%",
    fx: "THB/TWD 0.9455–0.9915",
    fxNote: "台銀即期買入／賣出，2026-08-18",
    reading: "第一季經濟成長由投資、出口與私人消費帶動；7 月燃料與交通成本推升物價。泰國既是重要來台客源，也是台灣旅客常見目的地，宜以航班、檔期與價格透明度同步管理雙向旅遊需求。",
    url: "https://www.nesdc.go.th/download/%E0%B9%80%E0%B8%AD%E0%B8%81%E0%B8%AA%E0%B8%B2%E0%B8%A3%E0%B9%81%E0%B8%96%E0%B8%A5%E0%B8%87%E0%B8%82%E0%B9%88%E0%B8%B2%E0%B8%A7-press-release-eng-19/?ddl=110034",
    cpiUrl: "https://www.tpso.go.th/en/document/2608-0000000001",
    fxUrl: "https://rate.bot.com.tw/xrt?Lang=en-US",
  },
];
