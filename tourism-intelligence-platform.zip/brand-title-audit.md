# 品牌標題修正稽核

本輪將 `client/index.html` 的網站標題、description、Open Graph title 與 Open Graph description 統一更新為「觀光趨勢」。

## 全專案來源搜尋

以 `grep -R` 掃描專案來源，排除 `node_modules`、`dist`、`.manus-logs` 與 source map。結果只找到設計參考文件 `ideas.md` 與本工作階段待辦文件中的歷史文字；`ideas.md` 已同步改為「觀光趨勢」，待辦中的舊字樣屬變更歷史紀錄，不會進入部署資產或頁面 runtime。

## 首頁 DOM 稽核

2026-08-14 於首頁預覽執行 DOM 讀取，結果如下：

- `document.title`: `觀光趨勢｜Tourism Atlas Weekly Intelligence`
- `meta[name="description"]`: `觀光趨勢：把分散的觀光新聞整理成可搜尋、可判讀、可追溯的產業方向。`
- `meta[property="og:title"]`: `觀光趨勢｜Tourism Atlas Weekly Intelligence`
- `meta[property="og:description"]`: `觀光趨勢：觀光產業新聞、總體經濟與國際市場情報。`
- `document.documentElement.innerHTML.includes("旅觀誌")`: `false`

桌面版與 375×812 手機版首頁截圖均確認導覽品牌、Hero 品牌與頁面版面正常，未出現溢出或錯位。
