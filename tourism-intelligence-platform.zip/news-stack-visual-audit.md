# 新聞持續堆疊與圖片驗證紀錄

驗證日期：2026-08-14。

修正後首頁 DOM 實際抽查結果：新聞卡片共 128 則；`imageMissing` 為 0；日期排序檢查 `datesNonIncreasing` 為 false，代表卡片順序維持由新到舊。前 8 則卡片均有圖片 src，其中缺少原始圖片的項目統一使用 `/manus-storage/atlas-hero-map_10be6641.jpg` 代表圖，並保留「查看原文」href。

來源分布包含聯合新聞網 68 則、經濟日報 19 則、NOWnews 15 則、自由時報 8 則、Google News 6 則，以及其他既有來源；可確認先前 Google News 與既有新聞並未因 live 資料存在而整批隱藏。前 8 則 href 抽查包含自由時報直接原文 URL、Google News RSS URL，且來源文字與卡片一致。

桌面版 1280×720 與手機版 375×812 長頁預覽均完成檢查，新聞圖片區塊維持一致版型，來源、主題標籤、日期與原文按鈕沒有水平溢出或卡片錯位。

測試結果：Vitest 4 個測試檔、10 項測試全部通過；涵蓋 RSS 圖片擷取、live／fallback 合併去重、duplicate upsert 圖片保留語意；TypeScript 檢查與正式建置均通過。
