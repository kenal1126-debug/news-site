import React from "react";
import { AlertTriangle, ExternalLink } from "lucide-react";
import { classifyTourismServiceAlertSeverity, extractAffectedTourismService, type SignalStory } from "@shared/tourismSignals";

type TourismServiceAlertStory = Pick<SignalStory, "id" | "title" | "summary" | "source" | "url"> & {
  date: string;
  publishedAt?: Date;
};

function formatTourismServiceAlertPublishedAt(alert: TourismServiceAlertStory) {
  if (!alert.publishedAt) return alert.date;
  return new Intl.DateTimeFormat("zh-TW", {
    timeZone: "Asia/Taipei",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  }).format(alert.publishedAt);
}

export function TourismServiceAlertBanner({ alerts }: { alerts: TourismServiceAlertStory[] }) {
  if (alerts.length === 0) return null;

  return (
    <section className="tourism-service-alert" aria-labelledby="tourism-service-alert-title" role="alert">
      <div className="tourism-service-alert-marker"><AlertTriangle size={20} aria-hidden="true" /></div>
      <div className="tourism-service-alert-intro">
        <span>HIGH PRIORITY / TOURISM SERVICE</span>
        <strong id="tourism-service-alert-title">旅遊服務警示</strong>
      </div>
      <div className="tourism-service-alert-items">
        {alerts.map((alert) => {
          const severity = classifyTourismServiceAlertSeverity(alert);
          return (
            <article className={`tourism-service-alert-item is-${severity.level}`} key={alert.id}>
              <div className="tourism-service-alert-headline">
                <span className="tourism-service-alert-severity">{severity.label}</span>
                <span className="tourism-service-alert-severity-description">{severity.description}</span>
              </div>
              <p>{alert.title}</p>
              <div>
                <span className="tourism-service-alert-details"><b>受影響服務</b>{extractAffectedTourismService(alert)} <i>·</i> {alert.source} <i>·</i> {formatTourismServiceAlertPublishedAt(alert)}</span>
                <a href={alert.url} target="_blank" rel="noreferrer">查看原始來源 <ExternalLink size={13} /></a>
              </div>
            </article>
          );
        })}
      </div>
    </section>
  );
}
