import { ArrowUp } from "lucide-react";
import React, { useEffect, useState } from "react";

export const BACK_TO_TOP_SCROLL_THRESHOLD = 480;

export function BackToTopButton({ threshold = BACK_TO_TOP_SCROLL_THRESHOLD }: { threshold?: number }) {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const updateVisibility = () => setVisible(window.scrollY > threshold);
    updateVisibility();
    window.addEventListener("scroll", updateVisibility, { passive: true });
    return () => window.removeEventListener("scroll", updateVisibility);
  }, [threshold]);

  return (
    <button
      type="button"
      aria-label="回到頁首"
      title="回到頁首"
      onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
      className={`fixed bottom-5 right-5 z-50 grid h-11 w-11 place-items-center rounded-full border border-[#d7c9b3] bg-[#fffdf8]/95 text-[#8f3922] shadow-[0_8px_24px_rgba(57,42,30,0.18)] backdrop-blur transition-all duration-200 hover:-translate-y-1 hover:bg-[#8f3922] hover:text-white focus:outline-none focus-visible:ring-2 focus-visible:ring-[#8f3922] focus-visible:ring-offset-2 active:scale-95 ${visible ? "pointer-events-auto translate-y-0 opacity-100" : "pointer-events-none translate-y-3 opacity-0"}`}
    >
      <ArrowUp className="h-5 w-5" aria-hidden="true" />
    </button>
  );
}
