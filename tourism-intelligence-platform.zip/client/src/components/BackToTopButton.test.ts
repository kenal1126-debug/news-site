// @vitest-environment jsdom
import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import { createElement } from "react";
import { afterEach, describe, expect, it, vi } from "vitest";
import { BackToTopButton } from "./BackToTopButton";

afterEach(() => {
  cleanup();
  vi.restoreAllMocks();
  Object.defineProperty(window, "scrollY", { configurable: true, value: 0 });
});

describe("BackToTopButton", () => {
  it("appears after the reading threshold and scrolls smoothly to the document top", () => {
    const scrollTo = vi.spyOn(window, "scrollTo").mockImplementation(() => undefined);
    Object.defineProperty(window, "scrollY", { configurable: true, value: 600 });
    render(createElement(BackToTopButton, { threshold: 480 }));

    const button = screen.getByRole("button", { name: "回到頁首" });
    expect(button.className).toContain("opacity-100");
    fireEvent.click(button);
    expect(scrollTo).toHaveBeenCalledWith({ top: 0, behavior: "smooth" });
  });

  it("remains inactive before the reading threshold", () => {
    Object.defineProperty(window, "scrollY", { configurable: true, value: 120 });
    render(createElement(BackToTopButton, { threshold: 480 }));
    expect(screen.getByRole("button", { name: "回到頁首" }).className).toContain("pointer-events-none");
  });
});
