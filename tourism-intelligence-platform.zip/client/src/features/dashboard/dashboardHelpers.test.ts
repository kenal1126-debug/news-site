import { describe, expect, it } from "vitest";
import { displayCategoryLabel, formatIssueRange, formatNextNewsUpdate, mapKeywordCloudSync, normalizeNewsSource, parseStoryDate, sourceOptions } from "./dashboardHelpers";

describe("dashboard helpers", () => {
  it("normalizes media aliases and preserves direct source filters", () => {
    expect(normalizeNewsSource("自由時報生活")).toBe("自由時報");
    expect(normalizeNewsSource("Google News／TVBS新聞網")).toBe("Google News");
    expect(sourceOptions).toContain("TVBS新聞網");
    expect(sourceOptions).toContain("ETtoday");
  });

  it("keeps the public editorial labels and date range semantics stable", () => {
    expect(displayCategoryLabel("目的地行銷")).toBe("觀光行銷");
    expect(parseStoryDate("08.20.2026").toISOString().slice(0, 10)).toBe("2026-08-20");
    expect(formatIssueRange(new Date("2026-08-21T00:00:00Z"))).toBe("08 — 21 AUG 2026");
  });

  it("maps the latest news sync query into the Hero audit payload", () => {
    expect(mapKeywordCloudSync({ id: "sync-run-001", completedAt: "2026-08-30T02:00:00.000Z", status: "success" })).toEqual({ batchId: "sync-run-001", completedAt: "2026-08-30T02:00:00.000Z", status: "success" });
    expect(mapKeywordCloudSync(null)).toBeNull();
  });

  it("calculates the next Taiwan news update from the 11:00 and 20:00 daily slots", () => {
    expect(formatNextNewsUpdate(new Date("2026-08-26T02:59:00Z"))).toBe("今日 11:00（台灣時間）");
    expect(formatNextNewsUpdate(new Date("2026-08-26T03:00:00Z"))).toBe("今日 20:00（台灣時間）");
    expect(formatNextNewsUpdate(new Date("2026-08-26T11:59:00Z"))).toBe("今日 20:00（台灣時間）");
    expect(formatNextNewsUpdate(new Date("2026-08-26T12:00:00Z"))).toBe("明日 11:00（台灣時間）");
  });
});
