import { inferNewsCategory } from "@shared/newsClassification";
import { YAHOO_TAIWAN_FUN_FILTER } from "@shared/yahooTaiwanSources";
import { type Category, type Region, SIGNAL_CATEGORY } from "./types";

export const DEFAULT_NEWS_IMAGE = "/manus-storage/atlas-hero-map_10be6641.jpg";
export const REGION_LABELS: Region[] = ["全部", "國內", "國際"];
export const CATEGORY_LABELS: Category[] = ["全部", SIGNAL_CATEGORY, "台灣觀光", "旅宿市場", "航空運能", "旅遊成本", "目的地行銷"];
export const TOPIC_LABELS = ["食", "宿", "遊", "購", "行"] as const;

export const sourceOptions = ["全部來源", "BBC Travel", "Yahoo Travel", YAHOO_TAIWAN_FUN_FILTER, "TVBS新聞網", "中央社", "ETtoday", "三立新聞", "中時新聞網", "公視新聞網", "自由時報", "經濟日報", "聯合新聞網", "NOWnews", "Google News", "交通部觀光署", "台中市觀旅局", "風傳媒", "TaiwanPlus", "Travel Weekly", "eTurboNews", "僑委會／中央社"] as const;

export function resolveInitialSourceFilter() {
  if (typeof window === "undefined") return "全部來源";
  const selected = new URLSearchParams(window.location.search).get("source");
  return sourceOptions.includes(selected as (typeof sourceOptions)[number]) ? selected! : "全部來源";
}

export function resolveInitialSourceFilterOpen() {
  if (typeof window === "undefined") return false;
  return new URLSearchParams(window.location.search).get("showSourceFilter") === "1";
}

export function normalizeNewsSource(source: string) {
  if (source === "自由時報" || source === "自由時報生活") return "自由時報";
  if (source.includes("聯合新聞網")) return "聯合新聞網";
  if (source.includes("經濟日報")) return "經濟日報";
  if (source.includes("NOWnews")) return "NOWnews";
  if (source.startsWith("Google News")) return "Google News";
  return source;
}

export function formatIssueRange(now: Date) {
  const start = new Date(now);
  start.setDate(start.getDate() - 13);
  const day = new Intl.DateTimeFormat("en-US", { day: "2-digit" });
  const month = new Intl.DateTimeFormat("en-US", { month: "short" });
  const year = new Intl.DateTimeFormat("en-US", { year: "numeric" });
  const sameMonth = start.getFullYear() === now.getFullYear() && start.getMonth() === now.getMonth();
  if (sameMonth) return `${day.format(start)} — ${day.format(now)} ${month.format(now).toUpperCase()} ${year.format(now)}`;
  return `${day.format(start)} ${month.format(start).toUpperCase()} ${year.format(start)} — ${day.format(now)} ${month.format(now).toUpperCase()} ${year.format(now)}`;
}

const TAIWAN_NEWS_UPDATE_MINUTES = [11 * 60, 20 * 60] as const;

export type LatestNewsSyncRecord = { id: string; completedAt: Date | string | null; status: string };

export function mapKeywordCloudSync(latestSync: LatestNewsSyncRecord | null | undefined) {
  return latestSync ? { batchId: latestSync.id, completedAt: latestSync.completedAt, status: latestSync.status } : null;
}

export function formatNextNewsUpdate(now: Date) {
  const parts = new Intl.DateTimeFormat("en-US", { timeZone: "Asia/Taipei", hour: "2-digit", minute: "2-digit", hourCycle: "h23" }).formatToParts(now);
  const hour = Number(parts.find((part) => part.type === "hour")?.value ?? 0);
  const minute = Number(parts.find((part) => part.type === "minute")?.value ?? 0);
  const currentMinute = hour * 60 + minute;
  const nextUpdateMinute = TAIWAN_NEWS_UPDATE_MINUTES.find((slot) => currentMinute < slot);
  const updateMinute = nextUpdateMinute ?? TAIWAN_NEWS_UPDATE_MINUTES[0];
  const dayLabel = nextUpdateMinute === undefined ? "明日" : "今日";
  return `${dayLabel} ${String(Math.floor(updateMinute / 60)).padStart(2, "0")}:${String(updateMinute % 60).padStart(2, "0")}（台灣時間）`;
}

export function inferRegion(title: string, summary: string, source: string): Exclude<Region, "全部"> {
  const text = `${title} ${summary} ${source}`;
  return /日本|韓國|加拿大|澳洲|紐西蘭|東南亞|海外|國際|出境|外國旅客|跨境/.test(text) ? "國際" : "國內";
}

export function inferCategory(title: string, summary: string, source: string): Exclude<Category, "全部"> {
  return inferNewsCategory(title, summary, source);
}

export function displayCategoryLabel(category: string) {
  return category === "目的地行銷" ? "觀光行銷" : category;
}

export function parseStoryDate(value: string) {
  const parts = value.replace(/\//g, ".").split(".").map(Number);
  if (parts.length === 3 && parts.every((part) => Number.isFinite(part))) return new Date(parts[2], parts[0] - 1, parts[1]);
  if (parts.length === 2 && parts.every((part) => Number.isFinite(part))) return new Date(parts[1], parts[0] - 1, 1);
  return new Date(0);
}
