import { describe, expect, it } from "vitest";
import { classifyDemandStrength, selectCapacityPressureSignal, selectDashboardMetrics, selectDemandEarlySignal, selectFilteredStories, selectSourceMarketSignal, selectVisibleStories } from "./dashboardSelectors";
import type { Story } from "../types";

const stories: Story[] = [
  { id: 1, region: "國內", category: "台灣觀光", date: "08.20.2026", source: "TVBS新聞網", title: "國旅補助申請官網首日當掉", summary: "觀光署表示服務中斷，旅客暫時無法申請。", insight: "服務異常", scope: "台灣", url: "https://example.com/tvbs" },
  { id: 2, region: "國際", category: "旅宿市場", date: "08.19.2026", source: "ETtoday旅遊雲", title: "飯店需求上升", summary: "住宿市場持續成長。", insight: "旅宿訊號", scope: "國際", url: "https://example.com/ettoday" },
  { id: 3, region: "國內", category: "台灣觀光", date: "08.18.2026", source: "旅奇週刊", title: "旅奇產業訊號", summary: "旅遊市場訊號。", insight: "產業訊號", scope: "台灣", url: "https://example.com/travelrich" },
  { id: 4, region: "國內", category: "台灣觀光", date: "08.17.2026", source: "旅報", title: "旅報產業訊號", summary: "旅遊市場訊號。", insight: "產業訊號", scope: "台灣", url: "https://example.com/ttn" },
  { id: 5, region: "國內", category: "台灣觀光", date: "08.16.2026", source: "旅奇傳媒", title: "旅奇傳媒產業訊號", summary: "旅遊市場訊號。", insight: "產業訊號", scope: "台灣", url: "https://example.com/tromni" },
];

describe("dashboard selectors", () => {
  it("keeps service alerts and dynamic facets in the dashboard view model", () => {
    const metrics = selectDashboardMetrics(stories);
    expect(metrics.tourismServiceAlerts.map((story) => story.id)).toEqual([1]);
    expect(metrics.regions.find((item) => item.label === "全部")?.count).toBe(5);
    expect(metrics.categories.find((item) => item.label === "台灣觀光")?.count).toBe(4);
    expect(metrics.industryMediaCount).toBe(3);
  });

  it("filters grouped sources and returns an empty state when no story matches", () => {
    expect(selectFilteredStories({ visibleStories: stories, activeRegion: "全部", activeCategory: "全部", activeSource: "ETtoday", query: "", signalIds: new Set() }).map((story) => story.id)).toEqual([2]);
    expect(selectFilteredStories({ visibleStories: stories, activeRegion: "國內", activeCategory: "旅宿市場", activeSource: "全部來源", query: "不存在", signalIds: new Set() })).toEqual([]);
  });

  it("filters every approved industry-media source as one group", () => {
    expect(selectFilteredStories({ visibleStories: stories, activeRegion: "全部", activeCategory: "全部", activeSource: "產業媒體", query: "", signalIds: new Set() }).map((story) => story.id)).toEqual([3, 4, 5]);
  });

  it("derives demand early signals from the same ranked keyword-cloud terms", () => {
    const signal = selectDemandEarlySignal([
      { language: "中文", articleCount: 4, terms: [{ term: "機票", count: 9, size: 32 }] },
      { language: "英文", articleCount: 2, terms: [{ term: "flights", count: 6, size: 24 }] },
    ], [
      { ...stories[0], title: "機票需求上升" },
      { ...stories[1], title: "Flights booking improves" },
    ]);
    expect(signal.articleCount).toBe(6);
    expect(signal.terms.map((term) => term.term)).toEqual(["機票", "flights"]);
    expect(signal.terms.map((term) => term.supportCount)).toEqual([1, 1]);
    expect(signal.sourceLabel).toBe("新聞文字雲高頻詞");
    expect(signal.level).toBe("弱");
    expect(signal.terms[0]?.comparisonStatus).toBe("基準不足");
  });

  it("classifies demand signals from relative prior-period change and relative rank, while using counts only as quality gates", () => {
    expect(classifyDemandStrength({ count: 2, supportCount: 1, relativeChangePercent: 80, relativeRank: 1, comparableTermCount: 3 })).toBe("強");
    expect(classifyDemandStrength({ count: 2, supportCount: 1, relativeChangePercent: 10, relativeRank: 2, comparableTermCount: 3 })).toBe("中");
    expect(classifyDemandStrength({ count: 2, supportCount: 1, relativeChangePercent: -10, relativeRank: 3, comparableTermCount: 3 })).toBe("弱");
  });

  it("uses current-versus-prior normalized term share and relative rank for demand strength", () => {
    const signal = selectDemandEarlySignal([
      { language: "中文", articleCount: 8, terms: [{ term: "機票", count: 9, size: 32 }, { term: "住宿", count: 5, size: 20 }] },
      { language: "英文", articleCount: 0, terms: [] },
    ], [
      { ...stories[0], title: "機票價格上升" },
      { ...stories[1], title: "機票需求增加" },
    ], {
      currentKeywordClouds: [{ language: "中文", articleCount: 4, terms: [{ term: "機票", count: 4, size: 32 }, { term: "住宿", count: 1, size: 16 }] }, { language: "英文", articleCount: 0, terms: [] }],
      priorKeywordClouds: [{ language: "中文", articleCount: 4, terms: [{ term: "機票", count: 1, size: 16 }, { term: "住宿", count: 2, size: 24 }] }, { language: "英文", articleCount: 0, terms: [] }],
    });
    expect(signal.terms[0]).toMatchObject({ term: "機票", baselineCount: 1, relativeChangePercent: 300, relativeRank: 1, comparisonStatus: "可比較", strength: "強" });
  });

  it("applies the same relative comparison to aviation-capacity pressure and source-market signals", () => {
    const keywordClouds = [{ language: "中文" as const, articleCount: 8, terms: [{ term: "延誤", count: 8, size: 32 }, { term: "取消", count: 5, size: 20 }, { term: "日本", count: 7, size: 28 }, { term: "韓國", count: 5, size: 20 }] }];
    const comparison = {
      currentKeywordClouds: [{ language: "中文" as const, articleCount: 4, terms: [{ term: "延誤", count: 4, size: 32 }, { term: "取消", count: 2, size: 20 }, { term: "日本", count: 4, size: 28 }, { term: "韓國", count: 2, size: 20 }] }],
      priorKeywordClouds: [{ language: "中文" as const, articleCount: 4, terms: [{ term: "延誤", count: 1, size: 16 }, { term: "取消", count: 4, size: 28 }, { term: "日本", count: 1, size: 16 }, { term: "韓國", count: 4, size: 28 }] }],
    };
    const supportStories = [{ ...stories[0], title: "航班延誤造成機場壅塞" }, { ...stories[1], title: "日本市場推廣帶動來台旅客" }];

    expect(selectCapacityPressureSignal(keywordClouds, supportStories, comparison).terms[0]).toMatchObject({ term: "延誤", relativeChangePercent: 300, relativeRank: 1, strength: "強" });
    expect(selectSourceMarketSignal(keywordClouds, supportStories, comparison).terms[0]).toMatchObject({ term: "日本", relativeChangePercent: 300, relativeRank: 1, strength: "強" });
  });

  it("keeps capacity and source-market signals at medium or weak when their relative comparison does not support a strong result", () => {
    const capacityMedium = selectCapacityPressureSignal([
      { language: "中文", articleCount: 8, terms: [{ term: "取消", count: 6, size: 30 }, { term: "延誤", count: 4, size: 20 }] },
    ], [{ ...stories[0], title: "航空公司取消航班" }, { ...stories[1], title: "航班延誤消息" }], {
      currentKeywordClouds: [{ language: "中文", articleCount: 4, terms: [{ term: "取消", count: 2, size: 20 }, { term: "延誤", count: 1, size: 16 }] }],
      priorKeywordClouds: [{ language: "中文", articleCount: 4, terms: [{ term: "取消", count: 2, size: 20 }, { term: "延誤", count: 2, size: 20 }] }],
    });
    expect(capacityMedium.terms[0]).toMatchObject({ term: "取消", relativeChangePercent: 0, relativeRank: 1, strength: "中" });
    expect(capacityMedium.level).toBe("中");

    const capacityBaselineInsufficient = selectCapacityPressureSignal([
      { language: "中文", articleCount: 4, terms: [{ term: "延誤", count: 4, size: 24 }] },
    ], [{ ...stories[0], title: "航班延誤影響機場作業" }], {
      currentKeywordClouds: [{ language: "中文", articleCount: 4, terms: [{ term: "延誤", count: 2, size: 20 }] }],
      priorKeywordClouds: [{ language: "中文", articleCount: 4, terms: [] }],
    });
    expect(capacityBaselineInsufficient.terms[0]).toMatchObject({ term: "延誤", comparisonStatus: "基準不足", strength: "弱" });
    expect(capacityBaselineInsufficient.level).toBe("弱");

    const sourceMarketBaselineInsufficient = selectSourceMarketSignal([
      { language: "中文", articleCount: 4, terms: [{ term: "泰國", count: 4, size: 24 }] },
    ], [{ ...stories[0], title: "泰國客源市場推廣" }], {
      currentKeywordClouds: [{ language: "中文", articleCount: 4, terms: [{ term: "泰國", count: 2, size: 20 }] }],
      priorKeywordClouds: [{ language: "中文", articleCount: 4, terms: [] }],
    });
    expect(sourceMarketBaselineInsufficient.terms[0]).toMatchObject({ term: "泰國", comparisonStatus: "基準不足", strength: "弱" });
    expect(sourceMarketBaselineInsufficient.level).toBe("弱");

    const sourceMarketMedium = selectSourceMarketSignal([
      { language: "中文", articleCount: 8, terms: [{ term: "韓國", count: 6, size: 30 }, { term: "日本", count: 4, size: 20 }] },
    ], [{ ...stories[0], title: "韓國客源市場推廣" }, { ...stories[1], title: "日本來台旅客活動" }], {
      currentKeywordClouds: [{ language: "中文", articleCount: 4, terms: [{ term: "韓國", count: 2, size: 20 }, { term: "日本", count: 1, size: 16 }] }],
      priorKeywordClouds: [{ language: "中文", articleCount: 4, terms: [{ term: "韓國", count: 2, size: 20 }, { term: "日本", count: 2, size: 20 }] }],
    });
    expect(sourceMarketMedium.terms[0]).toMatchObject({ term: "韓國", relativeChangePercent: 0, relativeRank: 1, strength: "中" });
    expect(sourceMarketMedium.level).toBe("中");
  });

  it("limits the newsroom to demand-support stories and restores all stories when the term clears", () => {
    const demandStories = [
      { ...stories[0], title: "機票價格帶動出境需求" },
      { ...stories[1], title: "一般旅宿市場訊號" },
    ];
    const activeResult = selectFilteredStories({ visibleStories: demandStories, activeRegion: "全部", activeCategory: "全部", activeSource: "全部來源", query: "機票", activeDemandTerm: "機票", signalIds: new Set() });
    const clearedResult = selectFilteredStories({ visibleStories: demandStories, activeRegion: "全部", activeCategory: "全部", activeSource: "全部來源", query: "", activeDemandTerm: "", signalIds: new Set() });
    expect(activeResult.map((story) => story.id)).toEqual([1]);
    expect(clearedResult.map((story) => story.id)).toEqual([1, 2]);
  });

  it("retains only recent fallback stories while preserving current live stories", () => {
    const result = selectVisibleStories([stories[0]], [stories[1]], new Date("2026-08-21T00:00:00Z"));
    expect(result.map((story) => story.id)).toEqual([1, 2]);
  });
});
