import { countNewsFacets } from "@shared/newsCounts";
import { buildNewsKeywordClouds, type NewsKeywordCloud } from "@shared/newsKeywordCloud";
import { mergeNewsByIdentity } from "@shared/newsMerge";
import { isGovernmentTourismServiceDisruption, rankTourismSignals } from "@shared/tourismSignals";
import { isIndustryMediaSource, isYahooTaiwanFunSource, matchesNewsSourceFilter } from "@shared/yahooTaiwanSources";
import { CATEGORY_LABELS, inferCategory, parseStoryDate, REGION_LABELS, TOPIC_LABELS } from "../dashboardHelpers";
import { type Category, type Region, SIGNAL_CATEGORY, type Story } from "../types";

export function selectVisibleStories(liveStories: Story[], fallbackStories: Story[], now = new Date()) {
  const fallbackCutoff = new Date(now.getTime() - 14 * 24 * 60 * 60 * 1000);
  const fallbackRecentStories = fallbackStories
    .filter((story) => parseStoryDate(story.date) >= fallbackCutoff)
    .map((story) => ({ ...story, category: inferCategory(story.title, story.summary, story.source) }));
  return mergeNewsByIdentity(liveStories, fallbackRecentStories)
    .sort((a, b) => parseStoryDate(b.date).getTime() - parseStoryDate(a.date).getTime());
}

export function selectKeywordClouds(liveStories: Story[], englishTerms?: string[]) {
  return buildNewsKeywordClouds(liveStories, 80).map((cloud) => {
    if (cloud.language === "英文") {
      return { ...cloud, terms: englishTerms ? cloud.terms.filter((term) => englishTerms.includes(term.term)) : cloud.terms.slice(0, 18) };
    }
    return { ...cloud, terms: cloud.terms.slice(0, 30) };
  });
}

export type DemandSignalStrength = "強" | "中" | "弱";
export type DemandComparisonStatus = "可比較" | "基準不足";

export type DemandWindowComparison = {
  currentKeywordClouds: NewsKeywordCloud[];
  priorKeywordClouds: NewsKeywordCloud[];
};

export type DemandEarlySignal = {
  observationPeriod: string;
  sourceLabel: string;
  articleCount: number;
  level: DemandSignalStrength;
  levelDefinition: string;
  terms: Array<{
    term: string;
    count: number;
    language: "中文" | "英文";
    supportCount: number;
    strength: DemandSignalStrength;
    baselineCount: number | null;
    relativeChangePercent: number | null;
    relativeRank: number | null;
    comparableTermCount: number;
    comparisonStatus: DemandComparisonStatus;
  }>;
};

export type MarketEarlySignal = DemandEarlySignal;

const DEMAND_TERM_PATTERN = /機票|航空|航班|住宿|飯店|訂房|行程|出境|國旅|客源|旅客|景點|票價|假期|目的地|旅行社|旅宿|美食|賞花|自由行|airline|flight|hotel|booking|demand|destination|visitor|passenger|fare|holiday|vacation/i;
const CAPACITY_PRESSURE_TERM_PATTERN = /航空|航班|機場|航線|座位|班次|機隊|飛航|載客|延誤|取消|停飛|停航|故障|壅塞|擁塞|超賣|缺工|罷工|客滿|滿載|客座率|運能不足|座位不足|航班減班|減班|縮減|運能|airline|flight|airport|route|seat|fleet|aviation|passenger capacity|delay|delayed|cancel(?:led|ed|lation)?|disruption|suspend(?:ed|sion)?|grounded|shortage|congestion|overbook(?:ed|ing)|load factor|capacity constraint|seat shortage/i;
const SOURCE_MARKET_TERM_PATTERN = /日本|韓國|泰國|香港|澳洲|紐西蘭|加拿大|新加坡|越南|菲律賓|馬來西亞|印尼|美國|歐洲|國際旅客|入境旅客|外國旅客|海外旅客|客源市場|來台旅客|市場推廣|市場開發|旅展|踩線|分眾|鎖定|目標客群|japan|korea|thailand|hong kong|australia|new zealand|canada|singapore|vietnam|philippines|malaysia|indonesia|inbound|international visitor|source market|campaign|targeted|familiarization/i;
const DEMAND_LEVEL_DEFINITIONS: Record<DemandSignalStrength, string> = {
  強: "強：相較前一期明顯增加（至少 +50%），且位於可比較需求詞前 1/3。",
  中: "中：相較前一期未減弱，且位於可比較需求詞前 2/3。",
  弱: "弱：基準不足、相對變化偏弱或未達相對排序門檻，僅作持續觀察。",
};

const CAPACITY_LEVEL_DEFINITIONS: Record<DemandSignalStrength, string> = {
  強: "強：航空運能壓力詞相較前一期明顯增加，且位於可比較詞前 1/3。",
  中: "中：航空運能壓力詞相較前一期未減弱，且位於可比較詞前 2/3。",
  弱: "弱：基準不足、相對變化偏弱或未達排序門檻，僅作持續觀察。",
};

const SOURCE_MARKET_LEVEL_DEFINITIONS: Record<DemandSignalStrength, string> = {
  強: "強：海外客源市場詞相較前一期明顯增加，且位於可比較詞前 1/3。",
  中: "中：海外客源市場詞相較前一期未減弱，且位於可比較詞前 2/3。",
  弱: "弱：基準不足、相對變化偏弱或未達排序門檻，僅作持續觀察。",
};

export function classifyDemandStrength(input: { count: number; supportCount: number; relativeChangePercent: number | null; relativeRank: number | null; comparableTermCount: number }): DemandSignalStrength {
  const { count, supportCount, relativeChangePercent, relativeRank, comparableTermCount } = input;
  if (count < 2 || supportCount < 1 || relativeChangePercent === null || relativeRank === null || comparableTermCount < 1) return "弱";
  if (relativeChangePercent >= 50 && relativeRank <= Math.ceil(comparableTermCount / 3)) return "強";
  if (relativeChangePercent >= 0 && relativeRank <= Math.ceil((comparableTermCount * 2) / 3)) return "中";
  return "弱";
}

export function isDemandSupportStory(story: Story, term: string) {
  const haystack = `${story.title} ${story.summary} ${story.source} ${story.scope}`.toLocaleLowerCase();
  return haystack.includes(term.toLocaleLowerCase());
}

function findCloudTermCount(keywordClouds: NewsKeywordCloud[], language: "中文" | "英文", term: string) {
  return keywordClouds.find((cloud) => cloud.language === language)?.terms.find((item) => item.term === term)?.count ?? 0;
}

type RelativeSignalConfig = {
  termPattern: RegExp;
  levelDefinitions: Record<DemandSignalStrength, string>;
};

function selectRelativeNewsSignal(keywordClouds: NewsKeywordCloud[], supportStories: Story[] = [], comparison: DemandWindowComparison | undefined, config: RelativeSignalConfig): MarketEarlySignal {
  const terms = keywordClouds
    .flatMap((cloud) => cloud.terms.map((term) => ({ ...term, language: cloud.language })))
    .filter((term) => config.termPattern.test(term.term))
    .sort((a, b) => b.count - a.count || a.term.localeCompare(b.term, "zh-Hant"))
    .slice(0, 3);
  const currentArticleCount = comparison?.currentKeywordClouds.reduce((total, cloud) => total + cloud.articleCount, 0) ?? 0;
  const priorArticleCount = comparison?.priorKeywordClouds.reduce((total, cloud) => total + cloud.articleCount, 0) ?? 0;
  const rawTerms = terms.map((term) => ({
    ...term,
    supportCount: supportStories.filter((story) => isDemandSupportStory(story, term.term)).length,
    baselineCount: comparison && priorArticleCount > 0 ? findCloudTermCount(comparison.priorKeywordClouds, term.language, term.term) : null,
    currentWindowCount: comparison && currentArticleCount > 0 ? findCloudTermCount(comparison.currentKeywordClouds, term.language, term.term) : 0,
  }));
  const comparableTerms = rawTerms
    .filter((term) => term.count >= 2 && term.supportCount >= 1 && term.baselineCount !== null && term.baselineCount > 0 && currentArticleCount > 0 && priorArticleCount > 0)
    .map((term) => ({ ...term, relativeChangePercent: Math.round((((term.currentWindowCount / currentArticleCount) / ((term.baselineCount as number) / priorArticleCount)) - 1) * 100) }))
    .sort((a, b) => b.relativeChangePercent - a.relativeChangePercent || b.count - a.count);
  const rankByTerm = new Map(comparableTerms.map((term, index) => [`${term.language}:${term.term}`, { rank: index + 1, relativeChangePercent: term.relativeChangePercent }]));
  const signalTerms = rawTerms.map((term) => {
    const comparisonResult = rankByTerm.get(`${term.language}:${term.term}`);
    const comparableTermCount = comparableTerms.length;
    const relativeRank = comparisonResult?.rank ?? null;
    const relativeChangePercent = comparisonResult?.relativeChangePercent ?? null;
    return {
    ...term,
      baselineCount: term.baselineCount,
      relativeChangePercent,
      relativeRank,
      comparableTermCount,
      comparisonStatus: relativeChangePercent === null ? "基準不足" as const : "可比較" as const,
      strength: classifyDemandStrength({ count: term.count, supportCount: term.supportCount, relativeChangePercent, relativeRank, comparableTermCount }),
    };
  });
  const level = signalTerms.some((term) => term.strength === "強") ? "強" : signalTerms.some((term) => term.strength === "中") ? "中" : "弱";
  return {
    observationPeriod: "最近 14 天",
    sourceLabel: "新聞文字雲高頻詞",
    articleCount: keywordClouds.reduce((total, cloud) => total + cloud.articleCount, 0),
    level,
    levelDefinition: config.levelDefinitions[level],
    terms: signalTerms,
  };
}

export function selectDemandEarlySignal(keywordClouds: NewsKeywordCloud[], supportStories: Story[] = [], comparison?: DemandWindowComparison): DemandEarlySignal {
  return selectRelativeNewsSignal(keywordClouds, supportStories, comparison, { termPattern: DEMAND_TERM_PATTERN, levelDefinitions: DEMAND_LEVEL_DEFINITIONS });
}

export function selectCapacityPressureSignal(keywordClouds: NewsKeywordCloud[], supportStories: Story[] = [], comparison?: DemandWindowComparison): MarketEarlySignal {
  return selectRelativeNewsSignal(keywordClouds, supportStories, comparison, { termPattern: CAPACITY_PRESSURE_TERM_PATTERN, levelDefinitions: CAPACITY_LEVEL_DEFINITIONS });
}

export function selectSourceMarketSignal(keywordClouds: NewsKeywordCloud[], supportStories: Story[] = [], comparison?: DemandWindowComparison): MarketEarlySignal {
  return selectRelativeNewsSignal(keywordClouds, supportStories, comparison, { termPattern: SOURCE_MARKET_TERM_PATTERN, levelDefinitions: SOURCE_MARKET_LEVEL_DEFINITIONS });
}

export function selectDashboardMetrics(visibleStories: Story[]) {
  const facetCounts = countNewsFacets(visibleStories);
  const tourismSignals = rankTourismSignals(visibleStories);
  const signalIds = new Set(tourismSignals.map((signal) => signal.id));
  return {
    tourismSignals,
    tourismServiceAlerts: visibleStories.filter((story) => isGovernmentTourismServiceDisruption(story)).slice(0, 2),
    signalIds,
    regions: REGION_LABELS.map((label) => ({ label, count: label === "全部" ? visibleStories.length : facetCounts.regions[label] ?? 0 })),
    categories: CATEGORY_LABELS.map((label) => ({ label, count: label === "全部" ? visibleStories.length : label === SIGNAL_CATEGORY ? tourismSignals.length : facetCounts.categories[label] ?? 0 })),
    topics: TOPIC_LABELS.map((label) => ({ label, count: facetCounts.topics[label] ?? 0 })),
    bbcTravelCount: visibleStories.filter((story) => story.source === "BBC Travel").length,
    yahooTravelCount: visibleStories.filter((story) => story.source === "Yahoo Travel").length,
    yahooTaiwanFunCount: visibleStories.filter((story) => isYahooTaiwanFunSource(story.source)).length,
    industryMediaCount: visibleStories.filter((story) => isIndustryMediaSource(story.source)).length,
  };
}

export function selectFilteredStories({ visibleStories, activeRegion, activeCategory, activeSource, query, signalIds, activeDemandTerm = "" }: {
  visibleStories: Story[];
  activeRegion: Region;
  activeCategory: Category;
  activeSource: string;
  query: string;
  signalIds: Set<number>;
  activeDemandTerm?: string;
}) {
  const normalized = query.trim().toLowerCase();
  return visibleStories.filter((story) => {
    const matchesRegion = activeRegion === "全部" || story.region === activeRegion;
    const matchesCategory = activeCategory === SIGNAL_CATEGORY ? signalIds.has(story.id) : activeCategory === "全部" || story.category === activeCategory;
    const matchesSource = matchesNewsSourceFilter(story.source, activeSource);
    const matchesDemandSupport = !activeDemandTerm || isDemandSupportStory(story, activeDemandTerm);
    const haystack = `${story.title} ${story.summary} ${story.insight} ${story.source} ${story.scope}`.toLowerCase();
    return matchesRegion && matchesCategory && matchesSource && matchesDemandSupport && (!normalized || haystack.includes(normalized));
  });
}
