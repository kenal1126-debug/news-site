import type { NewsCategory } from "@shared/newsClassification";
import type { TourismTopic } from "@shared/tourismTopics";

export type Region = "全部" | "國內" | "國際";
export const SIGNAL_CATEGORY = "10大觀光產業訊號" as const;
export type Category = "全部" | NewsCategory | typeof SIGNAL_CATEGORY;

export type Story = {
  id: number;
  region: Exclude<Region, "全部">;
  category: Exclude<Category, "全部">;
  date: string;
  source: string;
  title: string;
  summary: string;
  insight: string;
  scope: string;
  image?: string;
  url: string;
  publishedAt?: Date;
  impact?: string;
  strategy?: string;
  topics?: TourismTopic[];
};
