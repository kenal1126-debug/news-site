import { useEffect, useMemo, useState } from "react";
import { trpc } from "@/lib/trpc";
import { buildNewsAnalysis } from "@shared/newsAnalysis";
import { buildNewsKeywordClouds, type NewsKeywordCloudItem } from "@shared/newsKeywordCloud";
import { normalizeHtmlText } from "@shared/textNormalization";
import { getTourismTopics, isTourismRelated } from "@shared/tourismTopics";
import { INDUSTRY_MEDIA_FILTER, YAHOO_TAIWAN_FUN_FILTER } from "@shared/yahooTaiwanSources";
import { DEFAULT_NEWS_IMAGE, formatIssueRange, formatNextNewsUpdate, inferCategory, inferRegion, mapKeywordCloudSync, normalizeNewsSource, resolveInitialSourceFilter, resolveInitialSourceFilterOpen } from "../dashboardHelpers";
import { selectCapacityPressureSignal, selectDashboardMetrics, selectDemandEarlySignal, selectFilteredStories, selectKeywordClouds, selectSourceMarketSignal, selectVisibleStories } from "../selectors/dashboardSelectors";
import { type Category, type Region, SIGNAL_CATEGORY, type Story } from "../types";

export function useTourismNewsDashboard(fallbackStories: Story[]) {
  const [query, setQuery] = useState("");
  const [activeRegion, setActiveRegion] = useState<Region>("全部");
  const [activeCategory, setActiveCategory] = useState<Category>("全部");
  const [activeSource, setActiveSource] = useState<string>(resolveInitialSourceFilter);
  const [showSourceFilter, setShowSourceFilter] = useState(resolveInitialSourceFilterOpen);
  const [mobileNav, setMobileNav] = useState(false);
  const [saved, setSaved] = useState<number[]>([]);
  const [activeDemandTerm, setActiveDemandTerm] = useState("");
  const [today] = useState(() => new Date());
  const { data: recentNews } = trpc.news.recent.useQuery();
  const { data: englishKeywordNlp } = trpc.news.englishKeywordTerms.useQuery(undefined, { staleTime: 6 * 60 * 60 * 1000, retry: 1 });
  const { data: demandComparison } = trpc.news.demandComparison.useQuery(undefined, { staleTime: 15 * 60 * 1000, retry: 1 });
  const { data: latestSync } = trpc.news.latestSync.useQuery(undefined, { staleTime: 5 * 60 * 1000, retry: 1 });

  useEffect(() => {
    if (!resolveInitialSourceFilterOpen()) return;
    window.requestAnimationFrame(() => document.getElementById("source-filter-panel")?.scrollIntoView({ behavior: "instant", block: "start" }));
  }, []);

  const liveStories = useMemo<Story[]>(() => (recentNews ?? [])
    .filter((item) => isTourismRelated(`${item.title} ${item.summary ?? ""}`, item.source))
    .map((item) => ({
      id: item.id,
      region: inferRegion(item.title, item.summary ?? "", item.source),
      category: inferCategory(item.title, item.summary ?? "", item.source),
      date: new Intl.DateTimeFormat("en-US", { month: "2-digit", day: "2-digit", year: "numeric" }).format(new Date(item.publishedAt)),
      publishedAt: new Date(item.publishedAt),
      source: normalizeNewsSource(item.source),
      title: normalizeHtmlText(item.title),
      summary: item.summary ? normalizeHtmlText(item.summary) : "由每日同步來源更新的新聞摘要。",
      insight: "此則新聞已納入最近 14 天的自動更新資料。",
      scope: "自動同步／近期新聞",
      topics: getTourismTopics(`${item.title} ${item.summary ?? ""}`),
      image: item.imageUrl || DEFAULT_NEWS_IMAGE,
      url: item.url,
      ...buildNewsAnalysis(item.title, item.summary ?? "", item.source),
    })), [recentNews]);

  const visibleStories = useMemo(() => selectVisibleStories(liveStories, fallbackStories), [fallbackStories, liveStories]);
  const keywordClouds = useMemo(() => selectKeywordClouds(liveStories, englishKeywordNlp?.terms), [englishKeywordNlp?.terms, liveStories]);
  const demandWindowComparison = useMemo(() => {
    if (!demandComparison) return undefined;
    const toKeywordItems = (items: typeof demandComparison.current): NewsKeywordCloudItem[] => items
      .filter((item) => isTourismRelated(`${item.title} ${item.summary ?? ""}`, item.source))
      .map((item) => ({ source: normalizeNewsSource(item.source), title: normalizeHtmlText(item.title), summary: item.summary ? normalizeHtmlText(item.summary) : "" }));
    return {
      currentKeywordClouds: buildNewsKeywordClouds(toKeywordItems(demandComparison.current), 80),
      priorKeywordClouds: buildNewsKeywordClouds(toKeywordItems(demandComparison.prior), 80),
    };
  }, [demandComparison]);
  const demandEarlySignal = useMemo(() => selectDemandEarlySignal(keywordClouds, visibleStories, demandWindowComparison), [demandWindowComparison, keywordClouds, visibleStories]);
  const capacityPressureSignal = useMemo(() => selectCapacityPressureSignal(keywordClouds, visibleStories, demandWindowComparison), [demandWindowComparison, keywordClouds, visibleStories]);
  const sourceMarketSignal = useMemo(() => selectSourceMarketSignal(keywordClouds, visibleStories, demandWindowComparison), [demandWindowComparison, keywordClouds, visibleStories]);
  const metrics = useMemo(() => selectDashboardMetrics(visibleStories), [visibleStories]);
  const filteredStories = useMemo(() => selectFilteredStories({ visibleStories, activeRegion, activeCategory, activeSource, query, signalIds: metrics.signalIds, activeDemandTerm }), [activeCategory, activeDemandTerm, activeRegion, activeSource, metrics.signalIds, query, visibleStories]);

  const toggleSaved = (id: number) => setSaved((current) => current.includes(id) ? current.filter((item) => item !== id) : [...current, id]);

  return {
    query, setQuery, activeDemandTerm, setActiveDemandTerm, activeRegion, setActiveRegion, activeCategory, setActiveCategory, activeSource, setActiveSource, showSourceFilter, setShowSourceFilter, mobileNav, setMobileNav, saved, toggleSaved,
    todayLabel: new Intl.DateTimeFormat("en-US", { month: "2-digit", day: "2-digit", year: "numeric" }).format(today), newsNextUpdateLabel: formatNextNewsUpdate(today),
    issueRangeLabel: formatIssueRange(today), liveStories, visibleStories, keywordClouds, demandEarlySignal, capacityPressureSignal, sourceMarketSignal, keywordCloudSync: mapKeywordCloudSync(latestSync), ...metrics, filteredStories,
    yahooTaiwanFunFilter: YAHOO_TAIWAN_FUN_FILTER,
    industryMediaFilter: INDUSTRY_MEDIA_FILTER,
  };
}
