import React from "react";

export type DashboardPageView = "news" | "macro" | "international";

const PAGE_OPTIONS: Array<{ id: DashboardPageView; label: string; description: string }> = [
  { id: "news", label: "本週新聞", description: "最新10篇與分類篩選" },
  { id: "macro", label: "總體經濟趨勢", description: "六國經濟與官方旅次" },
  { id: "international", label: "國際市場洞察", description: "五國旅客研究判讀" },
];

type DashboardPageSwitcherProps = {
  activeView: DashboardPageView;
  onViewChange: (view: DashboardPageView) => void;
};

export function DashboardPageSwitcher({ activeView, onViewChange }: DashboardPageSwitcherProps) {
  return <nav className="dashboard-page-switcher" aria-label="內容頁切換">
    <div className="dashboard-page-switcher-copy"><span>READING DESK</span><strong>選擇閱讀頁面</strong></div>
    <div className="dashboard-page-switcher-options">{PAGE_OPTIONS.map((option) => <button key={option.id} type="button" className={activeView === option.id ? "is-active" : ""} aria-pressed={activeView === option.id} onClick={() => onViewChange(option.id)}><strong>{option.label}</strong><small>{option.description}</small></button>)}</div>
  </nav>;
}
