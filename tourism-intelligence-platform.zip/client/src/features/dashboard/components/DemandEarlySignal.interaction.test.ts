// @vitest-environment jsdom
import { createElement, useMemo, useState } from "react";
import { cleanup, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, describe, expect, it } from "vitest";
import { selectFilteredStories } from "../selectors/dashboardSelectors";
import type { Story } from "../types";
import { EditorialHero } from "./EditorialHero";
import { Newsroom } from "./Newsroom";

const demandSupportStory: Story = { id: 1, region: "國際", category: "航空運能", date: "08/25/2026", source: "旅報", title: "機票價格帶動出境需求", summary: "旅客持續比較機票。", insight: "需求訊號", scope: "台灣", url: "https://example.com/flight" };
const capacitySupportStory: Story = { id: 2, region: "國際", category: "航空運能", date: "08/25/2026", source: "旅報", title: "航班延誤造成機場壅塞", summary: "航空公司調整航班。", insight: "運能訊號", scope: "台灣", url: "https://example.com/delay" };
const sourceMarketSupportStory: Story = { id: 3, region: "國內", category: "台灣觀光", date: "08/25/2026", source: "旅奇週刊", title: "日本市場推廣帶動來台旅客", summary: "針對日本客源市場。", insight: "客源訊號", scope: "台灣", url: "https://example.com/japan" };
const otherStory: Story = { id: 4, region: "國內", category: "台灣觀光", date: "08/25/2026", source: "旅奇週刊", title: "地方活動帶動旅遊", summary: "地方活動資訊。", insight: "地方訊號", scope: "台灣", url: "https://example.com/local" };

function DemandSignalHomeHarness() {
  const [activeDemandTerm, setActiveDemandTerm] = useState("");
  const [query, setQuery] = useState("");
  const stories = [demandSupportStory, capacitySupportStory, sourceMarketSupportStory, otherStory];
  const filteredStories = useMemo(() => selectFilteredStories({ visibleStories: stories, activeRegion: "全部", activeCategory: "全部", activeSource: "全部來源", query, activeDemandTerm, signalIds: new Set() }), [activeDemandTerm, query]);
  const clearOrSetQuery = (nextQuery: string) => {
    setQuery(nextQuery);
    if (!nextQuery) setActiveDemandTerm("");
  };
  return createElement("div", {},
    createElement(EditorialHero, {
      todayLabel: "08/25/2026",
      visibleStoryCount: stories.length,
      onOpenNavigation: () => undefined,
      onDemandTermSelect: (term) => { setActiveDemandTerm(term); setQuery(term); },
      demandEarlySignal: { observationPeriod: "最近 14 天", sourceLabel: "新聞文字雲高頻詞", articleCount: 2, level: "中", levelDefinition: "中：相較前一期未減弱，且位於可比較需求詞前 2/3。", terms: [{ term: "機票", count: 8, language: "中文", supportCount: 1, strength: "中", baselineCount: 4, relativeChangePercent: 20, relativeRank: 1, comparableTermCount: 2, comparisonStatus: "可比較" }] },
      capacityPressureSignal: { observationPeriod: "最近 14 天", sourceLabel: "新聞文字雲高頻詞", articleCount: 2, level: "強", levelDefinition: "", terms: [{ term: "延誤", count: 5, language: "中文", supportCount: 1, strength: "強", baselineCount: 1, relativeChangePercent: 100, relativeRank: 1, comparableTermCount: 2, comparisonStatus: "可比較" }] },
      sourceMarketSignal: { observationPeriod: "最近 14 天", sourceLabel: "新聞文字雲高頻詞", articleCount: 2, level: "強", levelDefinition: "", terms: [{ term: "日本", count: 5, language: "中文", supportCount: 1, strength: "強", baselineCount: 1, relativeChangePercent: 100, relativeRank: 1, comparableTermCount: 2, comparisonStatus: "可比較" }] },
    }),
    createElement(Newsroom, {
      activeRegion: "全部", activeCategory: "全部", activeSource: "全部來源", query, showSourceFilter: false,
      visibleStories: stories, filteredStories, tourismSignalCount: 0, bbcTravelCount: 0, yahooTravelCount: 0,
      yahooTaiwanFunCount: 0, yahooTaiwanFunFilter: "Yahoo 台灣玩樂", industryMediaCount: 0, industryMediaFilter: "產業媒體",
      sourceOptions: ["全部來源"], saved: [], storyAnalysis: {},
      onQueryChange: clearOrSetQuery, onToggleSourceFilter: () => undefined, onSourceChange: () => undefined,
      onCategoryChange: () => undefined, onRegionChange: () => undefined, onToggleSaved: () => undefined,
    }),
  );
}

afterEach(() => cleanup());

describe("market signal homepage integration", () => {
  it("filters the actual Newsroom to each supporting signal and restores the list with its search-clear control", async () => {
    const user = userEvent.setup();
    render(createElement(DemandSignalHomeHarness));
    expect(screen.getByText("機票價格帶動出境需求")).toBeTruthy();
    expect(screen.getByText("航班延誤造成機場壅塞")).toBeTruthy();
    expect(screen.getByText("日本市場推廣帶動來台旅客")).toBeTruthy();
    expect(screen.getByText("地方活動帶動旅遊")).toBeTruthy();
    await user.click(screen.getByRole("button", { name: /機票：文字雲詞頻/ }));
    expect(screen.getByText("機票價格帶動出境需求")).toBeTruthy();
    expect(screen.queryByText("地方活動帶動旅遊")).toBeNull();
    await user.click(screen.getByRole("button", { name: "清除搜尋" }));
    expect(screen.getByText("地方活動帶動旅遊")).toBeTruthy();
    await user.click(screen.getByRole("button", { name: /運能／延誤：文字雲詞頻/ }));
    expect(screen.getByText("航班延誤造成機場壅塞")).toBeTruthy();
    expect(screen.queryByText("機票價格帶動出境需求")).toBeNull();
    await user.click(screen.getByRole("button", { name: "清除搜尋" }));
    await user.click(screen.getByRole("button", { name: /客源／日本：文字雲詞頻/ }));
    expect(screen.getByText("日本市場推廣帶動來台旅客")).toBeTruthy();
    expect(screen.queryByText("地方活動帶動旅遊")).toBeNull();
    await user.click(screen.getByRole("button", { name: "清除搜尋" }));
    expect(screen.getByText("地方活動帶動旅遊")).toBeTruthy();
  });
});
