import { createElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it, vi } from "vitest";

const useQuery = vi.hoisted(() => vi.fn());
vi.mock("@/lib/trpc", () => ({
  trpc: { internationalIndicators: { latest: { useQuery } } },
}));

import { MacroTrendSection } from "./MacroTrendSection";

const observations = [
  ["JPN", "inbound_arrivals", "3,148,600", "2026-06-30", "https://statistics.jnto.go.jp/en/graph/"], ["JPN", "population", "123,802,000", "2024-10-01", "https://www.stat.go.jp/english/data/jinsui/2024np/index.html"],
  ["KOR", "inbound_arrivals", "10,709,919", "2026-06-30", "https://www.mcst.go.kr/english/policy/pressView.jsp?pSeq=658"], ["KOR", "population", "51,817,499", "2025-12-31", "https://kosis.kr/statHtml/statHtml.do?tblId=DT_1IN1502"],
  ["CAN", "inbound_arrivals", "811,000", "2026-06-30", "https://www150.statcan.gc.ca/n1/daily-quotidien/260820/dq260820b-eng.htm"], ["CAN", "population", "41,417,056", "2026-04-01", "https://www150.statcan.gc.ca/n1/daily-quotidien/260617/dq260617a-eng.htm"],
  ["AUS", "inbound_arrivals", "566,910", "2026-06-30", "https://www.abs.gov.au/statistics/industry/tourism-and-transport/overseas-arrivals-and-departures-australia/latest-release"], ["AUS", "population", "27,801,023", "2025-12-31", "https://www.abs.gov.au/statistics/people/population/national-state-and-territory-population/latest-release"],
  ["NZL", "inbound_arrivals", "203,300", "2026-05-31", "https://www.stats.govt.nz/information-releases/international-travel-may-2026/"], ["NZL", "population", "5,344,500", "2025-12-31", "https://www.stats.govt.nz/topics/population/"],
  ["THA", "inbound_arrivals", "1,841,550", "2026-06-30", "https://app.bot.or.th/BTWS_STAT/statistics/ReportPage.aspx?reportID=875&language=eng"], ["THA", "population", "70,300,000", "2025-12-31", "https://www.nso.go.th/nsoweb/main/summano/aE?set_lang=en"],
].map(([countryCode, indicatorCode, value, referenceDate, sourceUrl]) => ({ countryCode, indicatorCode, value: value.replace(/,/g, ""), referenceDate, sourceUrl, unit: indicatorCode === "population" ? "人" : "旅次", note: "官方已核實觀測" }));

describe("MacroTrendSection", () => {
  it("renders the latest arrival, population, period, and official source for all six countries", () => {
    useQuery.mockReturnValue({ data: observations });
    const markup = renderToStaticMarkup(createElement(MacroTrendSection));
    for (const observation of observations) {
      expect(markup).toContain(new Intl.NumberFormat("zh-TW", { maximumFractionDigits: 0 }).format(Number(observation.value)));
      expect(markup).toContain(observation.sourceUrl.replace(/&/g, "&amp;"));
      expect(markup).toContain(new Intl.DateTimeFormat("zh-TW", { year: "numeric", month: "2-digit", day: "2-digit", timeZone: "UTC" }).format(new Date(observation.referenceDate)));
    }
    expect((markup.match(/入境統計/g) ?? [])).toHaveLength(6);
    expect((markup.match(/人口統計/g) ?? [])).toHaveLength(6);
  });
});
