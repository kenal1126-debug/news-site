import React from "react";
import { ArrowUpRight } from "lucide-react";
import type { TourismSignal } from "@shared/tourismSignals";

export function TourismSignalsPanel({ tourismSignals }: { tourismSignals: TourismSignal[] }) {
  return <section className="tourism-signals" id="tourism-signals" aria-label="10大觀光產業訊號"><div className="tourism-signals-grid">{tourismSignals.length === 0 ? <div className="signal-empty">目前沒有達到 60 分門檻的訊號。</div> : tourismSignals.map((signal, index) => <article className="tourism-signal-card" key={`signal-${signal.id}`}><div className="tourism-signal-top"><span className="tourism-signal-number">{String(index + 1).padStart(2, "0")}</span><span className="tourism-signal-score">{signal.score.total} / 100</span></div><div className="tourism-signal-meta">{signal.category} · {signal.source} · {signal.date}</div><h3>{signal.title}</h3><p>{signal.summary}</p><div className="tourism-signal-breakdown" aria-label="評分構成"><span>影響 {signal.score.impact}</span><span>可信 {signal.score.credibility}</span><span>時效 {signal.score.timeliness}</span><span>跨國 {signal.score.crossBorder}</span><span>台灣 {signal.score.taiwanRelevance}</span><span>多樣 {signal.score.diversity}</span></div><a href={signal.url} target="_blank" rel="noreferrer">查看原文 <ArrowUpRight size={14} /></a></article>)}</div></section>;
}
