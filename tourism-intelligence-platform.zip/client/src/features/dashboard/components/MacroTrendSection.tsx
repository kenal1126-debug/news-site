import React from "react";
import { ExternalLink } from "lucide-react";
import { macroTrends } from "@shared/macroTrends";
import { trpc } from "@/lib/trpc";

const COUNTRY_CODES: Record<string, string> = {
  日本: "JPN",
  韓國: "KOR",
  加拿大: "CAN",
  澳洲: "AUS",
  紐西蘭: "NZL",
  泰國: "THA",
};

function formatIndicatorValue(value: string | null, unit: string | null) {
  if (!value) return "待官方資料";
  const numeric = Number(value);
  if (!Number.isFinite(numeric)) return "待官方資料";
  return `${new Intl.NumberFormat("zh-TW", { maximumFractionDigits: 0 }).format(numeric)}${unit === "人" ? " 人" : " 旅次"}`;
}

function formatReferenceDate(value: Date | string | null) {
  if (!value) return "尚待公布期別";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "尚待公布期別";
  return new Intl.DateTimeFormat("zh-TW", { year: "numeric", month: "2-digit", day: "2-digit", timeZone: "UTC" }).format(date);
}

export function MacroTrendSection() {
  const { data: indicators = [] } = trpc.internationalIndicators.latest.useQuery(undefined, { staleTime: 15 * 60 * 1000 });

  return (
    <section className="macro-section" id="macro-trends" aria-labelledby="macro-trends-title">
      <div className="macro-heading"><div><div className="eyebrow">MACRO PULSE / GDP + CPI + FX + ARRIVALS</div><h2 id="macro-trends-title">總體經濟趨勢 <span>／ SIX MARKET PULSES</span></h2></div><p>以各國最新已發布 GDP、CPI、匯率及官方入境旅次／人口估計為基準。旅次與人口的統計期別不同，均保留各自的來源、基準日與定義。</p></div>
      <div className="macro-grid">{macroTrends.map((trend) => {
        const countryCode = COUNTRY_CODES[trend.country];
        const arrivals = indicators.find(item => item.countryCode === countryCode && item.indicatorCode === "inbound_arrivals");
        const population = indicators.find(item => item.countryCode === countryCode && item.indicatorCode === "population");
        return <article className="macro-card" key={trend.country}>
          <div className="macro-card-header"><span className="macro-country">{trend.country}</span><span className="macro-quarter">{trend.quarter}</span></div>
          <div className="macro-stat-row"><div className="macro-stat"><span className="macro-stat-label">REAL GDP</span><strong>{trend.gdp}</strong><small>{trend.gdpNote}</small></div><div className="macro-stat"><span className="macro-stat-label">CPI</span><strong>{trend.cpi}</strong><small>{trend.cpiNote}</small></div><div className="macro-stat"><span className="macro-stat-label">FX / TWD</span><strong>{trend.fx}</strong><small>{trend.fxNote}</small></div></div>
          <div className="macro-tourism-context" aria-label={`${trend.country}官方入境旅次與人口資料`}>
            <div><span>INBOUND / LATEST</span><strong>{formatIndicatorValue(arrivals?.value ?? null, arrivals?.unit ?? null)}</strong><small>{arrivals ? `${formatReferenceDate(arrivals.referenceDate)}・${arrivals.note ?? arrivals.definition}` : "來源已建檔，等待官方可驗證數值。"}</small>{arrivals?.sourceUrl && <a href={arrivals.sourceUrl} target="_blank" rel="noreferrer">入境統計 <ExternalLink size={11} /></a>}</div>
            <div><span>POPULATION</span><strong>{formatIndicatorValue(population?.value ?? null, population?.unit ?? null)}</strong><small>{population ? `${formatReferenceDate(population.referenceDate)}・${population.note ?? population.definition}` : "來源已建檔，等待官方可驗證數值。"}</small>{population?.sourceUrl && <a href={population.sourceUrl} target="_blank" rel="noreferrer">人口統計 <ExternalLink size={11} /></a>}</div>
          </div>
          <div className="macro-reading"><span>觀光產業判讀</span><p>{trend.reading}</p></div>
          <div className="macro-links"><a href={trend.url} target="_blank" rel="noreferrer">GDP 官方來源 <ExternalLink size={13} /></a><a href={trend.cpiUrl} target="_blank" rel="noreferrer">CPI 官方來源 <ExternalLink size={13} /></a><a href={trend.fxUrl} target="_blank" rel="noreferrer">匯率查核 <ExternalLink size={13} /></a></div>
        </article>;
      })}</div>
    </section>
  );
}
