import { buildNewsKeywordClouds, getNewsKeywordCloudLayout, getNewsKeywordHeatColor } from "@shared/newsKeywordCloud";

type KeywordCloud = ReturnType<typeof buildNewsKeywordClouds>[number];

export function KeywordCloudSection({ keywordClouds }: { keywordClouds: KeywordCloud[] }) {
  return (
    <section className="keyword-cloud-section" aria-labelledby="keyword-cloud-title">
      <div className="keyword-cloud-heading"><div><div className="eyebrow">NEWS PULSE / DATABASE WORD CLOUD</div><h2 id="keyword-cloud-title">新聞關鍵詞雲 <span>／ 中文 + ENGLISH</span></h2></div><p>以最近 14 天資料庫新聞的標題與摘要統計；中文與英文網站各自分組，字級依實際出現頻率呈現。</p></div>
      <div className="keyword-cloud-grid">
        {keywordClouds.map((cloud) => <article className={`keyword-cloud-card ${cloud.language === "英文" ? "is-english" : "is-chinese"}`} key={cloud.language}>
          <div className="keyword-cloud-card-heading"><span>{cloud.language === "中文" ? "中文新聞關鍵詞" : "ENGLISH NEWS KEYWORDS"}</span><strong>{cloud.articleCount} STORIES</strong></div>
          {cloud.terms.length > 0 ? <div className="keyword-cloud-terms is-cloud" aria-label={`${cloud.language}新聞高頻關鍵詞`}>{cloud.terms.slice(0, 30).map((term, index) => { const layout = getNewsKeywordCloudLayout(index); const densityClass = index >= 24 ? "is-edge" : index >= 16 ? "is-orbit" : ""; const highestCount = cloud.terms[0]?.count ?? term.count; const lowestCount = cloud.terms.at(-1)?.count ?? term.count; return <span className={`keyword-cloud-term ${index === 0 ? "is-core" : ""} ${densityClass}`} key={term.term} style={{ color: getNewsKeywordHeatColor(term.count, highestCount, lowestCount), fontSize: `${term.size}px`, left: `${layout.left}%`, top: `${layout.top}%`, zIndex: index === 0 ? 4 : index < 16 ? 3 : index < 24 ? 2 : 1, transform: `translate(-50%, -50%) rotate(${layout.rotate}deg)` }} title={`出現 ${term.count} 次`}>{term.term}</span>; })}</div> : <p className="keyword-cloud-empty">尚無可統計的近期新聞文字。</p>}
          <div className="keyword-cloud-footnote"><span>標題權重為摘要的 3 倍 · 已排除媒體名稱{cloud.language === "英文" && " · NLP 詞性篩選"}</span><span className="keyword-cloud-heat-legend"><i>低</i><b aria-hidden="true" /><i>高</i></span></div>
        </article>)}
      </div>
    </section>
  );
}
