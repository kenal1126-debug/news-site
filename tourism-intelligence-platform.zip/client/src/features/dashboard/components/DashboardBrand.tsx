import React from "react";

export function DashboardBrand() {
  return (
    <div className="brand-lockup">
      <img src="/manus-storage/tti-logo-02_a23c43b3.png" alt="觀．戰情 TTI 標誌" className="brand-mark" />
      <div>
        <div className="brand-name">觀光趨勢</div>
        <div className="brand-subtitle">TOURISM ATLAS / WEEKLY INTELLIGENCE</div>
      </div>
    </div>
  );
}
