// @vitest-environment jsdom
import { createElement, useMemo, useState } from "react";
import { cleanup, render, screen, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, describe, expect, it } from "vitest";
import { selectFilteredStories } from "../selectors/dashboardSelectors";
import type { Story } from "../types";
import { Newsroom } from "./Newsroom";

const tvbsStory: Story = { id: 101, region: "國內", category: "台灣觀光", date: "08/20/2026", source: "TVBS新聞網", title: "TVBS 國旅服務訊號", summary: "旅客暫時無法申請。", insight: "服務異常", scope: "台灣", url: "https://example.com/tvbs" };
const ettodayStory: Story = { id: 102, region: "國內", category: "台灣觀光", date: "08/20/2026", source: "ETtoday旅遊雲", title: "ETtoday 旅遊市場訊號", summary: "旅宿需求增加。", insight: "市場訊號", scope: "台灣", url: "https://example.com/ettoday" };
const industryStory: Story = { id: 103, region: "國內", category: "台灣觀光", date: "08/20/2026", source: "旅報", title: "旅報產業市場訊號", summary: "旅宿需求增加。", insight: "市場訊號", scope: "台灣", url: "https://example.com/ttn" };

function NewsroomHarness({ stories }: { stories: Story[] }) {
  const [activeSource, setActiveSource] = useState("全部來源");
  const [showSourceFilter, setShowSourceFilter] = useState(false);
  const [query, setQuery] = useState("");
  const filteredStories = useMemo(() => selectFilteredStories({ visibleStories: stories, activeRegion: "全部", activeCategory: "全部", activeSource, query, signalIds: new Set() }), [activeSource, query, stories]);
  return createElement(Newsroom, {
    activeRegion: "全部",
    activeCategory: "全部",
    activeSource,
    query,
    showSourceFilter,
    visibleStories: stories,
    filteredStories,
    tourismSignalCount: 0,
    bbcTravelCount: 0,
    yahooTravelCount: 0,
    yahooTaiwanFunCount: 0,
    yahooTaiwanFunFilter: "Yahoo 台灣玩樂",
    industryMediaCount: stories.filter((story) => story.source === "旅報").length,
    industryMediaFilter: "產業媒體",
    sourceOptions: ["全部來源", "TVBS新聞網", "ETtoday"],
    saved: [],
    storyAnalysis: {},
    onQueryChange: setQuery,
    onToggleSourceFilter: () => setShowSourceFilter((current) => !current),
    onSourceChange: setActiveSource,
    onCategoryChange: () => undefined,
    onRegionChange: () => undefined,
    onToggleSaved: () => undefined,
  });
}

afterEach(() => cleanup());

describe("Newsroom source-filter interaction", () => {
  it("opens the panel, selects a source, closes it, and immediately renders matching stories", async () => {
    const user = userEvent.setup();
    render(createElement(NewsroomHarness, { stories: [tvbsStory, ettodayStory] }));
    await user.click(screen.getByRole("button", { name: /來源篩選/ }));
    const panel = screen.getByLabelText("新聞來源篩選");
    await user.click(within(panel).getByRole("button", { name: "ETtoday" }));
    expect(screen.queryByLabelText("新聞來源篩選")).toBeNull();
    expect(screen.getByText("ETtoday 旅遊市場訊號")).toBeTruthy();
    expect(screen.queryByText("TVBS 國旅服務訊號")).toBeNull();
  });

  it("shows the empty state after an actual source selection has no matching stories", async () => {
    const user = userEvent.setup();
    render(createElement(NewsroomHarness, { stories: [tvbsStory] }));
    await user.click(screen.getByRole("button", { name: /來源篩選/ }));
    await user.click(within(screen.getByLabelText("新聞來源篩選")).getByRole("button", { name: "ETtoday" }));
    expect(screen.queryByLabelText("新聞來源篩選")).toBeNull();
    expect(screen.getByText("沒有找到這組訊號")).toBeTruthy();
  });

  it("toggles the industry-media quick filter and renders only industry stories", async () => {
    const user = userEvent.setup();
    render(createElement(NewsroomHarness, { stories: [tvbsStory, industryStory] }));
    await user.click(screen.getByRole("button", { name: "產業媒體 1" }));
    expect(screen.getByText("旅報產業市場訊號")).toBeTruthy();
    expect(screen.queryByText("TVBS 國旅服務訊號")).toBeNull();
    await user.click(screen.getByRole("button", { name: "產業媒體 1" }));
    expect(screen.getByText("TVBS 國旅服務訊號")).toBeTruthy();
    expect(screen.getByText("旅報產業市場訊號")).toBeTruthy();
  });

  it("shows ten newest stories per page and resets to page one when the search changes", async () => {
    const user = userEvent.setup();
    const paginationStories: Story[] = Array.from({ length: 12 }, (_, index) => ({
      id: 200 + index,
      region: "國內",
      category: "台灣觀光",
      date: "08/20/2026",
      source: "TVBS新聞網",
      title: `分頁新聞 ${String(index + 1).padStart(2, "0")}`,
      summary: "分頁驗證資料。",
      insight: "分頁訊號",
      scope: "台灣",
      url: `https://example.com/page-${index + 1}`,
    }));
    render(createElement(NewsroomHarness, { stories: paginationStories }));
    expect(screen.getByText("分頁新聞 01")).toBeTruthy();
    expect(screen.getByText("分頁新聞 10")).toBeTruthy();
    expect(screen.queryByText("分頁新聞 11")).toBeNull();
    await user.click(screen.getByRole("button", { name: "第 2 頁" }));
    expect(screen.getByText("分頁新聞 11")).toBeTruthy();
    expect(screen.queryByText("分頁新聞 01")).toBeNull();
    await user.type(screen.getByLabelText("搜尋新聞"), "12");
    expect(screen.getByText("分頁新聞 12")).toBeTruthy();
    expect(screen.queryByRole("button", { name: "第 2 頁" })).toBeNull();
  });
});
