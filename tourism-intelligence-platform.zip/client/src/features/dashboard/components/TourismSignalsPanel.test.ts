import { createElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it } from "vitest";
import type { TourismSignal } from "@shared/tourismSignals";
import { TourismSignalsPanel } from "./TourismSignalsPanel";

const signal: TourismSignal = {
  id: 801,
  title: "台灣觀光服務異常影響國旅補助申請",
  summary: "服務中斷影響旅客申請流程。",
  source: "TVBS新聞網",
  date: "08/20/2026",
  url: "https://news.tvbs.com.tw/life/4010102",
  category: "台灣觀光",
  region: "國內",
  scope: "台灣",
  score: { impact: 30, credibility: 14, timeliness: 15, crossBorder: 0, taiwanRelevance: 10, diversity: 10, total: 79 },
};

describe("TourismSignalsPanel", () => {
  it("renders the ranked signal and all score fields", () => {
    const markup = renderToStaticMarkup(createElement(TourismSignalsPanel, { tourismSignals: [signal] }));
    expect(markup).toContain("79 / 100");
    expect(markup).toContain("影響 30");
    expect(markup).toContain("可信 14");
    expect(markup).toContain("多樣 10");
  });

  it("renders the threshold empty state when no signal qualifies", () => {
    expect(renderToStaticMarkup(createElement(TourismSignalsPanel, { tourismSignals: [] }))).toContain("目前沒有達到 60 分門檻的訊號。");
  });
});
