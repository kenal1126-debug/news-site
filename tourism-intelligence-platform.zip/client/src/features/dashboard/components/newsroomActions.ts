export function selectNewsroomSource(source: string, onSourceChange: (value: string) => void, onCloseSourceFilter: () => void) {
  onSourceChange(source);
  onCloseSourceFilter();
}
