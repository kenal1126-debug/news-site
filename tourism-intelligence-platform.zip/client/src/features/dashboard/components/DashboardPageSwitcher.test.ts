// @vitest-environment jsdom
import { createElement, useState } from "react";
import { cleanup, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, describe, expect, it } from "vitest";
import { DashboardPageSwitcher, type DashboardPageView } from "./DashboardPageSwitcher";

afterEach(() => cleanup());

function SwitcherHarness() {
  const [activeView, setActiveView] = useState<DashboardPageView>("news");
  return createElement(DashboardPageSwitcher, { activeView, onViewChange: setActiveView });
}

describe("DashboardPageSwitcher", () => {
  it("exposes a dedicated total-economy page choice and updates the active view", async () => {
    const user = userEvent.setup();
    render(createElement(SwitcherHarness));
    const macroButton = screen.getByRole("button", { name: /總體經濟趨勢/ });
    expect(macroButton.getAttribute("aria-pressed")).toBe("false");
    await user.click(macroButton);
    expect(macroButton.getAttribute("aria-pressed")).toBe("true");
    expect(screen.getByRole("button", { name: /本週新聞/ }).getAttribute("aria-pressed")).toBe("false");
  });
});
