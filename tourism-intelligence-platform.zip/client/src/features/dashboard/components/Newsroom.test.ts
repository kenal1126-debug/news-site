import { createElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it } from "vitest";
import { Newsroom } from "./Newsroom";
import { selectNewsroomSource } from "./newsroomActions";
import { selectFilteredStories } from "../selectors/dashboardSelectors";

const story = {
  id: 101,
  region: "國內" as const,
  category: "台灣觀光" as const,
  date: "08/20/2026",
  source: "TVBS新聞網",
  title: "國旅補助申請官網首日當掉",
  summary: "旅客暫時無法申請。",
  insight: "服務異常訊號",
  scope: "台灣",
  url: "https://news.tvbs.com.tw/life/4010102",
};

function renderNewsroom(overrides: Partial<Parameters<typeof Newsroom>[0]> = {}) {
  return renderToStaticMarkup(createElement(Newsroom, {
    activeRegion: "全部",
    activeCategory: "全部",
    activeSource: "全部來源",
    query: "",
    showSourceFilter: false,
    visibleStories: [story],
    filteredStories: [story],
    tourismSignalCount: 0,
    bbcTravelCount: 0,
    yahooTravelCount: 0,
    yahooTaiwanFunCount: 0,
    yahooTaiwanFunFilter: "Yahoo 台灣玩樂",
    sourceOptions: ["全部來源", "TVBS新聞網", "ETtoday"],
    saved: [],
    storyAnalysis: {},
    onQueryChange: () => undefined,
    onToggleSourceFilter: () => undefined,
    onSourceChange: () => undefined,
    onCategoryChange: () => undefined,
    onRegionChange: () => undefined,
    onToggleSaved: () => undefined,
    ...overrides,
  }));
}

describe("Newsroom", () => {
  it("renders indexed stories and the source-filter controls", () => {
    const markup = renderNewsroom({ showSourceFilter: true, activeSource: "TVBS新聞網" });
    expect(markup).toContain("國旅補助申請官網首日當掉");
    expect(markup).toContain("TVBS新聞網");
    expect(markup).toContain("ETtoday");
    expect(markup).toContain("查看原文");
  });

  it("renders the empty state for a source or query with no matching result", () => {
    const markup = renderNewsroom({ activeSource: "ETtoday", query: "不存在", filteredStories: [] });
    expect(markup).toContain("沒有找到這組訊號");
    expect(markup).toContain("換一個關鍵字");
  });

  it("switches the source through the Newsroom action and closes the filter panel", () => {
    const selected: string[] = [];
    let closed = 0;
    selectNewsroomSource("ETtoday", (source) => selected.push(source), () => { closed += 1; });
    expect(selected).toEqual(["ETtoday"]);
    expect(closed).toBe(1);
  });

  it("rerenders the matching result after source selection and closes the source panel", () => {
    let activeSource = "全部來源";
    let showSourceFilter = true;
    selectNewsroomSource("TVBS新聞網", (source) => { activeSource = source; }, () => { showSourceFilter = false; });
    const filteredStories = selectFilteredStories({
      visibleStories: [story],
      activeRegion: "全部",
      activeCategory: "全部",
      activeSource,
      query: "",
      signalIds: new Set(),
    });
    const markup = renderNewsroom({ activeSource, showSourceFilter, filteredStories });
    expect(markup).toContain("國旅補助申請官網首日當掉");
    expect(markup).not.toContain('id="source-filter-panel"');
  });
});
