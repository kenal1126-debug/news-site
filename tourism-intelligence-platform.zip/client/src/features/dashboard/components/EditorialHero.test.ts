// @vitest-environment jsdom
import { createElement } from "react";
import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";
import { EditorialHero } from "./EditorialHero";

afterEach(() => cleanup());

describe("EditorialHero market signals", () => {
  it("renders traceable comparison details for demand, capacity, and source-market signals", () => {
    const onDemandTermSelect = vi.fn();
    render(createElement(EditorialHero, {
      todayLabel: "08/25/2026",
      newsNextUpdateLabel: "今日 20:00（台灣時間）",
      visibleStoryCount: 12,
      onOpenNavigation: () => undefined,
      onDemandTermSelect,
      demandEarlySignal: { observationPeriod: "最近 14 天", sourceLabel: "新聞文字雲高頻詞", articleCount: 12, level: "強", levelDefinition: "強：相較前一期明顯增加（至少 +50%），且位於可比較需求詞前 1/3。", terms: [{ term: "機票", count: 8, language: "中文", supportCount: 3, strength: "強", baselineCount: 2, relativeChangePercent: 75, relativeRank: 1, comparableTermCount: 3, comparisonStatus: "可比較" }] },
      capacityPressureSignal: { observationPeriod: "最近 14 天", sourceLabel: "新聞文字雲高頻詞", articleCount: 12, level: "強", levelDefinition: "", terms: [{ term: "延誤", count: 5, language: "中文", supportCount: 2, strength: "強", baselineCount: 1, relativeChangePercent: 100, relativeRank: 1, comparableTermCount: 2, comparisonStatus: "可比較" }] },
      sourceMarketSignal: { observationPeriod: "最近 14 天", sourceLabel: "新聞文字雲高頻詞", articleCount: 12, level: "強", levelDefinition: "", terms: [{ term: "日本", count: 5, language: "中文", supportCount: 2, strength: "強", baselineCount: 1, relativeChangePercent: 100, relativeRank: 1, comparableTermCount: 2, comparisonStatus: "可比較" }] },
      keywordCloudSync: { batchId: "sync-run-20260830-001", completedAt: "2026-08-30T02:00:00.000Z", status: "success" },
    }));
    expect(screen.getByLabelText(/需求強：文字雲驅動/)).toBeTruthy();
    expect(screen.getByText("吃緊")).toBeTruthy();
    expect(screen.getByText("擴張")).toBeTruthy();
    expect(screen.queryByText(/相較前一期明顯增加/)).toBeNull();
    expect(screen.getByText("8×／3則")).toBeTruthy();
    expect(screen.getByText("+75%／相對第 1/3")).toBeTruthy();
    expect(screen.getAllByText("強", { selector: "i" })).toHaveLength(3);
    expect(screen.getAllByText("5×／2則")).toHaveLength(2);
    expect(screen.getAllByText("+100%／相對第 1/2")).toHaveLength(2);
    expect(screen.getByText("強度計算說明", { selector: "strong" })).toBeTruthy();
    expect(screen.getByText(/文字雲批次：sync-run/)).toBeTruthy();
    expect(screen.getByText(/08\/30 10:00/)).toBeTruthy();
    expect(screen.getByTitle("完整同步批次編號：sync-run-20260830-001")).toBeTruthy();
    expect(screen.getByText(/比較兩段期間（T−6～T 與 T−13～T−7；T 為今日）各詞出現的比例/)).toBeTruthy();
    expect(screen.getByText(/強＝\+50%以上且前1\/3，中＝未減且前2\/3/)).toBeTruthy();
    expect(screen.getByText("下次新聞更新：今日 20:00（台灣時間）")).toBeTruthy();
    expect(screen.queryByText(/共用分級/)).toBeNull();
    expect(screen.queryByText(/標準化詞頻占比/)).toBeNull();
    expect(screen.queryByText(/國內新聞看地方/)).toBeNull();
    fireEvent.click(screen.getByRole("button", { name: /機票：文字雲詞頻 8，支撐新聞 3 則/ }));
    fireEvent.click(screen.getByRole("button", { name: /運能／延誤：文字雲詞頻 5，支撐新聞 2 則/ }));
    fireEvent.click(screen.getByRole("button", { name: /客源／日本：文字雲詞頻 5，支撐新聞 2 則/ }));
    expect(onDemandTermSelect).toHaveBeenCalledWith("機票");
    expect(onDemandTermSelect).toHaveBeenCalledWith("延誤");
    expect(onDemandTermSelect).toHaveBeenCalledWith("日本");
  });

  it("uses the selected contextual weak labels when the clouds lack comparable terms", () => {
    render(createElement(EditorialHero, {
      todayLabel: "08/25/2026",
      newsNextUpdateLabel: "明日 11:00（台灣時間）",
      visibleStoryCount: 0,
      onOpenNavigation: () => undefined,
      onDemandTermSelect: () => undefined,
      demandEarlySignal: { observationPeriod: "最近 14 天", sourceLabel: "新聞文字雲高頻詞", articleCount: 0, level: "弱", levelDefinition: "弱：基準不足、相對變化偏弱或未達相對排序門檻，僅作持續觀察。", terms: [] },
    }));
    expect(screen.getByLabelText(/需求弱：文字雲驅動/)).toBeTruthy();
    expect(screen.getByText("緩和")).toBeTruthy();
    expect(screen.getByText("轉弱")).toBeTruthy();
  });
});
