import { ExternalLink, Menu, Sparkles } from "lucide-react";
import React, { type ReactNode } from "react";
import type { DemandEarlySignal, MarketEarlySignal } from "../selectors/dashboardSelectors";
import { DashboardBrand } from "./DashboardBrand";

type EditorialHeroProps = {
  todayLabel: string;
  newsNextUpdateLabel: string;
  visibleStoryCount: number;
  onOpenNavigation: () => void;
  alertSlot?: ReactNode;
  demandEarlySignal: DemandEarlySignal;
  capacityPressureSignal?: MarketEarlySignal;
  sourceMarketSignal?: MarketEarlySignal;
  onDemandTermSelect: (term: string) => void;
  keywordCloudSync?: { batchId: string; completedAt: Date | string | null; status: string } | null;
};

type MarketSignalItemProps = {
  label: string;
  signal: MarketEarlySignal;
  levelLabels: Record<"強" | "中" | "弱", string>;
  onTermSelect: (term: string) => void;
};

function SignalTermDetails({ label, signal, onTermSelect }: { label: string; signal: MarketEarlySignal; onTermSelect: (term: string) => void }) {
  return signal.terms.length > 0 && <div className="signal-detail-terms">{signal.terms.map((term) => <button key={`${label}-${term.language}-${term.term}`} type="button" onClick={() => onTermSelect(term.term)} aria-label={`${label}／${term.term}：文字雲詞頻 ${term.count}，支撐新聞 ${term.supportCount} 則，${term.comparisonStatus === "可比較" ? `較前一期 ${term.relativeChangePercent}%、相對第 ${term.relativeRank}/${term.comparableTermCount}` : "基準不足"}，強度 ${term.strength}`} title="查看支撐新聞"><span>{term.term}</span><b>{`${term.count}×／${term.supportCount}則`}</b><em>{term.comparisonStatus === "可比較" ? `${(term.relativeChangePercent ?? 0) >= 0 ? "+" : ""}${term.relativeChangePercent ?? 0}%／相對第 ${term.relativeRank}/${term.comparableTermCount}` : "基準不足"}</em><i>{term.strength}</i></button>)}</div>;
}

function MarketSignalItem({ label, signal, levelLabels, onTermSelect }: MarketSignalItemProps) {
  const displayLevel = levelLabels[signal.level];
  return <div className="signal-item signal-market" aria-label={`${label}${displayLevel}：最近14天新聞文字雲的非官方相對比較訊號`}>
    <div className="signal-label"><strong>{label}</strong><span>{displayLevel}</span></div>
    <SignalTermDetails label={label} signal={signal} onTermSelect={onTermSelect} />
  </div>;
}

function DemandSignalItem({ signal, onTermSelect }: { signal: DemandEarlySignal; onTermSelect: (term: string) => void }) {
  return <div className="signal-item signal-demand" aria-label={`需求${signal.level}：文字雲驅動的旅客需求早期訊號`}>
    <div className="signal-label"><strong>需求</strong><span>{signal.level}</span></div>
    <SignalTermDetails label="需求" signal={signal} onTermSelect={onTermSelect} />
  </div>;
}

const DEMAND_LEVEL_LABELS = { 強: "強", 中: "中", 弱: "弱" };
const CAPACITY_LEVEL_LABELS = { 強: "吃緊", 中: "持平", 弱: "緩和" };
const SOURCE_MARKET_LEVEL_LABELS = { 強: "擴張", 中: "持平", 弱: "轉弱" };

export function EditorialHero({ todayLabel, newsNextUpdateLabel, visibleStoryCount, onOpenNavigation, alertSlot, demandEarlySignal, capacityPressureSignal, sourceMarketSignal, keywordCloudSync, onDemandTermSelect }: EditorialHeroProps) {
  const emptySignal = { ...demandEarlySignal, level: "弱" as const, terms: [] };
  return <>
    <header className="topbar">
      <div className="mobile-brand"><DashboardBrand /></div>
      <div className="topbar-kicker"><span className="topbar-line" />本週觀光產業情報</div>
      <div className="topbar-actions">
        <button className="icon-button" aria-label="開啟索引" onClick={onOpenNavigation}><Menu size={20} /></button>
        <a className="source-button" href="https://www.aol.com/articles/airbnb-posts-higher-quarterly-revenue-214410000.html" target="_blank" rel="noreferrer">原始來源 <ExternalLink size={14} /></a>
      </div>
    </header>
    {alertSlot}
    <section className="hero-grid">
      <div className="hero-copy">
        <div className="hero-brand"><img src="/manus-storage/tti-logo-02_a23c43b3.png" alt="" /><span style={{ width: "60px", height: "158px", display: "flex", alignItems: "center", justifyContent: "center", writingMode: "vertical-rl", textOrientation: "upright", letterSpacing: "0.16em", lineHeight: 1.1 }}>觀光趨勢</span><i>·</i><small>TOURISM ATLAS</small></div>
        <div className="eyebrow"><span className="eyebrow-dot" /> DAILY FIELD NOTE / {todayLabel}</div>
        <h1>觀光週報</h1>
        <p className="hero-description">從分散的旅遊新聞裡，辨識需求、航網與目的地正在發生的變化。</p>
        <div className="hero-meta-row"><span>{visibleStoryCount} 則近期訊號</span><span className="meta-separator" /><span>最近 14 天</span><span className="meta-separator" /><span>可追溯來源</span></div>
      </div>
      <div className="hero-visual">
        <img src="/manus-storage/atlas-hero-map_10be6641.jpg" alt="紙張地圖、航空航線與羅盤的編輯桌面" />
        <div className="hero-caption"><span>01</span><span>GLOBAL TOURISM SIGNALS</span><span>↗</span></div>
        <div className="hero-stamp">ATLAS<br /><span>FIELD<br />NOTE</span></div>
      </div>
    </section>
    <section className="signal-strip" aria-label="本期觀察摘要">
      <div className="signal-heading"><Sparkles size={17} /> 本期訊號</div>
      <DemandSignalItem signal={demandEarlySignal} onTermSelect={onDemandTermSelect} />
      <MarketSignalItem label="運能" signal={capacityPressureSignal ?? emptySignal} levelLabels={CAPACITY_LEVEL_LABELS} onTermSelect={onDemandTermSelect} />
      <MarketSignalItem label="客源" signal={sourceMarketSignal ?? emptySignal} levelLabels={SOURCE_MARKET_LEVEL_LABELS} onTermSelect={onDemandTermSelect} />
      <div className="signal-note signal-method-note"><strong>強度計算說明</strong><span>比較兩段期間（T−6～T 與 T−13～T−7；T 為今日）各詞出現的比例：強＝+50%以上且前1/3，中＝未減且前2/3，其餘或基準不足＝弱。詞頻與支撐新聞數僅作資料品質門檻。</span><small>下次新聞更新：{newsNextUpdateLabel}</small>{keywordCloudSync ? <small title={`完整同步批次編號：${keywordCloudSync.batchId}`}>文字雲批次：{keywordCloudSync.batchId.slice(0, 8)}… · {keywordCloudSync.completedAt ? new Intl.DateTimeFormat("zh-TW", { timeZone: "Asia/Taipei", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hourCycle: "h23" }).format(new Date(keywordCloudSync.completedAt)) : "完成時間待同步"}（{keywordCloudSync.status === "partial" ? "部分完成" : "完成"}）</small> : <small>文字雲批次：尚未取得</small>}
</div>
    </section>
  </>;
}
