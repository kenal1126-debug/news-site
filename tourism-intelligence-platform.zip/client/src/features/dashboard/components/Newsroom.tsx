import React, { useEffect, useMemo, useState } from "react";
import { ArrowUpRight, Bookmark, ChevronDown, Compass, Globe2, Search, SlidersHorizontal, X } from "lucide-react";
import { buildNewsAnalysis } from "@shared/newsAnalysis";
import { DEFAULT_NEWS_IMAGE, displayCategoryLabel } from "../dashboardHelpers";
import { type Category, type Region, SIGNAL_CATEGORY, type Story } from "../types";
import { selectNewsroomSource } from "./newsroomActions";

type StoryAnalysis = Record<number, { impact: string; strategy: string }>;

const NEWS_PAGE_SIZE = 10;

function buildPaginationEntries(totalPages: number, currentPage: number): Array<number | "ellipsis"> {
  if (totalPages <= 7) return Array.from({ length: totalPages }, (_, index) => index + 1);
  const pages = new Set([1, totalPages, currentPage - 1, currentPage, currentPage + 1].filter((page) => page >= 1 && page <= totalPages));
  const sortedPages = Array.from(pages).sort((a, b) => a - b);
  const entries: Array<number | "ellipsis"> = [];
  sortedPages.forEach((page, index) => {
    if (index > 0 && page - sortedPages[index - 1] > 1) entries.push("ellipsis");
    entries.push(page);
  });
  return entries;
}

type NewsroomProps = {
  activeRegion: Region;
  activeCategory: Category;
  activeSource: string;
  query: string;
  showSourceFilter: boolean;
  visibleStories: Story[];
  filteredStories: Story[];
  tourismSignalCount: number;
  bbcTravelCount: number;
  yahooTravelCount: number;
  yahooTaiwanFunCount: number;
  yahooTaiwanFunFilter: string;
  industryMediaCount: number;
  industryMediaFilter: string;
  sourceOptions: readonly string[];
  saved: number[];
  storyAnalysis: StoryAnalysis;
  onQueryChange: (value: string) => void;
  onToggleSourceFilter: () => void;
  onSourceChange: (source: string) => void;
  onCategoryChange: (category: Category) => void;
  onRegionChange: (region: Region) => void;
  onToggleSaved: (id: number) => void;
};

export function Newsroom({ activeRegion, activeCategory, activeSource, query, showSourceFilter, visibleStories, filteredStories, tourismSignalCount, bbcTravelCount, yahooTravelCount, yahooTaiwanFunCount, yahooTaiwanFunFilter, industryMediaCount, industryMediaFilter, sourceOptions, saved, storyAnalysis, onQueryChange, onToggleSourceFilter, onSourceChange, onCategoryChange, onRegionChange, onToggleSaved }: NewsroomProps) {
  const [currentPage, setCurrentPage] = useState(1);
  const storyCount = activeCategory === SIGNAL_CATEGORY ? tourismSignalCount : filteredStories.length;
  const totalCount = activeCategory === SIGNAL_CATEGORY ? tourismSignalCount : visibleStories.length;
  const totalPages = Math.max(1, Math.ceil(filteredStories.length / NEWS_PAGE_SIZE));
  const displayedPage = Math.min(currentPage, totalPages);
  const paginatedStories = useMemo(() => filteredStories.slice((displayedPage - 1) * NEWS_PAGE_SIZE, displayedPage * NEWS_PAGE_SIZE), [displayedPage, filteredStories]);
  const paginationEntries = useMemo(() => buildPaginationEntries(totalPages, displayedPage), [displayedPage, totalPages]);

  useEffect(() => {
    setCurrentPage(1);
  }, [activeCategory, activeRegion, activeSource, query, filteredStories]);

  return (
    <section className="workspace" id="stories">
      <div className="section-heading"><div><div className="eyebrow">NEWSROOM / {activeRegion === "全部" ? "DOMESTIC + GLOBAL" : activeRegion === "國內" ? "TAIWAN DESK" : "GLOBAL DESK"}</div><h2>{activeCategory === SIGNAL_CATEGORY ? SIGNAL_CATEGORY : activeCategory === "全部" ? "本週情報" : `${displayCategoryLabel(activeCategory)} 本週情報`} <span>／ {storyCount.toString().padStart(2, "0")}</span></h2></div><div className="section-caption">{activeCategory === SIGNAL_CATEGORY ? <>每則摘要都保留原始來源<br />讓判讀回到事件現場。<br /><span>總分 60 分以上才進入訊號候選池。</span></> : <>來源：近 14 天同步新聞<br />依分類規則整理，保留原始來源。</>}</div></div>
      <div className="search-command-surface">
        <div className="search-row"><div className="search-box"><Search size={18} /><input value={query} onChange={(event) => onQueryChange(event.target.value)} placeholder="搜尋關鍵字、目的地、來源…" aria-label="搜尋新聞" />{query && <button aria-label="清除搜尋" onClick={() => onQueryChange("")}><X size={16} /></button>}</div><button className={`filter-button ${showSourceFilter || activeSource !== "全部來源" ? "is-active" : ""}`} onClick={onToggleSourceFilter}><SlidersHorizontal size={16} /> 來源篩選 <ChevronDown size={15} /></button><div className="result-count"><span>{storyCount}</span> / {totalCount} STORIES</div></div>
        <div className="quick-filters"><span>快速索引</span>{["需求", "航線", "旅宿", "台灣", "永續"].map((term) => <button key={term} onClick={() => onQueryChange(term)}>{term}</button>)}{bbcTravelCount > 0 && <button className="source-quick-filter" onClick={() => { onSourceChange("BBC Travel"); onQueryChange(""); }}>{`BBC Travel ${bbcTravelCount}`}</button>}{yahooTravelCount > 0 && <button className="source-quick-filter" onClick={() => { onSourceChange("Yahoo Travel"); onQueryChange(""); }}>{`Yahoo Travel ${yahooTravelCount}`}</button>}{yahooTaiwanFunCount > 0 && <button className={`source-quick-filter ${activeSource === yahooTaiwanFunFilter ? "is-active" : ""}`} aria-pressed={activeSource === yahooTaiwanFunFilter} onClick={() => { const nextSource = activeSource === yahooTaiwanFunFilter ? "全部來源" : yahooTaiwanFunFilter; onSourceChange(nextSource); onCategoryChange("全部"); onRegionChange("全部"); onQueryChange(""); }}>{`${yahooTaiwanFunFilter} ${yahooTaiwanFunCount}`}</button>}{industryMediaCount > 0 && <button className={`source-quick-filter ${activeSource === industryMediaFilter ? "is-active" : ""}`} aria-pressed={activeSource === industryMediaFilter} onClick={() => { const nextSource = activeSource === industryMediaFilter ? "全部來源" : industryMediaFilter; onSourceChange(nextSource); onCategoryChange("全部"); onRegionChange("全部"); onQueryChange(""); }}>{`${industryMediaFilter} ${industryMediaCount}`}</button>}<span className="trust-note">↗ 每日更新 · 僅保留最近 14 天 · 每則報導附原始來源</span></div>
        {showSourceFilter && <div id="source-filter-panel" className="source-filter-panel" aria-label="新聞來源篩選"><span>新聞來源</span>{sourceOptions.map((source) => <button key={source} className={activeSource === source ? "is-active" : ""} onClick={() => selectNewsroomSource(source, onSourceChange, onToggleSourceFilter)}>{source}</button>)}</div>}
      </div>
      {activeCategory !== SIGNAL_CATEGORY && (
        <div className="story-list">
          {filteredStories.length === 0 ? (
            <div className="empty-state"><Compass size={28} /><h3>沒有找到這組訊號</h3><p>換一個關鍵字，或切回「全部」看看。</p></div>
          ) : paginatedStories.map((story, index) => (
            <article className={`story-card ${index === 0 ? "is-featured" : ""}`} key={`${story.source}-${story.id}-${story.url}`}>
              <div className="story-index">{String((displayedPage - 1) * NEWS_PAGE_SIZE + index + 1).padStart(2, "0")}</div>
              <div className="story-image"><img src={story.image || DEFAULT_NEWS_IMAGE} alt="" onError={(event) => { event.currentTarget.onerror = null; event.currentTarget.src = DEFAULT_NEWS_IMAGE; }} /><span className="image-label">FIELD IMAGE</span></div>
              <div className="story-content">
                <div className="story-topline"><span className="story-category">{displayCategoryLabel(story.category)}</span><span>{story.date}</span><span className="story-source">{story.source}</span><span className="source-status">● 已索引</span></div>
                {story.topics && story.topics.length > 0 && <div className="story-topics" aria-label="觀光產業主題">{story.topics.map((topic) => <span key={topic}>{topic}</span>)}</div>}
                <h3>{story.title}</h3><p>{story.summary}</p><div className="story-insight"><span>編輯判讀</span>{story.insight}</div>
                <div className="story-footer"><span className="scope-tag"><Globe2 size={13} /> {story.scope}</span><a href={story.url} target="_blank" rel="noreferrer">查看原文 <ArrowUpRight size={15} /></a></div>
              </div>
              <aside className="story-analysis" aria-label={`${story.title} 的產業分析`}>
                <div><span className="analysis-label">產業影響</span><p>{story.impact ?? storyAnalysis[story.id]?.impact ?? buildNewsAnalysis(story.title, story.summary, story.source).impact}</p></div>
                <div><span className="analysis-label">對應策略</span><p>{story.strategy ?? storyAnalysis[story.id]?.strategy ?? buildNewsAnalysis(story.title, story.summary, story.source).strategy}</p></div>
              </aside>
              <button className={`save-button ${saved.includes(story.id) ? "is-saved" : ""}`} aria-label={saved.includes(story.id) ? "取消收藏" : "收藏新聞"} onClick={() => onToggleSaved(story.id)}><Bookmark size={17} fill={saved.includes(story.id) ? "currentColor" : "none"} /></button>
            </article>
          ))}
        </div>
      )}
      {activeCategory !== SIGNAL_CATEGORY && filteredStories.length > NEWS_PAGE_SIZE && <nav className="news-pagination" aria-label="新聞分頁"><button type="button" onClick={() => setCurrentPage((page) => Math.max(1, page - 1))} disabled={displayedPage === 1}>上一頁</button><div className="news-pagination-pages">{paginationEntries.map((entry, index) => entry === "ellipsis" ? <span key={`ellipsis-${index}`} aria-hidden="true">…</span> : <button key={entry} type="button" className={entry === displayedPage ? "is-active" : ""} aria-label={`第 ${entry} 頁`} aria-current={entry === displayedPage ? "page" : undefined} onClick={() => setCurrentPage(entry)}>{entry}</button>)}</div><span className="news-pagination-status">第 {displayedPage}／{totalPages} 頁・本頁 {paginatedStories.length} 篇</span><button type="button" onClick={() => setCurrentPage((page) => Math.min(totalPages, page + 1))} disabled={displayedPage === totalPages}>下一頁</button></nav>}
    </section>
  );
}
