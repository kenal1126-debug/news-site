import { ArrowUpRight, CalendarDays } from "lucide-react";
import { displayCategoryLabel } from "../dashboardHelpers";
import type { Category, Region } from "../types";
import { DashboardBrand } from "./DashboardBrand";

type CountItem<T extends string> = { label: T; count: number };

type EditorialSidebarProps = {
  mobileNav: boolean;
  regions: CountItem<Region>[];
  categories: CountItem<Category>[];
  topics: CountItem<string>[];
  activeRegion: Region;
  activeCategory: Category;
  issueRangeLabel: string;
  onRegionChange: (region: Region) => void;
  onCategoryChange: (category: Category) => void;
};

export function EditorialSidebar({ mobileNav, regions, categories, topics, activeRegion, activeCategory, issueRangeLabel, onRegionChange, onCategoryChange }: EditorialSidebarProps) {
  return (
    <aside className={`atlas-sidebar ${mobileNav ? "is-open" : ""}`}>
      <div className="sidebar-topline"><span>戰情觀  /  TTI</span><span className="live-dot" /></div>
      <DashboardBrand />
      <div className="sidebar-rule" />
      <div className="sidebar-label">區域 REGION</div>
      <nav className="region-nav" aria-label="國內或國際新聞">
        {regions.map((item) => (
          <button key={item.label} className={`region-item ${activeRegion === item.label ? "is-active" : ""}`} onClick={() => onRegionChange(item.label)}>
            <span>{item.label}</span><span>{item.count}</span>
          </button>
        ))}
      </nav>
      <div className="sidebar-label category-index-label">產業 INDEX</div>
      <nav className="category-nav" aria-label="新聞分類">
        {categories.map((item) => (
          <button key={item.label} className={`category-item ${activeCategory === item.label ? "is-active" : ""}`} onClick={() => onCategoryChange(item.label)}>
            <span className="category-symbol">{activeCategory === item.label ? "✦" : "·"}</span>
            <span>{displayCategoryLabel(item.label)}</span>
            <span className="category-count">{item.count}</span>
          </button>
        ))}
      </nav>
      <div className="sidebar-label topic-index-label">食宿遊購行 TOURISM ACTIVITY</div>
      <nav className="topic-nav" aria-label="食宿遊購行主題">
        {topics.map((item) => <div className="topic-item" key={item.label}><span>{item.label}</span><span>{String(item.count).padStart(2, "0")}</span></div>)}
      </nav>
      <div className="sidebar-bottom">
        <div className="sidebar-label">本期範圍</div>
        <div className="issue-date"><CalendarDays size={15} /> {issueRangeLabel}</div>
        <p>聚焦旅遊需求、航網擴張、旅宿表現與台灣海外客源。</p>
        <a href="#methodology" className="method-link">閱讀編輯方法 <ArrowUpRight size={14} /></a>
      </div>
    </aside>
  );
}
