import { useAuth } from "@/_core/hooks/useAuth";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { AlertTriangle, ArrowLeft, CheckCircle2, Database, RefreshCw, ShieldAlert, WifiOff } from "lucide-react";
import { Link } from "wouter";

function formatDate(value?: Date | null) {
  return value ? new Intl.DateTimeFormat("zh-TW", { dateStyle: "short", timeStyle: "short", hour12: false }).format(value) : "尚無資料";
}

function statusLabel(status?: string | null) {
  if (status === "success") return "成功";
  if (status === "partial") return "部分完成";
  if (status === "failed") return "失敗";
  if (status === "running") return "執行中";
  if (status === "warning") return "注意";
  if (status === "critical") return "嚴重";
  return "未執行";
}

function StatusBadge({ status }: { status?: string | null }) {
  const style = status === "success" ? "bg-emerald-100 text-emerald-800 hover:bg-emerald-100" : status === "failed" || status === "critical" ? "bg-red-100 text-red-800 hover:bg-red-100" : status === "partial" || status === "warning" ? "bg-amber-100 text-amber-800 hover:bg-amber-100" : "bg-slate-100 text-slate-700 hover:bg-slate-100";
  return <Badge className={style}>{statusLabel(status)}</Badge>;
}

export default function Operations() {
  const { user, loading, isAuthenticated } = useAuth();
  const overview = trpc.operations.overview.useQuery(undefined, { enabled: Boolean(isAuthenticated && user?.role === "admin"), refetchInterval: 60_000 });

  if (loading) return <main className="min-h-screen bg-stone-50 p-8 text-stone-600">正在確認權限…</main>;
  if (!isAuthenticated) return <main className="min-h-screen bg-stone-50 p-8 text-stone-600">此頁需要登入後存取。</main>;
  if (user?.role !== "admin") return <main className="min-h-screen bg-stone-50 p-8 text-stone-600">此頁僅限管理者檢視。</main>;

  const data = overview.data;
  const latestRun = data?.latestRuns[0];
  const sourceFailures = data?.sourceHealth.filter(source => source.status === "failed").length ?? 0;

  return (
    <main className="min-h-screen bg-[#f5f2ea] text-[#26231f]">
      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-8">
        <header className="mb-8 flex flex-col gap-5 border-b border-[#d7d0c2] pb-6 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="mb-2 text-xs font-bold tracking-[0.18em] text-[#a34b2d]">觀光趨勢／INTERNAL OPERATIONS</p>
            <h1 className="font-serif text-4xl tracking-tight">資料同步營運室</h1>
            <p className="mt-2 max-w-2xl text-sm leading-6 text-stone-600">唯讀檢視新聞資料管線、旅遊服務警示、洞察快取與國別指標的可追溯狀態。資料以各項原始期別與來源為準，不以即時網頁時間取代統計基準日。</p>
          </div>
          <div className="flex items-center gap-3">
            <Button variant="outline" onClick={() => overview.refetch()} disabled={overview.isFetching} className="border-[#b9b0a0] bg-transparent">
              <RefreshCw className={`mr-2 h-4 w-4 ${overview.isFetching ? "animate-spin" : ""}`} />重新讀取
            </Button>
            <Link href="/" className="inline-flex h-9 items-center rounded-md border border-[#b9b0a0] px-3 text-sm font-medium transition-colors hover:bg-white"><ArrowLeft className="mr-2 h-4 w-4" />回首頁</Link>
          </div>
        </header>

        {overview.error ? <Card className="mb-6 border-red-200 bg-red-50"><CardContent className="flex gap-3 p-5 text-red-800"><ShieldAlert className="h-5 w-5 shrink-0" />無法讀取營運資料：{overview.error.message}</CardContent></Card> : null}

        <section className="mb-8 grid gap-4 md:grid-cols-4">
          <Card className="border-[#ddd5c6] bg-white/80"><CardHeader className="pb-2"><CardDescription>最近同步批次</CardDescription><CardTitle className="flex items-center justify-between text-2xl"><span>{statusLabel(latestRun?.status)}</span><StatusBadge status={latestRun?.status} /></CardTitle></CardHeader><CardContent className="text-sm text-stone-600">{formatDate(latestRun?.startedAt)}</CardContent></Card>
          <Card className="border-[#ddd5c6] bg-white/80"><CardHeader className="pb-2"><CardDescription>來源異常</CardDescription><CardTitle className="text-2xl">{sourceFailures}</CardTitle></CardHeader><CardContent className="flex items-center gap-2 text-sm text-stone-600"><WifiOff className="h-4 w-4" />最近一次可用結果</CardContent></Card>
          <Card className="border-[#ddd5c6] bg-white/80"><CardHeader className="pb-2"><CardDescription>服務警示</CardDescription><CardTitle className="text-2xl">{data?.activeAlerts.length ?? 0}</CardTitle></CardHeader><CardContent className="flex items-center gap-2 text-sm text-stone-600"><AlertTriangle className="h-4 w-4" />目前 active 狀態</CardContent></Card>
          <Card className="border-[#ddd5c6] bg-white/80"><CardHeader className="pb-2"><CardDescription>國別指標觀測值</CardDescription><CardTitle className="text-2xl">{data?.latestIndicatorObservations.filter(item => item.value !== null).length ?? 0}</CardTitle></CardHeader><CardContent className="flex items-center gap-2 text-sm text-stone-600"><Database className="h-4 w-4" />已保存最近可用期別</CardContent></Card>
        </section>

        <section className="mb-8 grid gap-6 xl:grid-cols-[1.35fr_0.65fr]">
          <Card className="border-[#ddd5c6] bg-white/80"><CardHeader><CardTitle>同步批次總帳</CardTitle><CardDescription>每次排程或手動稽核均記錄起訖時間、來源成功率與新聞寫入量。</CardDescription></CardHeader><CardContent className="overflow-x-auto"><table className="w-full min-w-[720px] text-left text-sm"><thead className="border-b border-stone-200 text-xs uppercase tracking-wide text-stone-500"><tr><th className="pb-3 font-medium">時間</th><th className="pb-3 font-medium">觸發</th><th className="pb-3 font-medium">狀態</th><th className="pb-3 text-right font-medium">來源</th><th className="pb-3 text-right font-medium">抓取／寫入</th></tr></thead><tbody>{data?.latestRuns.map(run => <tr key={run.id} className="border-b border-stone-100"><td className="py-3">{formatDate(run.startedAt)}</td><td className="py-3">{run.triggerKind}</td><td className="py-3"><StatusBadge status={run.status} /></td><td className="py-3 text-right tabular-nums">{run.sourceSucceeded}/{run.sourceTotal}</td><td className="py-3 text-right tabular-nums">{run.itemFetched}/{run.itemPersisted}</td></tr>)}</tbody></table>{!data?.latestRuns.length ? <p className="py-8 text-center text-sm text-stone-500">尚無可追溯同步批次；下次同步完成後會自動建立紀錄。</p> : null}</CardContent></Card>
          <Card className="border-[#ddd5c6] bg-white/80"><CardHeader><CardTitle>旅遊服務警示</CardTitle><CardDescription>從最近新聞判讀之政府旅遊服務異常，保留規則版本與最後偵測時間。</CardDescription></CardHeader><CardContent className="space-y-3">{data?.activeAlerts.map(alert => <div key={alert.id} className="rounded-lg border border-stone-200 p-3"><div className="flex items-center justify-between gap-3"><p className="font-medium">{alert.affectedService}</p><StatusBadge status={alert.severity} /></div><p className="mt-1 text-xs text-stone-500">最後偵測：{formatDate(alert.lastDetectedAt)} ・ {alert.ruleVersion}</p></div>)}{!data?.activeAlerts.length ? <div className="flex items-center gap-2 rounded-lg bg-emerald-50 p-4 text-sm text-emerald-800"><CheckCircle2 className="h-4 w-4" />目前沒有持久化的 active 服務警示。</div> : null}</CardContent></Card>
        </section>

        <section className="mb-8 grid gap-6 xl:grid-cols-2">
          <Card className="border-[#ddd5c6] bg-white/80"><CardHeader><CardTitle>來源健康度</CardTitle><CardDescription>使用最新來源執行結果；來源 URL 的當次快照保留在批次紀錄中。</CardDescription></CardHeader><CardContent className="max-h-[430px] overflow-auto"><div className="space-y-2">{data?.sourceHealth.map(source => <div key={source.id} className="flex items-center justify-between gap-4 rounded-lg border border-stone-100 px-3 py-2"><div className="min-w-0"><p className="truncate text-sm font-medium">{source.displayName}</p><p className="truncate text-xs text-stone-500">{source.adapterKind} ・ {formatDate(source.completedAt)}</p></div><div className="shrink-0 text-right"><StatusBadge status={source.status} /><p className="mt-1 text-xs tabular-nums text-stone-500">{source.httpStatus ?? "—"} ・ {source.itemFetched ?? 0} 則</p></div></div>)}{!data?.sourceHealth.length ? <p className="py-8 text-center text-sm text-stone-500">尚未建立來源健康度紀錄。</p> : null}</div></CardContent></Card>
          <Card className="border-[#ddd5c6] bg-white/80"><CardHeader><CardTitle>洞察快取</CardTitle><CardDescription>保存鍵值雜湊、輸入指紋、提示版本與到期時間，不保存原始新聞文字或提示內容。</CardDescription></CardHeader><CardContent className="max-h-[430px] overflow-auto"><div className="space-y-2">{data?.cacheEntries.map((entry, index) => <div key={`${entry.cacheNamespace}-${index}`} className="rounded-lg border border-stone-100 px-3 py-2"><p className="text-sm font-medium">{entry.cacheNamespace}</p><p className="mt-1 text-xs text-stone-500">提示：{entry.promptVersion} ・ 到期：{formatDate(entry.expiresAt)}</p></div>)}{!data?.cacheEntries.length ? <p className="py-8 text-center text-sm text-stone-500">尚無持久化洞察快取。</p> : null}</div></CardContent></Card>
        </section>

        <section><Card className="border-[#ddd5c6] bg-white/80"><CardHeader><CardTitle>國別指標觀測值</CardTitle><CardDescription>入境旅客與人口資料將依原始期別、發布日與官方來源保存；空白代表來源定義已建立但尚未完成首筆資料驗證。</CardDescription></CardHeader><CardContent className="overflow-x-auto"><table className="w-full min-w-[760px] text-left text-sm"><thead className="border-b border-stone-200 text-xs uppercase tracking-wide text-stone-500"><tr><th className="pb-3 font-medium">國家／指標</th><th className="pb-3 font-medium">最近數值</th><th className="pb-3 font-medium">統計基準日</th><th className="pb-3 font-medium">來源／狀態</th></tr></thead><tbody>{data?.latestIndicatorObservations.map(indicator => <tr key={indicator.indicatorId} className="border-b border-stone-100"><td className="py-3"><p className="font-medium">{indicator.countryName}・{indicator.label}</p><p className="text-xs text-stone-500">{indicator.periodicity}</p></td><td className="py-3 tabular-nums">{indicator.value === null ? "待驗證" : `${indicator.value} ${indicator.unit}`}</td><td className="py-3">{formatDate(indicator.referenceDate)}</td><td className="py-3"><a className="text-[#9d4328] underline-offset-4 hover:underline" href={indicator.sourceUrl} target="_blank" rel="noreferrer">{indicator.sourceName}</a>{indicator.status ? <span className="ml-2"><StatusBadge status={indicator.status} /></span> : null}</td></tr>)}</tbody></table>{!data?.latestIndicatorObservations.length ? <p className="py-8 text-center text-sm text-stone-500">尚未建立國別指標定義。</p> : null}</CardContent></Card></section>
      </div>
    </main>
  );
}
