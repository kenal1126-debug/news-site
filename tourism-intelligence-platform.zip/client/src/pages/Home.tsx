/* Editorial Atlas: 象牙紙張、赭紅訊號線、DM Serif Display＋Noto Sans TC、左索引右閱讀區。 */
import { useState } from "react";
import { buildNewsAnalysis } from "@shared/newsAnalysis";
import { TourismServiceAlertBanner } from "@/components/TourismServiceAlertBanner";
import { BackToTopButton } from "@/components/BackToTopButton";
import { DEFAULT_NEWS_IMAGE, displayCategoryLabel, sourceOptions } from "@/features/dashboard/dashboardHelpers";
import { EditorialHero } from "@/features/dashboard/components/EditorialHero";
import { EditorialSidebar } from "@/features/dashboard/components/EditorialSidebar";
import { DashboardPageSwitcher, type DashboardPageView } from "@/features/dashboard/components/DashboardPageSwitcher";
import { InternationalTrendsSection } from "@/features/dashboard/components/InternationalTrendsSection";
import { KeywordCloudSection } from "@/features/dashboard/components/KeywordCloudSection";
import { MacroTrendSection } from "@/features/dashboard/components/MacroTrendSection";
import { Newsroom } from "@/features/dashboard/components/Newsroom";
import { TourismSignalsPanel } from "@/features/dashboard/components/TourismSignalsPanel";
import { useTourismNewsDashboard } from "@/features/dashboard/hooks/useTourismNewsDashboard";
import { SIGNAL_CATEGORY, type Story } from "@/features/dashboard/types";
import {
  ArrowUpRight,
  Bookmark,
  ChevronDown,
  Compass,
  ExternalLink,
  Globe2,
  Search,
  SlidersHorizontal,
  X,
} from "lucide-react";

type StoryAnalysis = { impact: string; strategy: string };
type InternationalTrend = { country: string; program: string; institution: string; signal: string; implication: string; strategy: string; url: string };


const stories: Story[] = [
  {
    id: 1,
    region: "國際",
    category: "旅遊平台",
    date: "08.06.2026",
    source: "Reuters / AOL",
    title: "Airbnb 營收高於預期，全球旅遊需求與世界盃帶動",
    summary: "第二季全球 nights and seats booked 年增 10%，達 1.483 億；北美訂單成長創近三年新高。",
    insight: "大型體育賽事正把短期流量轉化為住宿與目的地體驗需求。",
    scope: "全球／住宿平台",
    image: "/manus-storage/airbnb_fb51fad0.jpg",
    url: "https://www.aol.com/articles/airbnb-posts-higher-quarterly-revenue-214410000.html",
  },
  {
    id: 2,
    region: "國際",
    category: "旅宿市場",
    date: "08.06.2026",
    source: "Travel Weekly",
    title: "美國飯店市場預測再度上修",
    summary: "2026 年 RevPAR 成長預估上調至 4.4%，平均日房價成長預估為 3.1%，入住率估計達 63.1%。",
    insight: "需求強勁，但營運成本上升仍是旅宿獲利的主要風險。",
    scope: "美國／飯店",
    image: "/manus-storage/travel-weekly-hotels_439b38c1.jpg",
    url: "https://www.travelweekly.com/Travel-News/Hotel-News/US-hotels-performing-well-in-2026-reforecast-costar-tourism-economics",
  },
  {
    id: 3,
    region: "國際",
    category: "航空運能",
    date: "08.2026",
    source: "Cirium",
    title: "旺季需求升溫，全球航空準點率卻下滑",
    summary: "7 月全球準點率由 6 月的 86.29% 降至 83.55%，北美為 71.58%，亞太則以 84.94% 領先。",
    insight: "人次成長與服務穩定度並非同一件事，復原能力成為競爭差異。",
    scope: "全球／航空",
    image: "/manus-storage/cirium-july-2026_09487be6.png",
    url: "https://www.cirium.com/thoughtcloud/cirium-monthly-on-time-performance-reports/",
  },
  {
    id: 4,
    region: "國內",
    category: "航空運能",
    date: "08.2026",
    source: "eTurboNews",
    title: "EVA Air 宣布開航台北—德里，跨境航網持續擴張",
    summary: "12 月 1 日起每週五班，串接台灣與印度的商務、探親與休閒旅遊需求。",
    insight: "新航線不只是交通供給，也會改變目的地的客源結構與產品設計。",
    scope: "台灣／印度",
    image: "/manus-storage/etn-live_d8dfd8cb.jpg",
    url: "https://eturbonews.com/travel-tourism-news-live-updates-august-2026/",
  },
  {
    id: 5,
    region: "國際",
    category: "目的地行銷",
    date: "08.2026",
    source: "eTurboNews",
    title: "大湄公次區啟動 2026–2030 共同觀光行銷計畫",
    summary: "六方共同推動四項年度活動，涵蓋 24 個優先目的地，並導入永續與次級目的地策略。",
    insight: "目的地競爭正在從單一城市，轉向跨境路線與共同品牌。",
    scope: "東南亞／區域合作",
    image: "/manus-storage/etn-breaking_7d68c8d4.jpg",
    url: "https://eturbonews.com/travel-tourism-news-live-updates-august-2026/",
  },
  {
    id: 6,
    region: "國內",
    category: "台灣觀光",
    date: "08.09.2026",
    source: "台中市觀旅局",
    title: "台中攜星宇航空邀日本 KOL 踩線推廣中台灣",
    summary: "台中市觀光旅遊局與星宇航空攜手邀請日本神戶地區 KOL 踩線，推廣中台灣山海屯城的多元觀光特色。",
    insight: "地方觀光正在用更精準的城市與社群受眾，取代泛用式曝光。",
    scope: "台灣／日本",
    image: "/manus-storage/taichung-yahoo_34b6b088.webp",
    url: "https://www.taichung.gov.tw/3342202/post",
  },
  {
    id: 7,
    region: "國內",
    category: "台灣觀光",
    date: "08.07.2026",
    source: "交通部觀光署",
    title: "台灣觀光館串聯 54 家觀光圈業者，讓美食成為旅行起點",
    summary: "2026 台灣美食展以「台灣美Ways發酵中」為主題，串聯地方風土、美食、文化與旅遊資源。",
    insight: "從展場買氣到地方旅遊，觀光圈正在把餐飲轉化為目的地入口。",
    scope: "台灣／地方創生",
    image: "/manus-storage/taiwan-food-expo_19d8ec0d.jpg",
    url: "https://www.motc.gov.tw/ch/app/data/view?module=news&id=14&serno=fff7df91-cd8b-46a4-854c-8eb6b2dc33ee",
  },
  {
    id: 8,
    region: "國內",
    category: "台灣觀光",
    date: "08.08.2026",
    source: "僑委會／中央社",
    title: "台灣以 LGBTQ+ 友善體驗進攻泰國市場",
    summary: "觀光署在曼谷邀請 4 組泰國網紅分享美食、文化、樂活與性別友善旅遊，串聯航空、旅宿與餐飲業者。",
    insight: "海外客源行銷從大眾曝光，轉向更清楚的主題路線與服務體驗。",
    scope: "台灣／泰國",
    image: "/manus-storage/ocac_0d230b76.jpg",
    url: "https://www.ocac.gov.tw/OCAC/Pages/Detail.aspx?nodeid=345&pid=88982944",
  },
  {
    id: 9,
    region: "國內",
    category: "旅遊成本",
    date: "08.09.2026",
    source: "經濟日報",
    title: "國籍航空國際線燃油附加費調整，出境旅遊成本受影響",
    summary: "8 月 9 日起國籍航空國際線燃油附加費調漲，短程航線調至 30 美元、長程航線調至 78 美元。",
    insight: "航空成本變動會同步反映在旅行社報價、旅客決策與目的地需求。",
    scope: "台灣／出境旅遊",
    image: "/manus-storage/fuel-yahoo_ee69bd91.webp",
    url: "https://money.udn.com/money/story/7307/9668656",
  },
  {
    id: 10,
    region: "國內",
    category: "台灣觀光",
    date: "08.07.2026",
    source: "交通部觀光署",
    title: "東北角外澳月夜串聯五漁村與慢旅產品",
    summary: "8 月 22 日至 23 日宜蘭外澳舉辦音樂、市集與火舞活動，並結合旅行社推出鐵道浪花小旅行。",
    insight: "地方活動與交通、旅遊業者協作，讓一次性節慶延伸成可購買的旅遊產品。",
    scope: "台灣／東北角",
    image: "/manus-storage/waiao-moon-night_f70adae7.jpg",
    url: "https://www.motc.gov.tw/ch/app/data/view?module=news&id=14&serno=4279da00-1722-4106-8c22-5677ff3cf72f",
  },
  {
    id: 11,
    region: "國內",
    category: "台灣觀光",
    date: "08.04.2026",
    source: "經濟日報",
    title: "國旅人次與支出創新高，但近八成旅程仍是當天來回",
    summary: "觀光署調查顯示，114 年國旅旅次達 2 億 4761 萬次、支出 5643 億元，雙創歷史新高；近八成旅程仍當天往返。",
    insight: "市場總量上升不等於住宿需求同步增加，地方目的地需要設計更能留客的夜間與深度體驗。",
    scope: "台灣／國旅市場",
    image: "/manus-storage/yahoo-domestic-travel_f10d8dea.jpg",
    url: "https://money.udn.com/money/story/5648/9668167",
  },
  {
    id: 12,
    region: "國內",
    category: "台灣觀光",
    date: "07.29.2026",
    source: "聯合新聞網",
    title: "學者：台灣觀光需要新的體驗，才能吸引更多國際旅客",
    summary: "產業觀察指出，若旅遊產品與目的地體驗缺乏差異，國際客源成長將受到限制。",
    insight: "觀光競爭已從景點曝光轉向產品更新，地方品牌必須回答旅客為何值得多停留幾天。",
    scope: "台灣／入境旅遊",
    image: "/manus-storage/yahoo-international_8683247b.jpg",
    url: "https://udn.com/news/story/7266/9659371",
  },
  {
    id: 13,
    region: "國內",
    category: "目的地行銷",
    date: "08.10.2026",
    source: "交通部觀光署",
    title: "觀光署前進釜山拓展韓國客源，聚焦短距離與短天數旅遊",
    summary: "觀光署攜手台灣旅遊業者在釜山推廣台灣，鎖定韓國旅客的短程、短天數海外旅遊需求。",
    insight: "成熟客源市場的開發更需要貼近旅客出發地、假期長度與既有航網設計產品。",
    scope: "台灣／韓國市場",
    image: "/manus-storage/busan-tourism-promotion_412a3cfc.jpg",
    url: "https://www.taiwan.net.tw/m1.aspx?sNo=0044528",
  },
  {
    id: 14,
    region: "國內",
    category: "目的地行銷",
    date: "08.10.2026",
    source: "台中市觀旅局",
    title: "中台灣觀光推廣前進新加坡，串聯旅行社與航空業者",
    summary: "中台灣四縣市赴新加坡進行海外推廣與業者媒合，深化航空、旅行社與地方觀光合作。",
    insight: "跨城市聯合行銷能把單點景點整合成更完整的區域旅遊路線，提高海外通路採購意願。",
    scope: "台灣／新加坡",
    image: "/manus-storage/taichung-singapore_37e46817.jpg",
    url: "https://travel.taichung.gov.tw/zh-tw/event/newsdetail/10333",
  },
  {
    id: 15,
    region: "國內",
    category: "旅遊成本",
    date: "08.13.2026",
    source: "風傳媒",
    title: "2026 旅遊補助方案聚焦平日住宿與合法旅宿",
    summary: "最新旅遊優惠方案將平日住宿列為重點，鼓勵旅客分散假日需求並選擇合法旅宿。",
    insight: "補助政策若能與淡季產品、地方活動及交通方案同步設計，才有機會轉化為真正的停留天數。",
    scope: "台灣／旅遊政策",
    image: "/manus-storage/atlas-hero-map_10be6641.jpg",
    url: "https://www.storm.mg/lifestyle/11154479",
  },
  {
    id: 16,
    region: "國際",
    category: "台灣觀光",
    date: "08.03.2026",
    source: "TaiwanPlus",
    title: "來台旅客消費創新高，觀光產業迎來高價值客群機會",
    summary: "台灣觀光產業在 2025 年迎來新的消費里程碑，國際旅客支出達到歷史高點。",
    insight: "入境人次之外，旅客消費結構與體驗品質將成為評估觀光成長的另一組核心指標。",
    scope: "台灣／國際客源",
    image: "/manus-storage/taiwanplus_0a65f479.jpg",
    url: "https://www.taiwanplus.com/news/taiwan-news/travel-and-food/260804011/tourism-to-taiwan-up-as-visitor-spending-reaches-new-high",
  },
];

const storyAnalysis: Record<number, StoryAnalysis> = {
  1: { impact: "平台訂單與大型賽事需求同步放大，住宿、體驗與交通預訂將在短期內集中湧入。", strategy: "提前建立賽事檔期容量與動態定價模型，並把住宿、接駁與在地體驗打包銷售。" },
  2: { impact: "旅宿需求與房價展望上修，有利收益成長，但人力、能源與服務成本也會壓縮利潤。", strategy: "以分眾收益管理提高平日入住率，同時優先投資節能、排班與數位自助服務。" },
  3: { impact: "旺季航班量增加但準點率下滑，延誤將連鎖影響轉機、旅宿入住與目的地行程。", strategy: "以即時航班資料建立主動通知與改簽流程，並為高風險航段預留替代運能。" },
  4: { impact: "台北—德里直航擴充台印商務、探親與休閒客源，也會提高印度市場的產品競爭。", strategy: "設計短天數城市串聯、商務延伸與印度友善餐飲服務，並與航空公司共同經營航線客座率。" },
  5: { impact: "跨境共同品牌把湄公次區從單點景點轉為區域路線，台灣業者將面對更完整的東南亞替代方案。", strategy: "鎖定次級目的地與永續主題，推出可跨境銷售的多國行程與一致的內容標籤。" },
  6: { impact: "航空、地方景點與 KOL 的聯合推廣提高日本客源轉換機會，也讓地方品牌更依賴精準受眾經營。", strategy: "以航線城市為入口追蹤內容觸及、到站與消費轉換，建立可複製的 KOL 聯合銷售模組。" },
  7: { impact: "美食展將餐飲、地方創生與觀光圈連結，能為地方帶來新客流，但需要展後持續導流。", strategy: "把展場品牌轉成地圖、預約與小旅行產品，建立從試吃到實際到訪的追蹤鏈。" },
  8: { impact: "性別友善與生活風格主題有助於切入泰國細分客群，服務一致性會直接影響口碑與回訪。", strategy: "建立友善接待培訓與主題旅程標準，讓航空、旅宿、餐飲與景點共享同一套服務承諾。" },
  9: { impact: "燃油附加費調整會推高出境旅遊報價，短程與價格敏感客群可能延後或改變目的地選擇。", strategy: "提供含附加費的透明報價，並以早鳥、替代航點與套裝產品降低旅客對單項漲幅的感受。" },
  10: { impact: "地方節慶若結合鐵道、旅行社與五漁村，可把一次性活動轉成淡季住宿與慢旅需求。", strategy: "建立活動日期以外的常態路線，配置接駁、夜間體驗與在地商家聯票延長停留。" },
  11: { impact: "國旅總量成長但當天往返比例高，地方旅宿與夜間經濟未必能同步受益。", strategy: "優先設計兩天一夜的夜遊、餐飲與親子產品，並以交通便利性降低旅客延長停留的門檻。" },
  12: { impact: "國際旅客對新體驗的需求提高，重複性高的景點與產品將更難支撐入境市場成長。", strategy: "以地方文化、自然療癒與創意生活打造可辨識主題，持續更新內容而非只增加曝光。" },
  13: { impact: "韓國短程、短天數市場具備快速轉換潛力，航網與假期節奏將影響台灣目的地分布。", strategy: "在釜山等出發地同步販售短程套裝，將週末航班、季節活動與區域交通整合成即買即走產品。" },
  14: { impact: "中台灣聯合新加坡旅行社與航空業者，有機會提升區域路線的海外通路能見度與採購效率。", strategy: "用四縣市共同產品取代單點宣傳，提供業者可直接上架的行程、素材與團體接待規格。" },
  15: { impact: "平日住宿補助可分散假日尖峰，但若缺少地方內容配套，可能只形成短期價格刺激。", strategy: "把補助與淡季活動、合法旅宿、交通優惠綁定，並追蹤入住天數與回訪率而非只看核銷量。" },
  16: { impact: "國際旅客消費創高顯示高價值客群機會增加，產業競爭將從人次轉向消費品質與體驗深度。", strategy: "以高附加價值體驗、在地採購與多語服務提升客單價，並用消費資料回饋市場投放。" },
};

const internationalTrends: InternationalTrend[] = [
  { country: "日本", program: "DBJ・JTBF 訪日外國旅客意向調查 2025", institution: "日本交通公社／日本政策投資銀行", signal: "地方誘客的關鍵不只是增加曝光；訪日經驗越深，旅客對自然風景、傳統料理與祭典等地域體驗的需求越明確。", implication: "台灣需要把地方景點轉成有背景、有脈絡、值得專程前往的深度體驗，而不是只做景點清單。", strategy: "以地方故事、季節活動與交通串聯設計 2–3 天主題路線，並用日語內容說清楚『為何值得來』。", url: "https://www.jtb.or.jp/news/news-research/release-asiaeuro-survey-2025-spinout/" },
  { country: "韓國", program: "2025 潛在訪韓旅客調查", institution: "韓國觀光公社 Data Lab", signal: "調查同時追蹤一般外國人與訪韓意向者，並細分 26 個居住國；新增主題形象、未決定者障礙、季節與交通偏好等題項。", implication: "成熟市場的客源判讀必須從總體意向進一步拆解到居住地區、旅遊阻礙與出行時機。", strategy: "為韓國市場建立週末短程、季節活動與區域交通的分眾產品，並持續追蹤『考慮中但尚未決定』的轉換障礙。", url: "https://datalab.visitkorea.or.kr/site/portal/ex/bbs/View.do?bcIdx=310609&cbIdx=1603" },
  { country: "加拿大", program: "Global Tourism Watch", institution: "Destination Canada", signal: "以消費者情報長期追蹤目的地認知、旅遊意向、品牌競爭力、體驗需求、動機、障礙與口碑推薦。", implication: "國際市場不應只看入境人次，也要同步掌握品牌被想起的程度、旅客想要的體驗與尚未成行的阻力。", strategy: "建立台灣的市場健康儀表板，按市場追蹤認知、考慮、偏好體驗與轉換障礙，讓行銷預算對應到漏斗階段。", url: "https://www.destinationcanada.com/en-ca/global-tourism-watch" },
  { country: "澳洲", program: "Consumer Demand Project（CDP）", institution: "Tourism Australia", signal: "官方 Insights 入口以消費者與市場研究支援國際行銷決策，重點在理解旅客需求、目的地選擇與市場變化。", implication: "台灣可把國際行銷從單次活動改成持續的需求監測，定期檢查不同市場對產品、內容與品牌的反應。", strategy: "建立季度市場訊號更新，將搜尋、內容互動、航線與實際到訪資料放在同一張決策表，快速調整投放與產品。", url: "https://www.tourism.australia.com/en/insights.html" },
  { country: "紐西蘭", program: "Active Considerer Monitor", institution: "Tourism New Zealand", signal: "Active considerers 指認真考慮下一趟假期前往紐西蘭的人；研究追蹤各市場的受眾規模、旅遊情緒，以及淡季動機、障礙與永續選擇。", implication: "真正值得經營的是已進入考慮階段、但仍需要理由與信心完成預訂的旅客。", strategy: "針對高意向客群提供清楚的行程證據、淡季理由與永續承諾，並以內容回答安全、交通與體驗品質疑慮。", url: "https://www.tourismnewzealand.com/insights/consumer-research/" },
];

function AppLogo() {
  return (
    <div className="brand-lockup">
      <img src="/manus-storage/tti-logo-02_a23c43b3.png" alt="觀．戰情 TTI 標誌" className="brand-mark" />
      <div>
        <div className="brand-name">觀光趨勢</div>
        <div className="brand-subtitle">TOURISM ATLAS / WEEKLY INTELLIGENCE</div>
      </div>
    </div>
  );
}

export default function Home() {
  const [contentView, setContentView] = useState<DashboardPageView>("news");
  const {
    query, setQuery, activeDemandTerm, setActiveDemandTerm, activeRegion, setActiveRegion, activeCategory, setActiveCategory, activeSource, setActiveSource, showSourceFilter, setShowSourceFilter, mobileNav, setMobileNav, saved, toggleSaved,
    todayLabel, newsNextUpdateLabel, issueRangeLabel, visibleStories, keywordClouds, demandEarlySignal, capacityPressureSignal, sourceMarketSignal, keywordCloudSync, tourismSignals, tourismServiceAlerts, regions, categories, topics, bbcTravelCount, yahooTravelCount, yahooTaiwanFunCount, industryMediaCount, filteredStories,
    yahooTaiwanFunFilter, industryMediaFilter,
  } = useTourismNewsDashboard(stories);

  const goToSignals = () => {
    setActiveRegion("全部");
    setActiveCategory("全部");
    setQuery("");
    window.setTimeout(() => document.getElementById("tourism-signals")?.scrollIntoView({ behavior: "smooth", block: "start" }), 0);
  };

  return (
    <div className="atlas-shell">
      <EditorialSidebar
        mobileNav={mobileNav}
        regions={regions}
        categories={categories}
        topics={topics}
        activeRegion={activeRegion}
        activeCategory={activeCategory}
        issueRangeLabel={issueRangeLabel}
        onRegionChange={(region) => { setContentView("news"); setActiveRegion(region); setActiveCategory("全部"); setMobileNav(false); }}
        onCategoryChange={(category) => { setContentView("news"); setActiveCategory(category); setMobileNav(false); }}
      />

      {mobileNav && <button className="mobile-overlay" aria-label="關閉選單" onClick={() => setMobileNav(false)} />}

      <main className="atlas-main">
        <EditorialHero
          todayLabel={todayLabel}
          newsNextUpdateLabel={newsNextUpdateLabel}
          visibleStoryCount={visibleStories.length}
          onOpenNavigation={() => setMobileNav(true)}
          demandEarlySignal={demandEarlySignal}
          capacityPressureSignal={capacityPressureSignal}
          sourceMarketSignal={sourceMarketSignal}
          keywordCloudSync={keywordCloudSync}
          onDemandTermSelect={(term) => { setContentView("news"); setActiveRegion("全部"); setActiveCategory("全部"); setActiveSource("全部來源"); setActiveDemandTerm(term); setQuery(term); window.setTimeout(() => document.getElementById("stories")?.scrollIntoView({ behavior: "smooth", block: "start" }), 0); }}
          alertSlot={<TourismServiceAlertBanner alerts={tourismServiceAlerts} />}
        />

        <DashboardPageSwitcher activeView={contentView} onViewChange={setContentView} />
        {contentView === "news" && <>
          <KeywordCloudSection keywordClouds={keywordClouds} />
          <Newsroom
          activeRegion={activeRegion}
          activeCategory={activeCategory}
          activeSource={activeSource}
          query={query}
          showSourceFilter={showSourceFilter}
          visibleStories={visibleStories}
          filteredStories={filteredStories}
          tourismSignalCount={tourismSignals.length}
          bbcTravelCount={bbcTravelCount}
          yahooTravelCount={yahooTravelCount}
          yahooTaiwanFunCount={yahooTaiwanFunCount}
          yahooTaiwanFunFilter={yahooTaiwanFunFilter}
          industryMediaCount={industryMediaCount}
          industryMediaFilter={industryMediaFilter}
          sourceOptions={sourceOptions}
          saved={saved}
          storyAnalysis={storyAnalysis}
          onQueryChange={(value) => { setActiveDemandTerm(""); setQuery(value); }}
          onToggleSourceFilter={() => setShowSourceFilter((current) => !current)}
          onSourceChange={(source) => { setActiveDemandTerm(""); setActiveSource(source); setShowSourceFilter(false); }}
          onCategoryChange={(category) => { setContentView("news"); setActiveCategory(category); }}
          onRegionChange={(region) => { setContentView("news"); setActiveRegion(region); }}
          onToggleSaved={toggleSaved}
          />
          {activeCategory === SIGNAL_CATEGORY && <TourismSignalsPanel tourismSignals={tourismSignals} />}
        </>}
        {contentView === "macro" && <MacroTrendSection />}
        {contentView === "international" && <InternationalTrendsSection trends={internationalTrends} />}

        <footer className="atlas-footer" id="methodology">
          <div className="footer-brand"><img src="/manus-storage/tti-logo-02_a23c43b3.png" alt="" /><span>觀．戰情</span></div>
          <div className="footer-copy">本平台整理公開新聞資料，提供觀光產業閱讀與研究參考。<br />所有報導連結皆回到原始發布來源。</div>
          <div className="footer-right">DAILY UPDATE<br /><span>{issueRangeLabel}</span></div>
        </footer>
      </main>
      <BackToTopButton />
    </div>
  );
}
