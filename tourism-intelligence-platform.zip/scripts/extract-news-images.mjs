import fs from "node:fs";
import https from "node:https";
import http from "node:http";
import { URL } from "node:url";

const source = fs.readFileSync(new URL("../client/src/pages/Home.tsx", import.meta.url), "utf8");
const urls = [...source.matchAll(/url:\s*["'](https?:[^"']+)["']/g)].map((match) => match[1]);

function fetchPage(url, redirects = 0) {
  return new Promise((resolve) => {
    if (redirects > 5) return resolve("");
    const client = url.startsWith("https:") ? https : http;
    const request = client.get(url, { headers: { "user-agent": "Mozilla/5.0 news-image-audit" }, timeout: 12000 }, (response) => {
      if ([301, 302, 303, 307, 308].includes(response.statusCode) && response.headers.location) {
        response.resume();
        return resolve(fetchPage(new URL(response.headers.location, url).toString(), redirects + 1));
      }
      let body = "";
      response.setEncoding("utf8");
      response.on("data", (chunk) => { body += chunk; if (body.length > 2_000_000) response.destroy(); });
      response.on("end", () => resolve(body));
      response.on("error", () => resolve(""));
    });
    request.on("timeout", () => request.destroy());
    request.on("error", () => resolve(""));
  });
}

const results = [];
for (const url of urls) {
  const html = await fetchPage(url);
  const match = html.match(/<meta[^>]+(?:property|name)=["'](?:og:image|twitter:image)["'][^>]+content=["']([^"']+)["']/i) || html.match(/<meta[^>]+content=["']([^"']+)["'][^>]+(?:property|name)=["'](?:og:image|twitter:image)["']/i);
  results.push({ url, image: match?.[1] ? new URL(match[1], url).toString() : null, fetched: Boolean(html) });
}
fs.writeFileSync(new URL("../news-image-audit.json", import.meta.url), JSON.stringify(results, null, 2));
console.log(JSON.stringify(results, null, 2));
