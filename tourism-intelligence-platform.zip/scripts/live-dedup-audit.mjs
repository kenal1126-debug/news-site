import { and, gte, desc } from "drizzle-orm";
import { newsItems } from "../drizzle/schema.ts";
import { getDb } from "../server/db.ts";
import { inferNewsCategory } from "../shared/newsClassification.ts";
import { mergeNewsByIdentity } from "../shared/newsMerge.ts";

const db = await getDb();
if (!db) throw new Error("DATABASE_URL is not available");
const since = new Date(Date.now() - 14 * 24 * 60 * 60 * 1000);
const rows = await db.select().from(newsItems).where(gte(newsItems.publishedAt, since)).orderBy(desc(newsItems.publishedAt));
const stories = rows.map((row) => ({
  id: row.id,
  source: row.source,
  title: row.title,
  summary: row.summary ?? "",
  url: row.url,
  image: row.imageUrl ?? "",
  date: row.publishedAt.toISOString(),
  category: inferNewsCategory(row.title, row.summary ?? ""),
}));
const categories = [...new Set(stories.map((story) => story.category))].sort();
const categoryAudit = categories.map((category) => {
  const categoryStories = stories.filter((story) => story.category === category);
  const deduped = mergeNewsByIdentity(categoryStories, []);
  return { category, before: categoryStories.length, after: deduped.length, removed: categoryStories.length - deduped.length };
});
const target = stories.filter((story) => /經濟放緩影響消費信心|中國人下半年出境游|下半年出境旅遊/.test(story.title));
const targetDeduped = mergeNewsByIdentity(target, []);
console.log(JSON.stringify({
  since: since.toISOString(),
  totalBefore: stories.length,
  totalAfter: categoryAudit.reduce((sum, item) => sum + item.after, 0),
  categoryAudit,
  targetBefore: target.length,
  targetAfter: targetDeduped.length,
  targetDeduped: targetDeduped.map(({ id, source, title, url, image, category }) => ({ id, source, title, url, image, category })),
}, null, 2));
process.exit(0);
