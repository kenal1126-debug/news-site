import fs from "node:fs";
import https from "node:https";
import http from "node:http";
import { URL } from "node:url";

const targets = JSON.parse(fs.readFileSync(new URL("../news-image-audit.json", import.meta.url), "utf8")).filter((item) => !item.image).map((item) => item.url);

function fetchPage(url, redirects = 0) {
  return new Promise((resolve) => {
    if (redirects > 5) return resolve("");
    const client = url.startsWith("https:") ? https : http;
    const request = client.get(url, { headers: { "user-agent": "Mozilla/5.0 news-image-audit" }, timeout: 10000 }, (response) => {
      if ([301, 302, 303, 307, 308].includes(response.statusCode) && response.headers.location) {
        response.resume();
        return resolve(fetchPage(new URL(response.headers.location, url).toString(), redirects + 1));
      }
      let body = "";
      response.setEncoding("utf8");
      response.on("data", (chunk) => { body += chunk; if (body.length > 2_000_000) response.destroy(); });
      response.on("end", () => resolve(body));
      response.on("error", () => resolve(""));
    });
    request.on("timeout", () => request.destroy());
    request.on("error", () => resolve(""));
  });
}

const results = [];
for (const url of targets) {
  const html = await fetchPage(url);
  const candidates = [...html.matchAll(/<img[^>]+(?:src|data-src|data-lazy-src)=["']([^"']+)["'][^>]*>/gi)]
    .map((match) => match[1])
    .map((src) => { try { return new URL(src, url).toString(); } catch { return null; } })
    .filter(Boolean)
    .filter((src) => !/logo|icon|avatar|pixel|tracking|sprite|svg/i.test(src));
  results.push({ url, image: candidates[0] ?? null, candidates: candidates.slice(0, 5) });
}
fs.writeFileSync(new URL("../news-inline-image-audit.json", import.meta.url), JSON.stringify(results, null, 2));
console.log(JSON.stringify(results, null, 2));
