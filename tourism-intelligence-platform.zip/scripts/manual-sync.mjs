import { mapWithConcurrency, NEWS_FEEDS, parseRss, parseYahooTaiwanCategoryHtml, syncRecentNews, SYNC_SOURCE_CONCURRENCY, YAHOO_TAIWAN_FUN_FEEDS } from "../server/news-sync.ts";
import { listRecentNews } from "../server/repositories/newsRepository.ts";
import { runManualNewsSyncAudit } from "../server/news/manualSyncAudit.ts";

const now = new Date();
const feedReport = await mapWithConcurrency(NEWS_FEEDS, SYNC_SOURCE_CONCURRENCY, async (feed) => {
  try {
    const response = await fetch(feed.url, {
      headers: { "user-agent": "TourismIntelligencePlatform/1.0" },
      signal: AbortSignal.timeout(12_000),
    });
    const xml = await response.text();
    return { source: feed.source, status: response.status, bytes: xml.length, parsed: response.ok ? parseRss(xml, feed.source, now).length : 0 };
  } catch (error) {
    return { source: feed.source, status: "error", error: String(error) };
  }
});

const yahooTaiwanReport = await mapWithConcurrency(YAHOO_TAIWAN_FUN_FEEDS, SYNC_SOURCE_CONCURRENCY, async (feed) => {
  try {
    const response = await fetch(feed.url, {
      headers: { "user-agent": "TourismIntelligencePlatform/1.0" },
      signal: AbortSignal.timeout(12_000),
    });
    const html = await response.text();
    return { category: feed.category, source: feed.source, url: feed.url, status: response.status, bytes: html.length, parsed: response.ok ? parseYahooTaiwanCategoryHtml(html, feed, now).length : 0 };
  } catch (error) {
    return { category: feed.category, source: feed.source, url: feed.url, status: "error", error: String(error) };
  }
});

console.log(JSON.stringify({ phase: "feed-preflight", generatedAt: now.toISOString(), feeds: feedReport, yahooTaiwan: yahooTaiwanReport }, null, 2));
const { syncResult, recent } = await runManualNewsSyncAudit({ now, syncNews: syncRecentNews, listRecentNews });
console.log(JSON.stringify({ phase: "sync-result", ...syncResult }, null, 2));

const englishSourcePattern = /Skift|台灣觀光署英文|海外英文|Travel Weekly|eTurboNews|Cirium|Reuters|Associated Press|BBC|Guardian|Bloomberg|CNBC|CNN Travel|Euronews|Nikkei|Forbes|National Geographic|WTTC|UN Tourism/i;
const englishTitlePattern = /\b(the|tourism|tourist|travel|hotel|airline|aviation|airport|destination|hospitality|passenger|flight|visitor|economy|sustainability|forecast|market)\b/i;
const englishItems = recent.filter((item) => englishSourcePattern.test(item.source) || englishTitlePattern.test(item.title));
const signalItems = recent.filter((item) => englishSourcePattern.test(item.source));
const domesticMediaPattern = /TVBS|中央社|ETtoday|三立|中時|公視|自由時報|聯合新聞網|經濟日報|NOWnews|風傳媒/i;
const serviceDisruptionPattern = /(觀光署|觀旅局|觀光局|國旅補助|旅宿網|旅遊補助).{0,48}(網站當機|網站當掉|官網當機|官網當掉|系統當機|系統當掉|系統壅塞|系統塞爆|網站壅塞|當掉|塞爆|流量異常|流量暴增|服務中斷|申請異常|無法登入|無法申請)|(網站當機|網站當掉|官網當機|官網當掉|系統當機|系統當掉|系統壅塞|系統塞爆|網站壅塞|當掉|塞爆|流量異常|流量暴增|服務中斷|申請異常|無法登入|無法申請).{0,48}(觀光署|觀旅局|觀光局|國旅補助|旅宿網|旅遊補助)/i;
const domesticMediaItems = recent.filter((item) => domesticMediaPattern.test(item.source));
const serviceDisruptionItems = recent.filter((item) => serviceDisruptionPattern.test(`${item.title} ${item.summary ?? ""}`));
console.log(JSON.stringify({
  phase: "database-audit",
  recentCount: recent.length,
  englishCount: englishItems.length,
  englishSourceCount: new Set(englishItems.map((item) => item.source)).size,
  englishSources: [...new Set(englishItems.map((item) => item.source))].sort(),
  signalItems: signalItems.length,
  domesticMediaCounts: Object.fromEntries([...new Set(domesticMediaItems.map((item) => item.source))].sort().map((source) => [source, domesticMediaItems.filter((item) => item.source === source).length])),
  governmentTourismServiceDisruptionCount: serviceDisruptionItems.length,
  governmentTourismServiceDisruptions: serviceDisruptionItems.slice(0, 10).map((item) => ({ source: item.source, title: item.title, url: item.url, publishedAt: item.publishedAt })),
  yahooTaiwanCounts: Object.fromEntries(YAHOO_TAIWAN_FUN_FEEDS.map((feed) => [feed.category, recent.filter((item) => item.source === feed.source).length])),
  sampleEnglish: englishItems.slice(0, 20).map((item) => ({ source: item.source, title: item.title, url: item.url, image: Boolean(item.imageUrl), publishedAt: item.publishedAt })),
}, null, 2));

// mysql2 retains its connection pool in a standalone CLI process; all work and
// audit output above are complete, so end explicitly instead of holding a shell.
process.exit(0);
