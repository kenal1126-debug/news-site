import fs from "node:fs";

const html = fs.readFileSync("/tmp/yahoo-tourist-spots.html", "utf8");
const needle = "台北近郊看海提案";
const index = html.indexOf(needle);
console.log({ length: html.length, index });
if (index >= 0) console.log(html.slice(Math.max(0, index - 1800), index + 2600));
const hrefs = [...html.matchAll(/href=["']([^"']+\.html)["']/gi)].slice(0, 10).map((m) => m[1]);
console.log("sampleHrefs", hrefs);
const dates = [...html.matchAll(/(?:天前|小時前|昨天|前天)/g)].slice(0, 12).map((m) => html.slice(Math.max(0, m.index - 80), m.index + 80));
console.log("dateContexts", dates);
