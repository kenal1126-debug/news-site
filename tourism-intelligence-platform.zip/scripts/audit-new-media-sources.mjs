import { listRecentNews } from "../server/db.ts";
import { inferNewsCategory } from "../shared/newsClassification.ts";
import { isTourismRelated } from "../shared/tourismTopics.ts";

const TARGET_SOURCES = [
  "TVBS新聞網",
  "中央社",
  "ETtoday",
  "三立",
  "中時",
  "公視",
];

const cutoff = new Date(Date.now() - 14 * 24 * 60 * 60 * 1000);
const recent = await listRecentNews(cutoff);

const sourceMatches = (source, target) => source.includes(target);
const report = TARGET_SOURCES.map((target) => {
  const items = recent
    .filter((item) => sourceMatches(item.source, target))
    .filter((item) => isTourismRelated(`${item.title} ${item.summary ?? ""}`, item.source));
  const categoryCounts = Object.fromEntries(Object.entries(items.reduce((counts, item) => {
    const category = inferNewsCategory(item.title, item.summary ?? "", item.source);
    counts[category] = (counts[category] ?? 0) + 1;
    return counts;
  }, {})).sort(([left], [right]) => left.localeCompare(right, "zh-Hant")));

  return {
    sourcePattern: target,
    visibleTourismItems: items.length,
    categoryCounts,
    withImage: items.filter((item) => Boolean(item.imageUrl)).length,
    directUrl: items.filter((item) => !item.url.startsWith("https://news.google.com/")).length,
    samples: items.slice(0, 3).map((item) => ({
      source: item.source,
      title: item.title,
      category: inferNewsCategory(item.title, item.summary ?? "", item.source),
      hasImage: Boolean(item.imageUrl),
      directUrl: !item.url.startsWith("https://news.google.com/"),
      url: item.url,
      publishedAt: item.publishedAt,
    })),
  };
});

console.log(JSON.stringify({ cutoff: cutoff.toISOString(), report }, null, 2));
process.exit(0);
