import { refreshInternationalIndicators } from "../server/internationalIndicators.ts";

const result = await refreshInternationalIndicators({ triggerKind: "manual_audit" });
console.log(JSON.stringify({ phase: "international-indicator-refresh", ...result }, null, 2));
process.exit(0);
