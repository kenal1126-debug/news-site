# 同步新聞來源與原文連結抽查

抽查時間：2026-08-14。

首頁重新載入真實同步資料後，頁面文字確認新聞卡片包含「自由時報」、「聯合新聞網」、「NOWnews」與「經濟日報」，並在每則卡片呈現「自動同步／近期新聞」、「已索引」與「查看原文」。首頁 DOM 實際 href 抽查結果如下：

| 來源 | 實際 href 抽查結果 | 判定 |
|---|---|---|
| 自由時報生活 | `https://news.ltn.com.tw/news/life/breakingnews/5539855`、`https://news.ltn.com.tw/news/life/breakingnews/5539840` | 直接連到自由時報生活原文 |
| 聯合新聞網 | 首頁同步卡片存在，href 為 `https://news.google.com/rss/articles/...` 聚合項目 | 可追溯至 Google News RSS 的聯合新聞網來源；同步程式會嘗試追蹤重新導向，若來源端不回傳重新導向則保留聚合網址 |
| 經濟日報 | 首頁同步卡片存在，href 為 `https://news.google.com/rss/articles/...` 聚合項目 | 可追溯至 Google News RSS 的經濟日報來源；同步程式會嘗試追蹤重新導向，若來源端不回傳重新導向則保留聚合網址 |
| NOWnews | 首頁同步卡片存在，href 為 `https://news.google.com/rss/articles/...` 聚合項目 | 可追溯至 Google News RSS 的 NOWnews 來源；同步程式會嘗試追蹤重新導向，若來源端不回傳重新導向則保留聚合網址 |

另以單元測試驗證：非聚合的自由時報 URL 維持不變；Google News wrapper 在回傳重新導向時會保存原始媒體 URL。首頁桌面與 375px 手機版長頁畫面均完成檢查，主題標籤、來源標示與雙欄產業影響／策略區塊沒有造成版面溢出。
